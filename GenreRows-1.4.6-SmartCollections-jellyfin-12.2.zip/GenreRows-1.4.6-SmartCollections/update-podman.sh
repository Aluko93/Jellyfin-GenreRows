#!/usr/bin/env bash
set -euo pipefail
container="${1:-jellyfin}"
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bundle="$here/package/GenreRows_1.4.6.0"
destination=/config/plugins/GenreRows_1.4.6.0
stamp="$(date -u +%Y%m%dT%H%M%SZ)-$$"
staging="/config/GenreRows-staging-$stamp"

command -v podman >/dev/null
[[ -f "$bundle/Jellyfin.Plugin.GenreRows.dll" ]] || { echo 'DLL assente: estrai tutto lo ZIP.' >&2; exit 1; }
(cd "$bundle" && sha256sum --check SHA256SUMS)
[[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || { echo 'Avvia prima il container Jellyfin.' >&2; exit 1; }
expected_server="12.2.0"
server_version="$(podman exec "$container" /jellyfin/jellyfin --version 2>&1 || true)"
server_version="${server_version//$'\r'/}"
[[ "$server_version" == "Jellyfin.Server $expected_server" || "$server_version" == "Jellyfin.Server $expected_server.0" ]] || { echo "Questo pacchetto richiede Jellyfin $expected_server. Rilevato: $server_version. Nessuna modifica eseguita." >&2; exit 1; }
podman exec "$container" test -d /config/plugins
if podman exec "$container" test -e "$destination"; then
  echo 'Genre Rows 1.4.6 è già presente: nessuna modifica eseguita.' >&2; exit 1
fi

mapfile -t installed < <(podman exec "$container" find /config/plugins -mindepth 2 -maxdepth 2 -type f -name Jellyfin.Plugin.GenreRows.dll -print)
if [[ "${#installed[@]}" -ne 1 ]]; then
  echo "Attesa una sola installazione Genre Rows precedente; trovate ${#installed[@]}. Nessuna modifica eseguita." >&2
  printf '%s\n' "${installed[@]}" >&2
  exit 1
fi
old="${installed[0]%/Jellyfin.Plugin.GenreRows.dll}"
[[ "$old" =~ ^/config/plugins/GenreRows_[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo 'Percorso plugin precedente inatteso.' >&2; exit 1; }
old_version="${old##*_}"
backup="/config/GenreRows-backup-$old_version-$stamp"
for target in "$staging" "$backup"; do
  if podman exec "$container" test -e "$target"; then echo "Percorso già presente: $target. Nessuna sostituzione eseguita." >&2; exit 1; fi
done

# Copy and verify the new files before moving the current plugin out of plugins.
podman cp "$bundle" "$container:$staging"
podman exec -w "$staging" "$container" sha256sum --check SHA256SUMS
podman exec "$container" sh -c '
  mv -- "$1" "$2" || exit 1
  if ! mv -- "$3" "$4"; then
    mv -- "$2" "$1"
    exit 1
  fi
' sh "$old" "$backup" "$staging" "$destination"
echo "Versione precedente conservata in: $backup"
echo "Per ripristinarla: bash restore-previous-podman.sh $container $backup"
if ! podman restart --time 30 "$container"; then
  echo 'Il riavvio non è riuscito: provo ad avviare il container.' >&2
  [[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || podman start "$container" || { echo "Avvio fallito. Ripristino: bash restore-previous-podman.sh $container $backup" >&2; exit 1; }
fi
sleep 3
if [[ "$(podman inspect --format '{{.State.Running}}' "$container")" != true ]]; then
  echo 'Il container si è fermato durante il riavvio: provo un avvio esplicito.' >&2
  [[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || podman start "$container" || { echo "Avvio fallito. Ripristino: bash restore-previous-podman.sh $container $backup" >&2; exit 1; }
fi
sleep 2
[[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || { echo "Il container non resta avviato. Log: podman logs --tail 80 $container. Ripristino: bash restore-previous-podman.sh $container $backup" >&2; exit 1; }
echo 'Genre Rows 1.4.6 installato. Ricarica Jellyfin con Ctrl+F5.'
