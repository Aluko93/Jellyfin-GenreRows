#!/usr/bin/env bash
set -euo pipefail
container="${1:-jellyfin}"
source_dir=/config/plugins/GenreRows_1.4.6.0
backup_dir="/config/GenreRows-disabled-$(date -u +%Y%m%dT%H%M%SZ)"
[[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || { echo 'Container fermo: usa il ripristino offline descritto nel README.' >&2; exit 1; }
podman exec "$container" test -d "$source_dir"
if podman exec "$container" test -e "$backup_dir"; then echo 'Backup già presente; riprova tra un secondo.' >&2; exit 1; fi
# Move outside plugins before restarting: nothing is deleted, including settings.
podman exec "$container" mv -- "$source_dir" "$backup_dir"
podman restart --time 30 "$container"
echo "Plugin disattivato e conservato in $backup_dir. Ricarica il browser."
