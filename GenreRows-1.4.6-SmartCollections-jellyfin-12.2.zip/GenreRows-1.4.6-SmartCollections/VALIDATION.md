# Verification — GenreRows 1.4.6 ActorFlix grouping — 2026-11-01

- Release build using existing official Jellyfin 12.2.0 packages / net10.0: 0 errors, 0 warnings.
- Actor cache/native API/popularity and grouping fixture: 55 checks passed. Includes a real service fixture with 186 matching episode records, series/movies, local seasons and a forbidden parent. Verified one series card per source page, existing parent poster tags, raw-credit pagination, matching versus available seasons, exclusion of hidden seasons/parents and unauthorized library rejection. Existing actor discovery, policy/cache separation, native favorites, authentication and popularity-cache checks remain enabled.
- Existing ActorFlix Chromium suite: 13 groups passed with the grouped-title response shape.
- New grouped-series Chromium suite: 6 groups passed. Separate Movies/TV groups, one card per series across pages/libraries, no episode cards, partial/all-local-season labels, unknown coverage, specials, stable series poster nodes, native details, retained filters, narrow layout/Back focus and all six new label translations.
- Screenshot inspected with synthetic posters. Archive/hash/version checks are recorded in ARCHIVE-VERIFICATION.txt.

Production changes are limited to ActorsCatalogService.cs and Web/actors.js plus assembly-version metadata. All Adult, Smart Collections, ordinary-row/configuration, controller and integration files were compared byte for byte against 1.4.5 and are unchanged. Previous source and release archives are preserved.

Limits: this release was not installed on production, a physical TV or a complete Jellyfin database. Repository behavior is represented by actual Jellyfin interfaces/entities with fixture implementations. Season coverage describes credits and authorized seasons currently present in local metadata, not a verified worldwide acting history. Series-level cast records without episode credits do not infer seasons. Season metadata queries are capped at 1,024 records per source page; incomplete coverage is marked unknown. Missing parent IDs/unauthorized parent metadata cannot produce a series card.

The unchanged Smart Collections, ordinary-row, Adult/FFmpeg and live TMDB-download suites were not rerun for this targeted change; their earlier results must not be counted as newly executed 1.4.6 checks. Other Jellyfin versions were not tested.
