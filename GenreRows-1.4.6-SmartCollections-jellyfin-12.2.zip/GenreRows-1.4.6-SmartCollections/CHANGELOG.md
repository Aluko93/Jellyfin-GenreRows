# Changelog

## 1.4.6 — 2026-11-01

- Split actor filmographies into Movies and TV series.
- Fold episode credits into one series card with its existing series poster and standard details link.
- Merge matching seasons across source pages/libraries; show compact labels for partial local season coverage and specials.
- Resolve parent series and available seasons through user/library-scoped queries.
- Preserve filters, sorting, recent movies, favorites, focus and decoded poster nodes.
- Translate Movies/TV/Season labels in all six module languages.
- Keep ordinary rows, Adult, Smart Collections, configuration and the 1.4.5 loading/placement fixes unchanged.

## 1.4.5 — 2026-11-01

- Fix missing Smart Collections covers by requesting Primary image metadata rather than StoredColumnsOnly.
- Reduce simple-rule queries to the requested result count.
- Load Home cards in batches of 12 and nearby artwork with at most four simultaneous image requests.
- Preserve complete rows and decoded artwork during refresh; reuse the ordinary 2:3 poster geometry.
- Add a direct horizontal remote-navigation path and display ratings with one decimal place.
- Place Smart Collections after genre rows and immediately before Actors; keep Adult last, including late section arrivals.
- Keep existing configuration and all non-Smart production modules unchanged.

## 1.4.4 — 2026-11-01

- Add optional Smart Collections with an administrator Dashboard, live normal-library Home rows and paged collection views.
- Combine actor AND, genre, production-year range, rating, played status, audio language and 4K criteria.
- Add current-user and aggregate current-server-user unplayed rules, local actor picker, genre suggestions, unsaved preview and per-collection sorting/row limits.
- Refresh visible Home results and definitions every minute, preserve existing card/image nodes, support keyboard/remote navigation and six languages.
- Preserve existing configuration and all Adult/ActorFlix/ordinary-row implementation files.
- Keep Jellyfin 12.2.0 / net10.0 target and the existing plugin GUID; default module state is disabled.

## 1.4.3 — 2026-11-01

- Fix ActorFlix flashing: keyed card/image reuse, stable exposed order, throttled background metadata updates and lazy portrait loading.
- Show 30 actor cards first; append 30 on navigation/More. Publish an initial 30-actor server snapshot during a cold build.
- Keep gallery position/focus across catalog and popularity revisions; explicit sorting applies fresh Discover scores.
- Enlarge selected portraits by 25% over 250 ms, with reserved space and a soft theme-colored underglow.
- Add title/year/rating ordering to actor profiles, preserving the six existing interface languages.
- Prefer different films/series in the first 15 cards of genre rows, retaining repetitions later and gracefully handling limited libraries.
- Preserve Adult implementation, configuration, plugin GUID and Jellyfin 12.2.0 target.

# GenreRows 1.4.2 — ActorFlix

- Default Discover ranking: popularity, actual movie counts and controlled daily variety.
- Optional public TMDB export with server-side weekly caching, no API key and local/offline fallback.
- Dedicated actor profiles with local biography, native per-user favorites, recent movies, genre/year filters and standard Jellyfin details links.
- Bottom-gradient portraits and subtle focus/hover glow.
- Preserve explicit search activation, bounded lazy portrait rendering and TV focus restoration.
- Lightweight title scans; cached actor counts exclude duplicate roles and episode inflation.
- Preserve 1.4.1 private-media behavior, matching per-video covers and ordinary genre rows.
