#!/usr/bin/env bash
set -euo pipefail
container="${1:-jellyfin}"
backup="${2:?Specifica il percorso di backup stampato durante l aggiornamento}"
[[ "$backup" =~ ^/config/GenreRows-backup-([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)-[0-9]{8}T[0-9]{6}Z-[0-9]+$ ]] || { echo 'Percorso di backup non valido.' >&2; exit 1; }
old_version="${BASH_REMATCH[1]}"
current=/config/plugins/GenreRows_1.4.6.0
old="/config/plugins/GenreRows_$old_version"
disabled="/config/GenreRows-disabled-1.4.6.0-$(date -u +%Y%m%dT%H%M%SZ)-$$"
podman exec "$container" test -f "$backup/Jellyfin.Plugin.GenreRows.dll"
podman exec "$container" test -d "$current"
podman exec "$container" test ! -e "$old"
podman exec "$container" test ! -e "$disabled"
podman exec "$container" sh -c '
  mv -- "$1" "$2" || exit 1
  if ! mv -- "$3" "$4"; then mv -- "$2" "$1"; exit 1; fi
' sh "$current" "$disabled" "$backup" "$old"
podman restart --time 30 "$container"
echo 'Versione precedente ripristinata. Ricarica il browser con Ctrl+F5.'
