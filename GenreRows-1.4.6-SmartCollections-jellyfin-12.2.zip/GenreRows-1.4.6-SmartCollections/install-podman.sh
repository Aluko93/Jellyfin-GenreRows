#!/usr/bin/env bash
set -euo pipefail
container="${1:-jellyfin}"
here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bundle="$here/package/GenreRows_1.4.6.0"
destination=/config/plugins/GenreRows_1.4.6.0
command -v podman >/dev/null
[[ -f "$bundle/Jellyfin.Plugin.GenreRows.dll" ]] || { echo 'DLL assente: estrai tutto lo ZIP.' >&2; exit 1; }
(cd "$bundle" && sha256sum --check SHA256SUMS)
[[ "$(podman inspect --format '{{.State.Running}}' "$container")" == true ]] || { echo 'Il container deve essere avviato per i controlli preliminari.' >&2; exit 1; }
# Jellyfin's command-line parser can report --version on stderr and exit 1.
# Capture both streams without letting set -e abort; validate the exact banner.
version_status=0
version="$(podman exec "$container" /jellyfin/jellyfin --version 2>&1)" || version_status=$?
version="${version//$'\r'/}"
[[ "$version" =~ ^Jellyfin\.Server[[:space:]]+12\.2\.0(\.0)?[[:space:]]*$ ]] || {
  echo "Versione non supportata/non verificata (uscita $version_status): $version" >&2; exit 1;
}
podman exec "$container" test -d /config/plugins
if podman exec "$container" test -e "$destination"; then
  echo 'La cartella GenreRows esiste già. Nessuna sovrascrittura eseguita.' >&2; exit 1
fi
existing="$(podman exec "$container" find /config/plugins -name Jellyfin.Plugin.GenreRows.dll -print)"
[[ -z "$existing" ]] || { echo 'Esiste già una DLL GenreRows: rimuovi prima la vecchia installazione.' >&2; exit 1; }
echo 'Controlli completati. Arresto temporaneo di Jellyfin e installazione Genre Rows.'
stopped=0
trap 'if [[ "$stopped" == 1 ]]; then podman start "$container" >/dev/null || true; fi' EXIT
podman stop "$container"
stopped=1
podman cp "$bundle" "$container:/config/plugins/"
podman start "$container"
stopped=0
echo 'Copia completata. Verifica caricamento nei log e Dashboard > Plugin > Genre Rows.'
echo "Log: podman logs --since 2m $container"
echo "Rollback: bash rollback-podman.sh $container"
