using System.Reflection;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Net.Http.Json;
using System.Text.Json;
using Jellyfin.Plugin.GenreRows;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Model.Serialization;
using Jellyfin.Plugin.GenreRows.Adult;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Entities;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.Options;

int checks = 0;
void Check(bool ok, string name) { if (!ok) throw new Exception(name); checks++; Console.WriteLine("PASS " + name); }
void Denied(Action action, string name) { try { action(); } catch (IOException) { Check(true, name); return; } throw new Exception(name); }
var numericProbe = AdultThumbnailService.ParseMediaInfo("""{"format":{"duration":123.5,"format_name":"matroska,webm"},"streams":[{"index":0,"codec_type":"video","codec_name":"h264"},{"index":1,"codec_type":"audio","codec_name":"aac","tags":{"language":"ita","title":"Italiano"}}]}""");
Check(numericProbe.DurationSeconds == 123.5 && numericProbe.Container == "matroska,webm" && numericProbe.VideoCodec == "h264" && numericProbe.AudioTracks.Single().Codec == "aac", "ffprobe numeric duration and track metadata parse correctly");
var stringProbe = AdultThumbnailService.ParseMediaInfo("""{"format":{"duration":"42.25","format_name":"mov,mp4"},"streams":[]}""");
Check(stringProbe.DurationSeconds == 42.25, "ffprobe string duration remains supported");
var clock = new TestClock(); var auth = new AdultAuthService(clock); var user = Guid.NewGuid();
var cfg = new AdultConfiguration { Enabled = true, AllowedUserIds = [user.ToString()], IdleMinutes = 1, PasswordHash = AdultAuthService.HashPassword("test-secret-123") };
Check(!cfg.PasswordHash.Contains("test-secret"), "password salted and hashed");
var legacySalt=System.Security.Cryptography.RandomNumberGenerator.GetBytes(32);
var legacyHash="210000:"+Convert.ToBase64String(legacySalt)+":"+Convert.ToBase64String(System.Security.Cryptography.Rfc2898DeriveBytes.Pbkdf2("legacy-test",legacySalt,210000,System.Security.Cryptography.HashAlgorithmName.SHA256,32));
Check(AdultAuthService.Verify("legacy-test",legacyHash),"1.3.2 password hash remains accepted after upgrade");
Check(AdultAuthService.Verify("test-secret-123", cfg.PasswordHash) && !AdultAuthService.Verify("wrong", cfg.PasswordHash), "password verification");
Check(!AdultAuthService.Verify("x", "broken"), "malformed hash denied");
Check(auth.Unlock(cfg, Guid.NewGuid(), "login", "test-secret-123") is not null, "any authenticated Jellyfin user can unlock with the shared password");
cfg.HomeVisibility = "SelectedUsers"; cfg.AllowedUserIds = [user.ToString()];
Check(AdultAuthService.Allowed(cfg, user) && !AdultAuthService.Allowed(cfg, Guid.NewGuid()), "selected Jellyfin user restriction is enforced server-side");
Check(!AdultAuthService.ShowHomeCard(new AdultConfiguration { Enabled = true, HomeVisibility = "Hidden" }, user), "hidden Home card remains hidden");
cfg.HomeVisibility = "AllUsers"; cfg.AllowedUserIds = [];
Check(auth.Unlock(cfg, user, "login", "bad") is null, "wrong password denied");
var token = auth.Unlock(cfg, user, "login", "test-secret-123")!;
var playTicket = AdultPlaybackService.Create(token, user, "login", "category", "video.mkv");
Check(playTicket.Length == 64 && AdultPlaybackService.Find(playTicket)?.Video == "video.mkv" && playTicket != token, "playback ticket is distinct from Adult token");
AdultPlaybackService.Revoke(playTicket); Check(AdultPlaybackService.Find(playTicket) is null, "playback ticket revocation");
Check(token.Length == 64 && auth.Validate(cfg, user, "login", token), "temporary server session");
Check(!auth.Validate(cfg, user, "other-login", token), "session cannot move to another Jellyfin login");
token = auth.Unlock(cfg, user, "login", "test-secret-123")!;
Check(!auth.Validate(cfg, Guid.NewGuid(), "login", token), "session cannot move to another user");
token = auth.Unlock(cfg, user, "login", "test-secret-123")!; auth.Lock(token);
Check(!auth.Validate(cfg, user, "login", token), "explicit lock invalidates server token");
clock.Advance(61); token = auth.Unlock(cfg, user, "login", "test-secret-123")!; clock.Advance(9);
Check(!auth.Validate(cfg, user, "login", token), "lost browser or network expires within 8 seconds");
token = auth.Unlock(cfg, user, "login", "test-secret-123")!;
for (int i = 0; i < 9; i++) { clock.Advance(6); Check(auth.Validate(cfg, user, "login", token, true), "heartbeat lease " + i); }
clock.Advance(6); Check(!auth.Validate(cfg, user, "login", token, true), "heartbeats alone do not renew idle timeout");
token = auth.Unlock(cfg, user, "login", "test-secret-123")!;
clock.Advance(5); Check(auth.Validate(cfg, user, "login", token, true, true), "real activity refreshes inactivity timer");
cfg.RootPath = "changed"; Check(!auth.Validate(cfg, user, "login", token), "configuration changes invalidate sessions");
token = auth.Unlock(cfg, user, "login", "test-secret-123")!; cfg.Enabled = false;
Check(!auth.Validate(cfg, user, "login", token), "disabled module denies existing session"); cfg.Enabled = true;
clock.Advance(61); token = auth.Unlock(cfg, user, "login", "test-secret-123")!;
Check(!new AdultAuthService(clock).Validate(cfg, user, "login", token), "restart forgets sessions");
var replacement = auth.Unlock(cfg, user, "login", "test-secret-123")!;
Check(!auth.Validate(cfg, user, "login", token) && auth.Validate(cfg, user, "login", replacement), "new tab replaces old Adult session");
auth.LockAll(); Check(!auth.Validate(cfg, user, "login", replacement), "admin save revokes all sessions");
clock.Advance(61); var throttle = new AdultAuthService(clock);
for (int i = 0; i < 5; i++) throttle.Unlock(cfg, user, "login", "wrong");
Check(throttle.Unlock(cfg, user, "login", "test-secret-123") is null, "five attempts per minute rate limit");
clock.Advance(61); Check(throttle.Unlock(cfg, user, "login", "test-secret-123") is not null, "rate limit recovery");

var temp = Path.Combine(Environment.GetEnvironmentVariable("GR_TEST_TEMP") ?? Path.GetTempPath(), "gr-adult-tests-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(temp);
try {
    var adult = Path.Combine(temp, "ADULTI"); var normal = Path.Combine(temp, "Normal"); Directory.CreateDirectory(adult); Directory.CreateDirectory(normal);
    var cat = Path.Combine(adult, "Categoria test"); Directory.CreateDirectory(cat);
    File.WriteAllText(Path.Combine(cat, "TEST_VIDEO_001.mkv"), "not actual media");
    File.WriteAllText(Path.Combine(cat, "ignore.txt"), "test"); File.WriteAllBytes(Path.Combine(cat, "folder.jpg"), [0xff, 0xd8, 0xff, 0xd9]);
    File.WriteAllBytes(Path.Combine(cat, "personalizzata.png"), [137,80,78,71,13,10,26,10]);
    File.WriteAllBytes(Path.Combine(adult, "home.webp"), [82,73,70,70,0,0,0,0,87,69,66,80]);
    var lib = DispatchProxy.Create<ILibraryManager, LibraryProxy>();
    ((LibraryProxy)(object)lib).Paths = [normal]; var files = new AdultLibraryService(lib); cfg.RootPath = adult;
    cfg.HomeTitle = "Riservato"; cfg.HomeDescription = "Descrizione home"; cfg.HomeImageFile = "home.webp";
    cfg.Categories = [new() { FolderName = "Categoria test", Title = "Titolo scelto", Description = "Descrizione scelta", ImageFile = "personalizzata.png" }];
    Check(files.Categories(cfg).Length == 1 && files.Videos(cfg, "Categoria test").Length == 1, "categories and video allowlist from external filesystem");
    var categoryJson = JsonSerializer.Serialize(files.Categories(cfg));
    Check(categoryJson.Contains("Titolo scelto") && categoryJson.Contains("Descrizione scelta"), "custom category title and description");
    Check(files.Cover(cfg, "Categoria test").ContentType == "image/png", "custom optional category PNG");
    cfg.Categories = [];
    Check(files.Cover(cfg, "Categoria test").ContentType == "image/jpeg", "automatic category cover fallback to folder image");
    File.WriteAllBytes(Path.Combine(cat, "cover.webp"), [82,73,70,70,0,0,0,0,87,69,66,80]);
    Check(files.Cover(cfg, "Categoria test").ContentType == "image/webp", "automatic cover.* image takes priority and supports WebP");
    Check(Path.GetFullPath(files.VideoFile(cfg, "Categoria test", "TEST_VIDEO_001.mkv")) == Path.GetFullPath(Path.Combine(cat, "TEST_VIDEO_001.mkv")), "video thumbnail path restricted to category files");
    Denied(() => files.VideoFile(cfg, "Categoria test", "../Normal/ignore.txt"), "thumbnail traversal denied");
    Check(files.CustomHomeCover(cfg)?.ContentType == "image/webp", "replaceable Home cover WebP");
    foreach (var name in new[] { "..", "../Normal", "..\\Normal", "/root", "C:secret", ".", "x\0y" })
        Denied(() => files.Videos(cfg, name), "traversal denied: " + name.Replace('\0', '?'));
    Check(AdultLibraryService.Overlaps(adult, temp) && AdultLibraryService.Overlaps(temp, adult) && !AdultLibraryService.Overlaps(adult, adult + "-other"), "path boundary and overlap checks");
    ((LibraryProxy)(object)lib).Paths = [temp]; Denied(() => files.Root(cfg), "Adult child of Jellyfin library denied");
    ((LibraryProxy)(object)lib).Paths = [cat]; Denied(() => files.Root(cfg), "Adult parent of Jellyfin library denied");
    File.Delete(Path.Combine(cat, "cover.webp"));
    ((LibraryProxy)(object)lib).Paths = [normal]; var savedCategories = cfg.Categories; cfg.Categories = [];
    File.WriteAllText(Path.Combine(cat, "folder.jpg"), "not jpeg"); Denied(() => files.Cover(cfg, "Categoria test"), "non-JPEG cover denied"); cfg.Categories = savedCategories;
    var coverVideo = files.VideoFile(cfg, "Categoria test", "TEST_VIDEO_001.mkv");
    var coverStem = Path.Combine(cat, "TEST_VIDEO_001");
    Check(AdultLibraryService.CustomVideoCover(coverVideo) is null, "unrelated category images are not used as a video poster");
    File.WriteAllBytes(coverStem + ".jpg", [255,216,255,217]);
    Check(AdultLibraryService.CustomVideoCover(coverVideo)?.ContentType == "image/jpeg", "matching basename JPG overrides the generated video thumbnail");
    File.WriteAllBytes(coverStem + ".png", [137,80,78,71,13,10,26,10]);
    Check(AdultLibraryService.CustomVideoCover(coverVideo)?.ContentType == "image/jpeg", "multiple matching images have deterministic JPG-before-PNG priority");
    File.WriteAllText(coverStem + ".jpg", "invalid image");
    Check(AdultLibraryService.CustomVideoCover(coverVideo)?.ContentType == "image/png", "corrupt preferred poster falls through to the next valid matching image");
    File.Delete(coverStem + ".jpg"); File.Delete(coverStem + ".png");
    File.WriteAllBytes(coverStem + ".WEBP", [82,73,70,70,0,0,0,0,87,69,66,80]);
    Check(AdultLibraryService.CustomVideoCover(coverVideo)?.ContentType == "image/webp", "matching WebP with uppercase extension is supported");
    File.Delete(coverStem + ".WEBP"); File.WriteAllBytes(coverStem + " extra.png", [137,80,78,71,13,10,26,10]);
    File.WriteAllText(coverStem + ".svg", "<svg/>");
    Check(AdultLibraryService.CustomVideoCover(coverVideo) is null, "prefix matches and SVG files do not override a video poster");
    File.Delete(coverStem + " extra.png"); File.Delete(coverStem + ".svg");
    using(var large = File.Create(coverStem + ".png")) large.SetLength(8 * 1024 * 1024 + 1);
    Check(AdultLibraryService.CustomVideoCover(coverVideo) is null, "oversized custom posters retain the automatic-thumbnail fallback");
    File.WriteAllBytes(coverStem + ".png", [137,80,78,71,13,10,26,10,1]);
    Check(AdultLibraryService.CustomVideoCover(coverVideo)?.Bytes.Last() == 1, "adding or replacing a poster is read immediately without a thumbnail-cache rebuild");
    File.Delete(coverStem + ".png");
    var outsidePoster = Path.Combine(normal, "private.png"); File.WriteAllBytes(outsidePoster, [137,80,78,71,13,10,26,10]);
    try { File.CreateSymbolicLink(coverStem + ".png", outsidePoster);
        Check(AdultLibraryService.CustomVideoCover(coverVideo) is null, "symlink poster cannot expose an image outside its category");
    } catch (Exception e) when(e is UnauthorizedAccessException or IOException or PlatformNotSupportedException) { Console.WriteLine("SKIP poster symlink fixture: OS permission unavailable"); }
    finally { if(File.Exists(coverStem + ".png"))File.Delete(coverStem + ".png"); }
    if (args.Contains("--unit-only", StringComparer.Ordinal)) {
        Console.WriteLine($"SUCCESS {checks} Adult unit/security checks (unit-only mode)");
        return;
    }
    var builder = WebApplication.CreateBuilder(); builder.Logging.ClearProviders(); builder.WebHost.UseUrls("http://127.0.0.1:0");
    var users = DispatchProxy.Create<IUserManager, UserManagerProxy>(); builder.Services.AddSingleton(users);
    builder.Services.AddHostedService<AdultPlaybackReaper>(); builder.Services.AddSingleton(lib); builder.Services.AddAuthentication("fixture").AddScheme<AuthenticationSchemeOptions, FixtureAuthentication>("fixture", _ => {});
    builder.Services.AddAuthorization(o => o.AddPolicy("RequiresElevation", p => p.RequireRole("Admin")));
    builder.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions.PropertyNamingPolicy = null).AddApplicationPart(typeof(AdultController).Assembly);
    await using var app = builder.Build(); app.UseAuthentication(); app.UseAuthorization(); app.MapControllers(); app.MapGet("/web/index.html", () => Results.Content("<html lang=\"it\"><div id=\"homeTab\"></div></html>", "text/html")); await app.StartAsync();
    var address = app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single();
    using var client = new HttpClient(new HttpClientHandler { UseProxy = false, CookieContainer = new System.Net.CookieContainer() }) { BaseAddress = new Uri(address) };
    foreach (var route in new[] { "Status", "HomeCover", "Categories", "Videos?category=x", "Cover?category=x", "Thumbnail?category=x&video=x.mkv", "Configuration" }) {
        var r = await client.GetAsync("GenreRows/Adult/" + route); Check((int)r.StatusCode == 401, "anonymous HTTP denied " + route);
    }
    Check((int)(await client.GetAsync("GenreRows/Actors/Status")).StatusCode==401,"Actors status requires Jellyfin authentication");
Check((int)(await client.GetAsync("GenreRows/Actors/Catalog")).StatusCode==401,"actor disk cache is not an anonymous metadata endpoint");
client.DefaultRequestHeaders.Add("X-Fixture-User", user.ToString());
Check((int)(await client.PostAsync("GenreRows/Actors/Refresh",null)).StatusCode==403,"only administrators may invalidate the server catalog cache");
Check((int)(await client.PostAsJsonAsync("GenreRows/Actors/Configuration",new{Enabled=true})).StatusCode==403,"Actors configuration requires administrator");
    foreach (var route in new[] { "Categories", "Videos?category=x", "Cover?category=x", "Thumbnail?category=x&video=x.mkv", "Configuration" }) {
        var r = await client.GetAsync("GenreRows/Adult/" + route); Check((int)r.StatusCode == 403, "ordinary/locked HTTP denied " + route);
        if (route != "Configuration") Check(r.Headers.CacheControl?.NoStore == true, "sensitive response no-store " + route);
    }
    var settings = await client.GetStringAsync("GenreRows/Settings"); Check(!settings.Contains("PasswordHash") && !settings.Contains("RootPath") && !settings.Contains("AllowedUserIds"), "normal settings disclose no Adult config");
    var script = await client.GetStringAsync("GenreRows/client.js"); Check(script.Contains("__grAdultLoaded") && script.Contains("__genreRowsLoaded"), "same client loader contains both isolated modules");
    Check((int)(await client.GetAsync("GenreRows/Adult/Playback/Stream")).StatusCode == 403, "anonymous playback denied without ticket");
    var paths = DispatchProxy.Create<IApplicationPaths, PathsProxy>(); ((PathsProxy)(object)paths).Root = temp;
    var serializer = DispatchProxy.Create<IXmlSerializer, SerializerProxy>();
    cfg.Categories = [new() { FolderName = "Categoria test", Title = "Titolo HTTP", ImageFile = "personalizzata.png" }];
    var plugin = new Plugin(paths, serializer); plugin.UpdateConfiguration(new Configuration { Adult = cfg });
    File.WriteAllBytes(Path.Combine(cat, "personalizzata.png"), [137,80,78,71,13,10,26,10]);
    client.DefaultRequestHeaders.Add("Authorization", "MediaBrowser Client=\"GenreRows Test\", Device=\"Test\", DeviceId=\"GenreRowsTest\", Version=\"1.4.1\", Token=\"fixture-jellyfin-login\"");
    var homeStatus = await client.GetStringAsync("GenreRows/Adult/Status");
    Check(homeStatus.Contains("Riservato") && homeStatus.Contains("Descrizione home"), "HTTP personalized Home presentation");
    var homeImage = await client.GetAsync("GenreRows/Adult/HomeCover"); Check(homeImage.IsSuccessStatusCode && homeImage.Content.Headers.ContentType?.MediaType == "image/webp", "HTTP replaceable Home image");
    var unlocked = await client.PostAsJsonAsync("GenreRows/Adult/Unlock", new { Password = "test-secret-123" });
    Check(unlocked.IsSuccessStatusCode, "HTTP password unlock with authenticated identity");
    var result = await unlocked.Content.ReadFromJsonAsync<JsonElement>(); var httpToken = result.GetProperty("Token").GetString();
    client.DefaultRequestHeaders.Add("X-Adult-Session", httpToken);
    var categoryResponse = await client.GetAsync("GenreRows/Adult/Categories");
    Check(categoryResponse.IsSuccessStatusCode && (await categoryResponse.Content.ReadAsStringAsync()).Contains("Categoria test"), "HTTP unlocked categories");
    var videoResponse = await client.GetStringAsync("GenreRows/Adult/Videos?category=Categoria%20test");
    Check(videoResponse.Contains("TEST_VIDEO_001.mkv") && !videoResponse.Contains(temp) && !videoResponse.Contains("ignore.txt"), "HTTP video names only, no paths or non-video files");
    var customCover = await client.GetAsync("GenreRows/Adult/Cover?category=Categoria%20test");
    Check(customCover.IsSuccessStatusCode && customCover.Content.Headers.ContentType?.MediaType == "image/png", "HTTP optional personalized category image behind valid session");
    var sidecar = Path.Combine(cat, "TEST_VIDEO_001.png");
    var customPosterBytes = Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=");
    File.WriteAllBytes(sidecar, customPosterBytes);
    const string posterUrl = "GenreRows/Adult/Thumbnail?category=Categoria%20test&video=TEST_VIDEO_001.mkv";
    var posterResponse = await client.GetAsync(posterUrl);
    Check(posterResponse.IsSuccessStatusCode && posterResponse.Content.Headers.ContentType?.MediaType == "image/png" && (await posterResponse.Content.ReadAsByteArrayAsync()).SequenceEqual(customPosterBytes), "HTTP custom PNG poster served without FFmpeg even for an unplayable test video");
    Check(posterResponse.Headers.CacheControl?.NoStore == true && posterResponse.Headers.GetValues("X-Content-Type-Options").Contains("nosniff"), "custom poster retains private no-store and nosniff headers");
    client.DefaultRequestHeaders.Remove("X-Adult-Session");
    Check((int)(await client.GetAsync(posterUrl)).StatusCode == 403, "custom video poster denied without an Adult session");
    client.DefaultRequestHeaders.Add("X-Adult-Session", httpToken);
    File.WriteAllBytes(Path.Combine(cat, "GHOST.png"), customPosterBytes);
    Check((int)(await client.GetAsync("GenreRows/Adult/Thumbnail?category=Categoria%20test&video=GHOST.mkv")).StatusCode == 404, "an image without a real matching video is not exposed by the poster endpoint");
    File.Delete(Path.Combine(cat, "GHOST.png"));
    Check((int)(await client.GetAsync("GenreRows/Adult/Thumbnail?category=Categoria%20test&video=..%2FNormal%2Fprivate.png")).StatusCode == 404, "poster endpoint rejects filesystem traversal");
    File.Delete(sidecar);
    var openedPlayback = await client.PostAsJsonAsync("GenreRows/Adult/Playback/Open", new { Category = "Categoria test", Video = "TEST_VIDEO_001.mkv" });
    Check(openedPlayback.IsSuccessStatusCode && openedPlayback.Headers.TryGetValues("Set-Cookie", out var cookieValues) && cookieValues.Any(x => x.Contains("httponly", StringComparison.OrdinalIgnoreCase) && !x.Contains("TEST_VIDEO_001.mkv")), "playback issues HttpOnly ticket without file path in cookie URL");
    client.DefaultRequestHeaders.Range = new System.Net.Http.Headers.RangeHeaderValue(0, 3);
    var range = await client.GetAsync("GenreRows/Adult/Playback/Stream");
    Check((int)range.StatusCode == 206 && range.Content.Headers.ContentRange?.From == 0 && (await range.Content.ReadAsByteArrayAsync()).Length == 4, "protected playback supports HTTP Range seeking");
    client.DefaultRequestHeaders.Range = null;
    // If FFmpeg is installed, exercise the real HLS path using generated test media.
    var ffmpeg = Environment.GetEnvironmentVariable("GR_FFMPEG_PATH") ?? "ffmpeg";
    try {
        var generated = Path.Combine(cat, "TEST_VIDEO_001.mkv");
        var gen = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo { FileName = ffmpeg, UseShellExecute = false,
            RedirectStandardError = true, ArgumentList = { "-hide_banner", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "testsrc=size=320x180:rate=12", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100", "-t", "12", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", generated } });
        if (gen is not null) { await gen.WaitForExitAsync(); if (gen.ExitCode == 0) {
            var jpeg = await AdultThumbnailService.GetOrCreateAsync(generated,CancellationToken.None);Check(jpeg.Length>4 && jpeg[0]==255 && jpeg[1]==216,"real FFmpeg thumbnail extraction");
            var automaticPoster = await client.GetAsync(posterUrl);
            Check(automaticPoster.IsSuccessStatusCode && automaticPoster.Content.Headers.ContentType?.MediaType == "image/jpeg" && (await automaticPoster.Content.ReadAsByteArrayAsync()).Length > 4, "HTTP poster falls back to the existing generated JPEG when the custom image is removed");
await File.WriteAllTextAsync(Path.Combine(cat, "TEST_VIDEO_001.srt"), "1\n00:00:00,000 --> 00:00:01,000\nSubtitle test\n");
            var open = await client.PostAsJsonAsync("GenreRows/Adult/Playback/Open", new { Category = "Categoria test", Video = "TEST_VIDEO_001.mkv" }); Check(open.IsSuccessStatusCode, "FFmpeg test media opens behind Adult session");
            var audio = await open.Content.ReadFromJsonAsync<JsonElement>(); var audioIndex = audio.GetProperty("AudioTracks")[0].GetProperty("Index").GetInt32();
            Check(audio.GetProperty("SubtitleTracks").EnumerateArray().Any(x => x.GetProperty("Index").GetInt32() == -2), "adjacent external subtitle is discovered without exposing its path");
            var subtitle = await client.GetAsync("GenreRows/Adult/Playback/Subtitle/-2");
            Check(subtitle.IsSuccessStatusCode && (await subtitle.Content.ReadAsStringAsync()).Contains("Subtitle test"), "external SRT subtitle converted to WebVTT behind playback ticket");
            await client.PostAsJsonAsync("GenreRows/Adult/Heartbeat",new{Active=true});
var transcodeTask = client.PostAsJsonAsync("GenreRows/Adult/Playback/Transcode", new { AudioIndex = audioIndex });
            while(!transcodeTask.IsCompleted){await Task.Delay(1000);await client.PostAsJsonAsync("GenreRows/Adult/Heartbeat",new{Active=true});}
            var transcode = await transcodeTask; var transcodeError = await transcode.Content.ReadAsStringAsync(); Check(transcode.IsSuccessStatusCode, "FFmpeg transcode starts for unsupported media: " + (int)transcode.StatusCode + " " + transcodeError);
            var manifestUrl = (await transcode.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("ManifestUrl").GetString()!;
            var manifestResponse = await client.GetAsync(manifestUrl); var manifest = await manifestResponse.Content.ReadAsStringAsync();
            
Check(manifestResponse.IsSuccessStatusCode && manifest.Contains("#EXTM3U") && manifest.Contains("segment_"), "authenticated HLS manifest delivered: "+(int)manifestResponse.StatusCode+" "+manifest);
            var segment = manifest.Split('\n').Select(x => x.Trim()).FirstOrDefault(x => x.StartsWith("segment_", StringComparison.Ordinal));
            Check(segment is not null && (await client.GetAsync("GenreRows/Adult/Playback/Segment/" + segment)).IsSuccessStatusCode, "authenticated HLS segment delivered");
            await client.PostAsync("GenreRows/Adult/Lock", null);
            Check((int)(await client.GetAsync("GenreRows/Adult/Playback/Segment/" + segment)).StatusCode == 403, "HLS segment revoked after Adult lock");
Check(!Directory.EnumerateFiles(Path.Combine(plugin.DataFolderPath,"AdultPlayback"),"*",SearchOption.AllDirectories).Any(),"FFmpeg segment cache cleaned after lock");
            if (Environment.GetEnvironmentVariable("GR_BROWSER_TEST") is { } browserTest) {
                var browserMedia=Path.Combine(cat,"TEST_BROWSER.mp4");
                var mux=System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo{FileName=ffmpeg,UseShellExecute=false,ArgumentList={"-hide_banner","-loglevel","error","-y","-i",generated,"-map","0:v:0","-map","0:a:0","-map","0:a:0","-c","copy",browserMedia}})!;
                await mux.WaitForExitAsync(); Check(mux.ExitCode==0,"browser fixture with two audio tracks generated");
                File.Copy(Path.Combine(cat,"TEST_VIDEO_001.srt"),Path.Combine(cat,"TEST_BROWSER.srt"),true);
                var start=new System.Diagnostics.ProcessStartInfo{FileName="node",UseShellExecute=false};start.ArgumentList.Add(browserTest);
                start.Environment["GR_TEST_URL"]=address;start.Environment["GR_TEST_USER"]=Guid.NewGuid().ToString();
                var browser=System.Diagnostics.Process.Start(start)!;await browser.WaitForExitAsync();Check(browser.ExitCode==0,"real browser protected video playback suite");
            }
        } }
    } catch (System.ComponentModel.Win32Exception) { Console.WriteLine("SKIP FFmpeg HLS checks: ffmpeg not installed"); }
    client.DefaultRequestHeaders.Remove("X-Adult-Session");
    var resumedUnlock = await client.PostAsJsonAsync("GenreRows/Adult/Unlock", new { Password = "test-secret-123" });
    client.DefaultRequestHeaders.Add("X-Adult-Session", (await resumedUnlock.Content.ReadFromJsonAsync<JsonElement>()).GetProperty("Token").GetString());
    Check((int)(await client.GetAsync("GenreRows/Adult/Videos?category=..%2FNormal")).StatusCode == 404, "HTTP traversal rejected even after unlock");
    Check((await client.PostAsJsonAsync("GenreRows/Adult/Heartbeat", new { Active = true })).IsSuccessStatusCode, "HTTP valid heartbeat");
    Check((await client.PostAsync("GenreRows/Adult/Lock", null)).IsSuccessStatusCode, "HTTP server lock");
    Check((int)(await client.GetAsync("GenreRows/Adult/Categories")).StatusCode == 403, "HTTP old token denied after explicit lock");
    File.WriteAllBytes(sidecar, customPosterBytes);
    Check((int)(await client.GetAsync(posterUrl)).StatusCode == 403, "custom poster becomes inaccessible after Adult lock");
    Check((int)(await client.GetAsync("GenreRows/Adult/Playback/Stream")).StatusCode == 403, "playback stream revoked immediately after Adult lock");
    client.DefaultRequestHeaders.Remove("X-Adult-Session");
    client.DefaultRequestHeaders.Add("X-Fixture-Admin", "true");
    var adminConfig = await client.GetStringAsync("GenreRows/Adult/Configuration");
    Check(!adminConfig.Contains("210000:") && !adminConfig.Contains("test-secret-123"), "admin endpoint never returns password hash or password");
    var configured = await client.PostAsJsonAsync("GenreRows/Adult/Configuration", new { Enabled = true, RootPath = temp, AllowedUserIds = new[] { user.ToString() }, IdleMinutes = 5 });
    Check((int)configured.StatusCode == 400, "admin endpoint rejects overlapping root");
    configured = await client.PostAsJsonAsync("GenreRows/Adult/Configuration", new { Enabled = true, RootPath = adult, AllowedUserIds = new[] { user.ToString() }, IdleMinutes = 5, Password = "123" });
    Check((int)configured.StatusCode == 400, "admin endpoint rejects short PIN");
    configured = await client.PostAsJsonAsync("GenreRows/Adult/Configuration", new { Enabled = true, RootPath = adult, AllowedUserIds = new[] { user.ToString() }, IdleMinutes = 5, Password = "another-test-secret",
        HomeTitle = "Nuova Home", HomeDescription = "Testo personalizzato", HomeImageFile = "home.webp",
        Categories = new[] { new { FolderName = "Categoria test", Title = "Titolo nuovo", Description = "Descrizione nuova", ImageFile = "personalizzata.png" } } });
    Check(configured.IsSuccessStatusCode && plugin.Configuration.Adult.IdleMinutes == 5 && plugin.Configuration.Adult.HomeTitle == "Nuova Home" &&
        plugin.Configuration.Adult.Categories.Single().Description == "Descrizione nuova", "admin configuration saves custom Home and category metadata");
    var preservedAdult=plugin.Configuration.Adult; var preservedGroups=plugin.Configuration.Groups;
Check((await client.PostAsJsonAsync("GenreRows/Actors/Configuration",new{Enabled=true})).IsSuccessStatusCode,"administrator enables Actors");
Check(plugin.Configuration.ActorsEnabled && ReferenceEquals(preservedAdult,plugin.Configuration.Adult) && ReferenceEquals(preservedGroups,plugin.Configuration.Groups),"Actors configuration preserves Adult and genre settings");
await app.StopAsync();
} finally { Directory.Delete(temp, true); }
Console.WriteLine($"SUCCESS {checks} Adult security checks");

public sealed class TestClock : TimeProvider { private DateTimeOffset now = DateTimeOffset.UtcNow; public override DateTimeOffset GetUtcNow() => now; public void Advance(int seconds) => now = now.AddSeconds(seconds); }
public class LibraryProxy : DispatchProxy {
    public string[] Paths = [];
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) => targetMethod?.Name == "GetVirtualFolders" ? new List<VirtualFolderInfo> { new() { Locations = Paths } } : throw new NotSupportedException(targetMethod?.Name);
}
public class UserManagerProxy : DispatchProxy {
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) => targetMethod?.Name switch {
        "GetUsers" => Array.Empty<Jellyfin.Database.Implementations.Entities.User>(),
        "GetUserById" => null,
        _ => throw new NotSupportedException(targetMethod?.Name)
    };
}
public class PathsProxy : DispatchProxy {
    public string Root = "";
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) => targetMethod?.ReturnType == typeof(string) ? Root : null;
}
public class SerializerProxy : DispatchProxy {
    protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) => null;
}
public sealed class FixtureAuthentication(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder) : AuthenticationHandler<AuthenticationSchemeOptions>(options, logger, encoder) {
    protected override Task<AuthenticateResult> HandleAuthenticateAsync() {
        var user = Request.Headers["X-Fixture-User"].ToString();
        var claims = new List<Claim> { new("Jellyfin-UserId", user) };
        if (Request.Headers["X-Fixture-Admin"] == "true") claims.Add(new(ClaimTypes.Role, "Admin"));
        return Task.FromResult(Guid.TryParse(user, out _) ? AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(new ClaimsIdentity(claims, Scheme.Name)), Scheme.Name)) : AuthenticateResult.NoResult());
    }
}


