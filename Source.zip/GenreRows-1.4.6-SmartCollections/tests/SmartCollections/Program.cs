using System.Net.Http.Json;
using System.Reflection;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.Json;
using Jellyfin.Data.Enums;
using Jellyfin.Database.Implementations.Entities;
using Jellyfin.Database.Implementations.Enums;
using Jellyfin.Plugin.GenreRows;
using Jellyfin.Plugin.GenreRows.SmartCollections;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Controller.Drawing;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Entities.Movies;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Configuration;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Querying;
using MediaBrowser.Model.Serialization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.Options;

var checks=0;void Check(bool ok,string label){if(!ok)throw new Exception(label);checks++;Console.WriteLine("PASS "+label);}
var directory=Path.Combine(Environment.GetEnvironmentVariable("GR_TEST_TEMP")??Path.GetTempPath(),"smart-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(directory);
try{
 var paths=Proxy.Make<IApplicationPaths>((m,_)=>m.Name.StartsWith("get_")?directory:null);
 var plugin=new Plugin(paths,Proxy.Make<IXmlSerializer>((_,_)=>null));
 var configuration=new Configuration{ActorsEnabled=true,SchemaVersion=3,Groups=[new(){Name="Existing",Genres=["Drama"]}]};plugin.UpdateConfiguration(configuration);
 Check(!configuration.SmartCollections.Enabled&&configuration.SmartCollections.Collections.Length==0,"module is disabled with no collections by default");
 var a=new User("A","Default","Default"){Id=Guid.NewGuid()};var b=new User("B","Default","Default"){Id=Guid.NewGuid()};
 var folderA=new CollectionFolder{Id=Guid.NewGuid()};var folderB=new CollectionFolder{Id=Guid.NewGuid()};
 var root=new TestRoot();root.Folders[a.Id]=[folderA];root.Folders[b.Id]=[folderB];
 var actors=new[]{new Person{Id=Guid.NewGuid(),Name="Actor One"},new Person{Id=Guid.NewGuid(),Name="Actor Two"}};
 var played=new Dictionary<(Guid User,Guid Item),UserItemData>();
 var users=Proxy.Make<IUserManager>((m,args)=>m.Name switch{"GetUserById"=>new[]{a,b}.FirstOrDefault(u=>u.Id==(Guid)args[0]!),"GetUsers"=>new[]{a,b},"GetUserDto"=>new UserDto{Id=((User)args[0]!).Id,Policy=new(){EnableAllFolders=true}},_=>throw new Exception(m.Name)});
 var data=Proxy.Make<IUserDataManager>((m,args)=>m.Name=="GetUserDataBatch"?((IReadOnlyList<BaseItem>)args[0]!).ToDictionary(i=>i.Id,i=>played.GetValueOrDefault((((User)args[1]!).Id,i.Id))??new UserItemData{Key=i.Id.ToString("N")}):throw new Exception("Unexpected user-data write/query "+m.Name));
 var all=new List<TestItem>();
 for(int i=0;i<320;i++)all.Add(new(new Movie{Id=Guid.NewGuid(),Name="Film "+i.ToString("D3"),ProductionYear=2010+i%17,CommunityRating=i%11,DateCreated=DateTime.UtcNow.AddDays(-i),Genres=[i%2==0?"Science Fiction":"Drama"]},folderA.Id,i%3==0?[actors[0].Id,actors[1].Id]:[actors[0].Id],i%2==0?"ita":"eng",i%4==0));
 var foreign=new TestItem(new Movie{Id=Guid.NewGuid(),Name="Foreign",ProductionYear=2024,CommunityRating=10,Genres=["Science Fiction"]},folderB.Id,[actors[0].Id,actors[1].Id],"ita",true);all.Add(foreign);
 played[(b.Id,all[0].Item.Id)]=new UserItemData{Key="zero",Played=true,PlayCount=1};
 played[(a.Id,all[1].Item.Id)]=new UserItemData{Key="one",Played=true};
 played[(b.Id,all[2].Item.Id)]=new UserItemData{Key="two",Played=false,PlayCount=2};
 var access=new HashSet<InternalItemsQuery>();var itemCalls=0;var creditCalls=0;var emptyQueries=0;var queries=new List<InternalItemsQuery>();
 var library=Proxy.Make<ILibraryManager>((m,args)=>{
  if(m.Name.StartsWith("add_")||m.Name.StartsWith("remove_"))return null;
  if(m.Name=="GetUserRootFolder")return root;if(m.Name=="GetLibraryOptions")return new LibraryOptions{Enabled=true};
  if(m.Name=="GetItemById")return actors.FirstOrDefault(p=>p.Id==(Guid)args[0]!);
  if(m.Name=="GetPerson")return actors.FirstOrDefault(p=>p.Name==(string)args[0]!);
  if(m.Name=="ConfigureUserAccess"){var query=(InternalItemsQuery)args[0]!;if(query.User?.Id!=((User)args[1]!).Id)throw new Exception("Wrong user scope");access.Add(query);return null;}
  if(m.Name=="GetItemList"){
   var q=(InternalItemsQuery)args[0]!;var parents=(List<BaseItem>)args[1]!;if(parents.Count==0){emptyQueries++;throw new Exception("Global query");}
   if(!access.Contains(q)||q.User is null||parents.Any(p=>!root.Folders[q.User.Id].Any(f=>f.Id==p.Id))||q.IsVirtualItem!=false||q.IsMissing!=false||!(q.SourceTypes.SequenceEqual(new[]{SourceType.Library})||q.IncludeItemTypes.Length==3&&q.SourceTypes.Length==0)||q.Limit is <1 or >128||q.EnableTotalRecordCount)throw new Exception("Missing security or bounded query");
   itemCalls++;queries.Add(q);var selected=parents.Select(p=>p.Id).ToHashSet();
   var found=all.Where(x=>selected.Contains(x.Folder)&&q.IncludeItemTypes.Contains(BaseItemKind.Movie)&&(!q.Genres.Any()||x.Item.Genres.Intersect(q.Genres).Any())&&(!q.PersonIds.Any()||x.Actors.Intersect(q.PersonIds).Any())&&(!q.Years.Any()||q.Years.Contains(x.Item.ProductionYear??0))&&(!q.MinCommunityRating.HasValue||x.Item.CommunityRating>=q.MinCommunityRating)&&(!q.AudioLanguages.Any()||q.AudioLanguages.Contains(x.Audio))&&(q.Is4K!=true||x.FourK)&&(q.IsPlayed!=false||played.GetValueOrDefault((q.User.Id,x.Item.Id))?.Played!=true));
   found=q.OrderBy[0].OrderBy switch{ItemSortBy.SortName=>found.OrderBy(x=>x.Item.Name),ItemSortBy.CommunityRating=>found.OrderByDescending(x=>x.Item.CommunityRating).ThenBy(x=>x.Item.Name),ItemSortBy.ProductionYear=>found.OrderByDescending(x=>x.Item.ProductionYear).ThenBy(x=>x.Item.Name),_=>found.OrderByDescending(x=>x.Item.DateCreated).ThenBy(x=>x.Item.Name)};
   return found.Skip(q.StartIndex??0).Take(q.Limit??128).Select(x=>{var item=new Movie{Id=x.Item.Id,Name=x.Item.Name,ProductionYear=x.Item.ProductionYear,CommunityRating=x.Item.CommunityRating,DateCreated=x.Item.DateCreated,Genres=x.Item.Genres};if(q.DtoOptions.GetImageLimit(ImageType.Primary)>0)item.ImageInfos=[new ItemImageInfo{Path="fixture-cover.jpg",Type=ImageType.Primary}];return (BaseItem)item;}).ToArray();
  }
  if(m.Name=="GetPeopleNamesByItems"){creditCalls++;var ids=(IReadOnlyList<Guid>)args[0]!;if(ids.Count==0||ids.Count>128)throw new Exception("Unbounded credits");return all.Where(x=>ids.Contains(x.Item.Id)).ToDictionary(x=>x.Item.Id,x=>(IReadOnlyList<string>)actors.Where(p=>x.Actors.Contains(p.Id)).Select(p=>p.Name).ToArray());}
  throw new Exception("Unexpected library write/query "+m.Name);
 });
 var service=new SmartService(library,users,data,Proxy.Make<IImageProcessor>((m,args)=>m.Name=="GetImageCacheTag"?"fixture-primary-tag":throw new Exception(m.Name)));
 SmartCollection Rule()=>new(){Id=Guid.NewGuid().ToString("N"),Name="Test collection"};
 var broad=Rule();var first=await service.Page(a.Id,broad,0,20,default);
 Check(first.Items.Length==20&&first.HasMore&&first.NextStartIndex==20,"first page returns immediately with a continuation cursor, not the complete library");
 Check(first.Items.All(i=>i.PrimaryImageTag=="fixture-primary-tag"),"Primary artwork is hydrated by the metadata query and its cache tag reaches every card");
 Check(queries.Last().Limit==20&&queries.Last().DtoOptions.GetImageLimit(ImageType.Primary)==1&&queries.Last().DtoOptions.GetImageLimit(ImageType.Backdrop)==0,"simple rules request only the returned items and one Primary image, not 128 full records");
 var next=await service.Page(a.Id,broad,first.NextStartIndex,20,default);Check(!next.Items.Select(i=>i.Id).Intersect(first.Items.Select(i=>i.Id)).Any(),"continuation does not repeat or skip the previous page");
 var both=Rule();both.ActorIds=actors.Select(p=>p.Id.ToString("N")).ToArray();var conjunction=await service.Page(a.Id,both,0,100,default);
 Check(conjunction.Items.Length==100&&conjunction.Items.All(i=>all.Single(x=>x.Item.Id.ToString("N")==i.Id).Actors.Length==2)&&creditCalls>0,"two selected actors mean AND, not an OR of their filmographies");
 var combined=Rule();combined.Genre="Science Fiction";combined.MinYear=2016;combined.MaxYear=2025;combined.MinRating=7.5;combined.AudioLanguage="it";combined.Require4K=true;combined.SortBy="Rating";
 var match=await service.Page(a.Id,combined,0,100,default);
 Check(match.Items.Length>0&&match.Items.All(i=>{var x=all.Single(x=>x.Item.Id.ToString("N")==i.Id);return x.Folder==folderA.Id&&x.Item.Genres.Contains("Science Fiction")&&i.ProductionYear>=2016&&i.ProductionYear<=2025&&i.CommunityRating>=7.5&&x.Audio=="ita"&&x.FourK;}),"genre, inclusive year bounds, rating, Italian audio and 4K combine correctly");
 Check(match.Items.Select(i=>i.CommunityRating).SequenceEqual(match.Items.Select(i=>i.CommunityRating).OrderByDescending(x=>x)),"rating order uses the stored Jellyfin community rating");
 var me=Rule();me.Played="UnplayedByMe";var mine=await service.Page(a.Id,me,0,100,default);Check(!mine.Items.Any(i=>i.Id==all[1].Item.Id.ToString("N"))&&mine.Items.Any(i=>i.Id==all[0].Item.Id.ToString("N")),"unplayed-by-me does not use another user's watched flag");
 me.Played="UnplayedByAnyone";var unseen=await service.Page(a.Id,me,0,100,default);Check(unseen.Items.All(i=>!all.Take(3).Any(x=>x.Item.Id.ToString("N")==i.Id)),"never watched checks every current user's played status and existing play count");
 var filtered=Rule();filtered.LibraryIds=[folderB.Id.ToString("N")];var calls=itemCalls;var denied=await service.Page(a.Id,filtered,0,20,default);Check(denied.Items.Length==0&&itemCalls==calls&&emptyQueries==0,"forbidden or empty library scope never becomes a global query");
 var other=await service.Page(b.Id,broad,0,20,default);Check(other.Items.Single().Name=="Foreign","different user gets only their own accessible library");
 var missing=Rule();missing.ActorIds=[Guid.NewGuid().ToString("N")];Check((await service.Page(a.Id,missing,0,20,default)).Items.Length==0,"unknown actor ID does not broaden the rule");
 var before=itemCalls;using(var cancel=new CancellationTokenSource()){cancel.Cancel();try{await service.Page(a.Id,broad,0,20,cancel.Token);throw new Exception("Cancellation ignored");}catch(OperationCanceledException){Check(itemCalls==before,"cancelled requests stop before reading metadata");}}
 foreach(var bad in new[]{new SmartCollection{Name=""},new SmartCollection{Name="Bad",MinYear=2025,MaxYear=2010},new SmartCollection{Name="Bad",MinRating=11},new SmartCollection{Name="Bad",MediaType="Audio"},new SmartCollection{Name="Bad",MediaType="Series",Require4K=true},new SmartCollection{Name="Bad",AudioLanguage="../etc"},new SmartCollection{Name="Bad",ActorIds=["../etc"]}}){var rejected=false;try{SmartValidation.Normalize(bad);}catch(ArgumentException){rejected=true;}Check(rejected,"invalid rule rejected: "+JsonSerializer.Serialize(bad));}
 var duplicate=Rule();try{SmartValidation.Normalize(new SmartConfiguration{Collections=[duplicate,duplicate]});throw new Exception("Duplicate ID accepted");}catch(ArgumentException){Check(true,"duplicate collection IDs are rejected");}
 var sparse=Rule();sparse.ActorIds=both.ActorIds;foreach(var x in all.Where(x=>x.Folder==folderA.Id))x.Actors=[actors[0].Id];before=itemCalls;var none=await service.Page(a.Id,sparse,0,100,default);Check(none.Items.Length==0&&itemCalls-before<=5,"sparse AND matches issue at most five 128-item queries per request");
 foreach(var x in all.Where(x=>x.Folder==folderA.Id&&int.Parse(x.Item.Name.Split(' ')[1])%3==0))x.Actors=actors.Select(p=>p.Id).ToArray();
 var xml=new System.Xml.Serialization.XmlSerializer(typeof(Configuration));using(var buffer=new StringWriter()){xml.Serialize(buffer,configuration);using var reader=new StringReader(buffer.ToString());Check(((Configuration)xml.Deserialize(reader)!).SmartCollections.Collections.Length==0,"existing configuration XML round-trips with default optional Smart Collections");}
 var builder=WebApplication.CreateBuilder();builder.Logging.ClearProviders();builder.WebHost.UseUrls("http://127.0.0.1:0");builder.Services.AddSingleton(service);builder.Services.AddSingleton(library);builder.Services.AddSingleton(users);builder.Services.AddSingleton(data);
 builder.Services.AddSingleton(Proxy.Make<IImageProcessor>((_,_)=>null));builder.Services.AddSingleton<ActorsCatalogService>();
 builder.Services.AddAuthentication("fixture").AddScheme<AuthenticationSchemeOptions,TestAuthentication>("fixture",_=>{});builder.Services.AddAuthorization(o=>o.AddPolicy("RequiresElevation",p=>p.RequireRole("Admin")));
 builder.Services.AddControllers().AddJsonOptions(o=>o.JsonSerializerOptions.PropertyNamingPolicy=null).AddApplicationPart(typeof(SmartController).Assembly);
 await using var app=builder.Build();app.UseAuthentication();app.UseAuthorization();app.MapControllers();await app.StartAsync();
 using var client=new HttpClient(new HttpClientHandler{UseProxy=false}){BaseAddress=new Uri(app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single())};
 Check((int)(await client.GetAsync("GenreRows/SmartCollections/Catalog")).StatusCode==401,"anonymous catalog access denied");
 Check((await client.GetAsync("GenreRows/SmartCollections/strings.js")).IsSuccessStatusCode,"public static translations contain no library data");
 var script=await client.GetStringAsync("GenreRows/client.js");Check(script.Contains("window.__genreRowsSmart")&&script.Contains("window.__genreRowsActors")&&script.Contains("gra-player"),"the real plugin script bundle includes Smart Collections and preserves ActorFlix/Adult resources");
 client.DefaultRequestHeaders.Add("X-Test-User",a.Id.ToString());Check((int)(await client.GetAsync("GenreRows/SmartCollections/Catalog")).StatusCode==403,"disabled module blocks ordinary catalog access");
 foreach(var route in new[]{"Configuration","Actors?SearchTerm=Actor"})Check((int)(await client.GetAsync("GenreRows/SmartCollections/"+route)).StatusCode==403,"ordinary user cannot read administrator "+route);
 Check((int)(await client.PostAsJsonAsync("GenreRows/SmartCollections/Preview",broad)).StatusCode==403,"ordinary user cannot preview arbitrary rules");
 Check((int)(await client.PostAsJsonAsync("GenreRows/SmartCollections/Configuration",new SmartConfiguration())).StatusCode==403,"ordinary user cannot edit collection rules");
 client.DefaultRequestHeaders.Add("X-Test-Admin","true");
 JsonElement search=default;for(var retry=0;retry<100;retry++){search=await client.GetFromJsonAsync<JsonElement>("GenreRows/SmartCollections/Actors?SearchTerm=Actor");if(search.GetProperty("Items").GetArrayLength()==2)break;await Task.Delay(10);}
 Check(search.GetProperty("Items").GetArrayLength()==2,"administrator actor picker uses the permission-scoped local ActorFlix catalog");
 var saved=await client.PostAsJsonAsync("GenreRows/SmartCollections/Configuration",new SmartConfiguration{Enabled=true,Collections=[combined,broad]});Check(saved.IsSuccessStatusCode,"administrator can save valid collection definitions");
 Check(configuration.ActorsEnabled&&configuration.Groups.Single().Name=="Existing"&&ReferenceEquals(plugin.Configuration.Adult,configuration.Adult),"saving Smart Collections preserves existing genre/ActorFlix/Adult configuration");
 var response=await client.GetFromJsonAsync<JsonElement>("GenreRows/SmartCollections/Catalog");Check(response.GetProperty("Collections").GetArrayLength()==2&&!response.ToString().Contains("ActorIds"),"ordinary catalog publishes only collection presentation fields");
 Check((int)(await client.GetAsync("GenreRows/SmartCollections/Items/"+Guid.NewGuid())).StatusCode==404,"unknown collection endpoint cannot select an arbitrary rule");
 Check((int)(await client.GetAsync("GenreRows/SmartCollections/Items/"+broad.Id+"?startIndex=-1")).StatusCode==400,"invalid cursor rejected at the HTTP endpoint");
 var payload=await client.GetAsync("GenreRows/SmartCollections/Items/"+combined.Id);var body=await payload.Content.ReadAsStringAsync();Check(payload.IsSuccessStatusCode&&payload.Headers.CacheControl?.NoStore==true&&!body.Contains("Path")&&!body.Contains("UserData")&&!body.Contains("Foreign")&&body.Contains("fixture-primary-tag"),"collection API is no-store and exposes no paths, viewing profiles or foreign items");
 var configBefore=plugin.Configuration.SmartCollections;var preview=await client.PostAsJsonAsync("GenreRows/SmartCollections/Preview",Rule());Check(preview.IsSuccessStatusCode&&ReferenceEquals(configBefore,plugin.Configuration.SmartCollections),"preview evaluates an unsaved rule without persisting it");
 var invalid=await client.PostAsJsonAsync("GenreRows/SmartCollections/Configuration",new SmartConfiguration{Enabled=true,Collections=[new(){Name="Bad",MinYear=2025,MaxYear=2010}]});Check((int)invalid.StatusCode==400&&ReferenceEquals(configBefore,plugin.Configuration.SmartCollections),"invalid save leaves the last valid configuration intact");
 var extra=new TestItem(new Movie{Id=Guid.NewGuid(),Name="Added later",ProductionYear=2026,DateCreated=DateTime.UtcNow},folderA.Id,[],"ita",false);all.Insert(0,extra);Check((await service.Page(a.Id,broad,0,20,default)).Items[0].Name=="Added later","newly indexed titles enter dynamic collections without a rebuild");
 await app.StopAsync();Check(queries.All(q=>!q.DtoOptions.EnableUserData&&q.DtoOptions.Fields.Count==0&&(!q.SourceTypes.Contains(SourceType.Library)||q.DtoOptions.GetImageLimit(ImageType.Primary)==1&&q.DtoOptions.ImageTypes.Count==1)),"queries load only Primary artwork and avoid unrelated fields/user metadata");
 Console.WriteLine($"SUCCESS {checks} Smart Collections checks");
}finally{Directory.Delete(directory,true);}

public class Proxy:DispatchProxy{
 public Func<MethodInfo,object?[],object?> Call=null!;
 public static T Make<T>(Func<MethodInfo,object?[],object?> callback)where T:class{var proxy=Create<T,Proxy>();((Proxy)(object)proxy).Call=callback;return proxy;}
 protected override object? Invoke(MethodInfo? method,object?[]? args)=>Call(method!,args??[]);
}
public class TestRoot:UserRootFolder{public Dictionary<Guid,CollectionFolder[]> Folders=new();public override IReadOnlyList<BaseItem> GetChildren(User user,bool includeLinkedChildren,InternalItemsQuery? query=null)=>Folders[user.Id];}
public class TestItem(Movie item,Guid folder,Guid[] actors,string audio,bool fourK){public Movie Item=item;public Guid Folder=folder;public Guid[] Actors=actors;public string Audio=audio;public bool FourK=fourK;}
public class TestAuthentication(IOptionsMonitor<AuthenticationSchemeOptions> options,ILoggerFactory logger,UrlEncoder encoder):AuthenticationHandler<AuthenticationSchemeOptions>(options,logger,encoder){
 protected override Task<AuthenticateResult> HandleAuthenticateAsync(){if(!Guid.TryParse(Request.Headers["X-Test-User"],out var user))return Task.FromResult(AuthenticateResult.NoResult());var claims=new List<Claim>{new("Jellyfin-UserId",user.ToString())};if(Request.Headers["X-Test-Admin"]=="true")claims.Add(new(ClaimTypes.Role,"Admin"));return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(new ClaimsIdentity(claims,"fixture")),"fixture")));}
}
