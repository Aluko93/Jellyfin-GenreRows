using System.Net;
using Jellyfin.Plugin.GenreRows;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.ClearProviders();
builder.WebHost.UseUrls("http://127.0.0.1:0");
builder.Services.AddResponseCompression();
var app = builder.Build();
var directory = Path.Combine(Path.GetTempPath(), "genre-rows-test-" + Guid.NewGuid());
Directory.CreateDirectory(directory);
var original = "<!doctype html><html><body>Fantascienza & avventura</body></html>";
await File.WriteAllTextAsync(Path.Combine(directory, "index.html"), original);
app.UseMiddleware<IndexMiddleware>("/jellyfin");
app.UseMiddleware<IndexMiddleware>("");
app.Map("/jellyfin", branch => {
    branch.Use(async (ctx, next) => {
        if (ctx.Request.Query.ContainsKey("redirect")) { ctx.Response.Redirect("https://example.invalid"); return; }
        await next();
    });
    branch.UseResponseCompression();
    branch.UseDefaultFiles(new DefaultFilesOptions { FileProvider = new PhysicalFileProvider(directory), RequestPath = "/web" });
    branch.UseStaticFiles(new StaticFileOptions { FileProvider = new PhysicalFileProvider(directory), RequestPath = "/web" });
});
app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = new PhysicalFileProvider(directory), RequestPath = "/web" });
app.UseStaticFiles(new StaticFileOptions { FileProvider = new PhysicalFileProvider(directory), RequestPath = "/web" });
await app.StartAsync();
var url = app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single();
using var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false, UseProxy = false }) { BaseAddress = new Uri(url) };
int checks = 0;
void Check(bool condition, string message) { if (!condition) throw new Exception(message); checks++; Console.WriteLine("PASS " + message); }
try {
    foreach (var path in new[] { "/jellyfin/web/index.html", "/jellyfin/web/", "/web/index.html", "/web/" }) {
        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.TryAddWithoutValidation("Accept-Encoding", "gzip, br");
        request.Headers.TryAddWithoutValidation("If-None-Match", "*");
        request.Headers.TryAddWithoutValidation("Range", "bytes=0-10");
        using var response = await client.SendAsync(request);
        var html = await response.Content.ReadAsStringAsync();
        Check(response.StatusCode == HttpStatusCode.OK, path + " returns 200");
        Check(html.Contains("genre-rows-loader") && html.Contains("Fantascienza"), path + " injected and content preserved");
        Check(response.Content.Headers.ContentLength == System.Text.Encoding.UTF8.GetByteCount(html), "correct transformed content length");
        Check(response.Headers.ETag == null && response.Headers.CacheControl?.NoStore == true, "no stale cached index");
    }
    Check(await File.ReadAllTextAsync(Path.Combine(directory, "index.html")) == original, "index on disk unchanged");
    using var outside = await client.GetAsync("/other/web/index.html");
    Check(outside.StatusCode == HttpStatusCode.NotFound, "BaseUrl boundary preserved");
    using var redirect = await client.GetAsync("/jellyfin/web/index.html?redirect=1");
    Check(redirect.StatusCode == HttpStatusCode.Redirect && !(await redirect.Content.ReadAsStringAsync()).Contains("genre-rows-loader"), "redirect preserved");
    using var head = await client.SendAsync(new HttpRequestMessage(HttpMethod.Head, "/jellyfin/web/index.html"));
    Check((await head.Content.ReadAsByteArrayAsync()).Length == 0, "HEAD preserved");
    Console.WriteLine($"{checks} integration checks passed.");
} finally {
    await app.StopAsync(); await app.DisposeAsync();
    Directory.Delete(directory, true);
}
