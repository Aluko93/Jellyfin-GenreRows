const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true});
 try{
  const page=await browser.newPage({viewport:{width:1280,height:800}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  let images=0;await page.route('http://portrait.test/**',async route=>{images++;await new Promise(r=>setTimeout(r,450));await route.fulfill({contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="156" height="234"><path fill="#778899" d="M0 0h156v234H0z"/></svg>'});});
  await page.setContent('<html lang="it"><body style="background:#111;color:white;font:16px Arial"><div id="homeTab"></div></body></html>');
  await page.evaluate(()=>{
   window.actorRequests=0;window.catalogDone=false;window.seenRequests=[];window.currentUser='u';
   window.ApiClient={getCurrentUserId:()=>currentUser,accessToken:()=>currentUser+'-token',serverAddress:()=>'/jf',getUrl:(p,q)=>JSON.stringify({p,q}),getImageUrl:id=>'http://portrait.test/'+id+'.svg',
    ajax:async req=>{const {p,q={}}=JSON.parse(req.url);if(p==='GenreRows/Actors/Status')return{Enabled:true,PopularityEnabled:false};if(p==='GenreRows/Libraries')return[];if(p==='GenreRows/Actors/Favorites')return{Ids:[]};
     if(p!=='GenreRows/Actors/Catalog')throw Error(p);actorRequests++;const offset=q.StartIndex||0;seenRequests.push(offset);await new Promise(r=>setTimeout(r,120));
     const size=4000;const items=Array.from({length:Math.min(100,size-offset)},(_,n)=>{const i=n+offset;return{Id:'actor-'+i,Name:'Actor '+String(i).padStart(4,'0'),PrimaryImageTag:'same',MovieCount:i%7,Popularity:i+1};});
     if(offset+100>=size)catalogDone=true;
     return{Items:items,Revision:actorRequests>5?'cached-complete':'cached-first',PopularityVersion:actorRequests>7?'score-updated':'score',TotalCount:size,NextStartIndex:offset+items.length,Loading:false};}
   };
  });
  const started=Date.now();for(const f of ['core.js','tv.js','actors.js'])await page.addScriptTag({path:path.join(__dirname,'../src/Web',f)});
  await page.waitForFunction(()=>document.querySelectorAll('.gr-person[data-id]').length===30);
  const firstTime=Date.now()-started;assert.equal(await page.evaluate(()=>catalogDone),false);assert(firstTime<2500);
  await page.evaluate(()=>{
   window.firstCard=document.querySelector('.gr-person[data-id]');window.firstImage=firstCard.querySelector('img');window.firstOrder=[...document.querySelectorAll('.gr-person[data-id]')].map(n=>n.dataset.id);
   window.removedCards=0;window.changedSources=0;const track=document.querySelector('.gr-actors-track');
   new MutationObserver(records=>{for(const record of records){for(const n of record.removedNodes)if(n.matches?.('.gr-person[data-id]'))removedCards++;if(record.type==='attributes'&&record.target===firstImage)changedSources++;}}).observe(track,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
  });
  await page.waitForFunction(()=>firstImage.complete&&firstImage.naturalWidth>0);await page.evaluate(()=>changedSources=0);
  await page.locator('.gr-person[data-id]').nth(3).focus();const saved=await page.evaluate(()=>({focus:document.activeElement.dataset.id,scroll:document.querySelector('.gr-actors-track').scrollLeft}));
  await page.waitForFunction(()=>actorRequests>=12);
  assert.equal(await page.evaluate(()=>firstCard===document.querySelector('.gr-person[data-id]')&&firstImage===firstCard.querySelector('img')&&firstImage.naturalWidth>0),true);
  assert.equal(await page.evaluate(()=>removedCards),0);assert.equal(await page.evaluate(()=>changedSources),0);
  assert.deepEqual(await page.evaluate(()=>[...document.querySelectorAll('.gr-person[data-id]')].map(n=>n.dataset.id)),await page.evaluate(()=>firstOrder));
  assert.equal(await page.evaluate(()=>document.activeElement.dataset.id),saved.focus);assert.equal(await page.evaluate(()=>document.querySelector('.gr-actors-track').scrollLeft),saved.scroll);
  assert(images<18,'off-screen portraits were requested eagerly');console.log('PASS first 30 actors before catalog completion; slow portraits stay decoded, no card removal, no source resets, stable focus/scroll/order under latency');
  await page.waitForFunction(()=>catalogDone&&document.querySelector('.gr-actors>p:not(.gr-discover-note)').textContent==='',{},{timeout:20000});
  assert.equal(await page.evaluate(()=>removedCards),0);assert.equal(await page.locator('.gr-person[data-id]').count(),30);
  await page.getByRole('button',{name:'Mostra altri',exact:true}).click();assert.equal(await page.locator('.gr-person[data-id]').count(),60);assert.equal(await page.evaluate(()=>firstCard===document.querySelector('.gr-person[data-id]')),true);
  const expected=await page.evaluate(()=>GenreRowsActorFlix.discover(Array.from({length:4000},(_,i)=>({Id:'actor-'+i,Name:'Actor '+String(i).padStart(4,'0'),MovieCount:i%7,Popularity:i+1})),currentUser+'|'+new Date().toISOString().slice(0,10))[0].Id);
  await page.locator('.gr-actors-toolbar select').selectOption('discover');assert.equal(await page.locator('.gr-person[data-id]').first().getAttribute('data-id'),expected);console.log('PASS 4,000 actor background catalog, 30-node incremental append, explicit Discover reordering');
  const card=page.locator('.gr-person[data-id]').first();await card.evaluate(n=>GenreRowsTV.focus(n));await page.waitForTimeout(700);
  const layout=await card.evaluate(n=>{const a=n.getBoundingClientRect(),b=n.firstChild.getBoundingClientRect(),c=n.nextElementSibling.getBoundingClientRect();return{frameWidth:b.width,slotWidth:a.width,right:b.right,nextLeft:c.left,border:getComputedStyle(n.firstChild).outlineWidth,scale:getComputedStyle(n.firstChild).transform};});
  assert(Math.abs(layout.frameWidth/156-1.25)<.01);assert(layout.frameWidth<=layout.slotWidth+.5);assert(layout.right<layout.nextLeft);assert.equal(layout.border,'0px');
  await page.screenshot({path:path.join(__dirname,'../actorflix-progressive.png')});console.log('PASS 25% focus enlargement fits reserved slot without overlapping the next card or a permanent outline');
  await page.evaluate(()=>currentUser='');await page.waitForFunction(()=>!document.querySelector('.gr-actors'));assert.deepEqual(errors,[]);
  console.log('SUCCESS progressive latency regression');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
