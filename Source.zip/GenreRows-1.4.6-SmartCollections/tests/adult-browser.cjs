const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const script = path.join(__dirname, '../src/Adult/Web/adult.js');
(async () => {
    const browser = await chromium.launch({ headless: true, ...(process.env.TEST_BROWSER_CHANNEL ? {channel:process.env.TEST_BROWSER_CHANNEL}:{}) });
    let checks = 0;
    const pass = name => { checks++; console.log('PASS ' + name); };
    try {
        const page = await browser.newPage({ viewport: { width: 1280, height: 900 }, locale: 'it-IT' });
        const errors = []; page.on('pageerror', e => errors.push(e.message));
        let allowed = true, beatOK = true, delayUnlock = false, releaseUnlock,delayPlayback=false,releasePlayback;
        const calls = [], active = new Set(); let n = 0;
        await page.route('http://genre.test/**', async route => {
            const req = route.request(), url = new URL(req.url()), endpoint = url.pathname.split('/').pop();
            if (!url.pathname.startsWith('/GenreRows/Adult/')) return route.fulfill({ contentType: 'text/html', body: '<div id="homeTab"><div class="sections">Jellyfin Home</div><div class="gr-root">GenreRows esistente</div></div>' });
            const token = req.headers()['x-adult-session']; calls.push({ endpoint, method: req.method(), token, authorization: req.headers().authorization, url: req.url() });
            const json = body => route.fulfill({ contentType: 'application/json', headers: { 'cache-control': 'no-store' }, body: JSON.stringify(body) });
            if (endpoint === 'Status') return json({ Available: allowed, HomeTitle: 'Riservato', HomeDescription: 'Descrizione card personalizzata' });
            if (endpoint === 'HomeCover') return route.fulfill({ contentType: 'image/png', body: Buffer.from([137,80,78,71,13,10,26,10]) });
            if (endpoint === 'Unlock') {
                const t = 'session-' + (++n); active.add(t);
                if (delayUnlock) await new Promise(r => { releaseUnlock = r; });
                return json({ Token: t, IdleMinutes: 1, LeaseSeconds: 8 });
            }
            if (endpoint === 'Lock') { active.delete(token); return route.fulfill({ status: 204 }); }
            if (!active.has(token) || (endpoint === 'Heartbeat' && !beatOK)) return route.fulfill({ status: 403 });
            if (endpoint === 'Heartbeat') return route.fulfill({ status: 204 });if(endpoint==='Open'){if(delayPlayback)await new Promise(r=>releasePlayback=r);return json({DurationSeconds:12,ContentType:'video/mp4',Container:'mp4',VideoCodec:'h264',AudioTracks:[],SubtitleTracks:[],StreamUrl:'GenreRows/Adult/Playback/Stream'});}if(endpoint==='Close')return route.fulfill({status:204});
            if (endpoint === 'Categories') return json([{ Name: 'Categoria test', Title: 'Titolo scelto', Description: 'Descrizione scelta', HasCover: false }, { Name: '<img src=x onerror=alert(1)>', Title: '<img src=x onerror=alert(1)>', Description: '', HasCover: false }]);
            if (endpoint === 'Videos') return json([{ Name: '<script>test</script>.mkv' }, { Name: 'TEST_VIDEO_002.mp4' }]);
            if (endpoint === 'Thumbnail') return route.fulfill({ status: 200, contentType: 'image/jpeg', body: Buffer.from([255,216,255,217]) });
            return route.fulfill({ status: 404 });
        });
        await page.goto('http://genre.test/web/index.html');
        await page.evaluate(() => { window.user = 'adult-user'; window.authKey = 'jellyfin-test-login'; window.ApiClient = { getCurrentUserId: () => window.user, accessToken: () => window.authKey, serverAddress: () => 'http://genre.test', getUrl: p => 'http://genre.test/' + p }; });
        await page.addScriptTag({path:path.join(__dirname,'../src/Web/tv.js')});await page.addScriptTag({ path: script });
        await page.locator('.gra-card').waitFor();
        assert(await page.evaluate(() => document.querySelector('#homeTab').lastElementChild.matches('.gra-home'))); pass('Adult card at bottom; existing GenreRows retained');
        assert.equal(await page.locator('.gra-home-title').textContent(), 'Riservato'); assert.equal(await page.locator('.gra-home-description').textContent(), 'Descrizione card personalizzata');
        await page.locator('.gra-card img').waitFor(); pass('customizable Home title, description and image');
        const open = async () => { await page.locator('.gra-card').click(); await page.locator('#gra-secret').fill('test-secret-123'); await page.getByRole('button', { name: 'Sblocca', exact: true }).click(); await page.locator('.gra-category').first().waitFor(); };
        await open();
        assert.equal(await page.locator('.gra-category').first().locator('.gra-category-title').textContent(), 'Titolo scelto');
        assert.equal(await page.locator('.gra-category').first().locator('.gra-category-description').textContent(), 'Descrizione scelta');
        assert.equal(await page.locator('.gra-category').nth(1).textContent(), '<img src=x onerror=alert(1)>');
        assert.equal(await page.locator('.gra-category img').count(), 0); pass('category labels render as text, never HTML');
        await page.setViewportSize({width:320,height:500});await page.locator('.gra-category').first().focus();await page.keyboard.press('ArrowDown');
        assert(await page.locator('.gra-category').nth(1).evaluate(n=>n===document.activeElement));assert(await page.locator('.gra-dialog').evaluate(n=>n.scrollTop>0));
        await page.keyboard.press('ArrowUp');assert(await page.locator('.gra-category').first().evaluate(n=>n===document.activeElement));
        await page.setViewportSize({width:1280,height:900});await page.keyboard.press('Enter');
        await page.locator('.gra-video-card').first().waitFor();
        assert.equal(await page.locator('.gra-video-title').first().textContent(), '<script>test</script>.mkv');
        assert.equal(await page.locator('.gra-video-poster').count(), 2);assert.equal(await page.locator('.gra-video-play').count(),0); pass('remote Up/Down scroll categories and OK opens portrait video cards without overlay Play');
        await page.waitForFunction(() => document.querySelectorAll('.gra-video-card img[src]').length > 0);
        assert(calls.some(c => c.endpoint === 'Thumbnail' && c.authorization?.startsWith('MediaBrowser Client='))); pass('video names stay text and authenticated thumbnails load');
        delayPlayback=true;await page.locator('.gra-video-poster').first().click();for(let i=0;i<30&&!releasePlayback;i++)await page.waitForTimeout(10);assert(releasePlayback);await page.goBack();await page.locator('.gra-category').first().waitFor();releasePlayback();delayPlayback=false;await page.waitForTimeout(150);assert.equal(await page.locator('video').count(),0);assert(calls.some(x=>x.endpoint==='Close'));assert.equal(active.size,1);pass('Back inside Adult preserves categories and cancels a late video-open response');
        await page.goBack(); await page.waitForFunction(() => !document.querySelector('.gra-dialog'));
        await page.waitForTimeout(100); assert.equal(active.size, 0); pass('Back out of Adult closes interface and revokes server token');
        await open(); await page.getByRole('button', { name: '🔒 Blocca e chiudi' }).click(); await page.waitForTimeout(100); assert.equal(active.size, 0); pass('explicit lock revokes token');
        await open(); await page.evaluate(() => window.dispatchEvent(new Event('blur'))); await page.waitForTimeout(100); assert.equal(await page.locator('.gra-dialog').count(), 0); assert.equal(active.size, 0); pass('background/focus loss locks immediately');
        await open(); await page.evaluate(() => { window.user = 'child-user'; }); await page.waitForFunction(() => !document.querySelector('.gra-dialog')); await page.waitForTimeout(100); assert.equal(active.size, 0); pass('user switch locks old session');
        await page.evaluate(() => { window.user = 'adult-user'; }); await open(); await page.evaluate(() => { window.authKey = ''; }); await page.waitForFunction(() => !document.querySelector('.gra-dialog')); pass('logout closes section');
        await page.evaluate(() => { window.authKey = 'new-login'; }); await open(); await page.evaluate(() => { location.hash = '#/movies'; }); await page.waitForFunction(() => !document.querySelector('.gra-dialog')); pass('navigation outside section locks');
        await open(); beatOK = false; await page.waitForFunction(() => !document.querySelector('.gra-dialog')); beatOK = true; pass('server heartbeat refusal hides sensitive content');
        delayUnlock = true; await page.locator('.gra-card').click(); await page.locator('#gra-secret').fill('test-secret-123'); await page.getByRole('button', { name: 'Sblocca', exact: true }).click();
        await page.waitForTimeout(200); assert(releaseUnlock); await page.getByRole('button', { name: '🔒 Blocca e chiudi' }).click(); releaseUnlock(); delayUnlock = false;
        await page.waitForTimeout(200); assert.equal(await page.locator('.gra-dialog').count(), 0); assert.equal(active.size, 0); pass('late unlock response is revoked after exit');
        assert.equal(await page.evaluate(() => localStorage.length + sessionStorage.length), 0);
        assert(calls.every(c => !c.url.includes('session-') && !c.url.includes('test-secret') && c.authorization?.startsWith('MediaBrowser Client='))); pass('MediaBrowser auth header used; no Adult token in URLs or browser storage');
        allowed = false; await page.evaluate(() => window.dispatchEvent(new Event('genreRowsSettingsChanged'))); await page.waitForFunction(() => !document.querySelector('.gra-card')); pass('disabled or unauthenticated user has no card');
        assert.equal(await page.locator('.gr-root').textContent(), 'GenreRows esistente'); assert.deepEqual(errors, []); pass('existing Home retained; no uncaught browser errors');
        allowed = true; await page.evaluate(() => window.dispatchEvent(new Event('genreRowsSettingsChanged'))); await page.locator('.gra-card').waitFor(); await open();
        if (process.env.SCREENSHOT_PATH) { fs.mkdirSync(path.dirname(process.env.SCREENSHOT_PATH), { recursive: true }); await page.screenshot({ path: process.env.SCREENSHOT_PATH }); }
        await page.clock.install(); await page.clock.runFor(61000); await page.waitForFunction(() => !document.querySelector('.gra-dialog')); pass('configured inactivity timeout closes Adult despite heartbeat');
        await page.clock.uninstall?.();
        let savedConfiguration, savedAuthorization;
        const admin = await browser.newPage({ locale: 'it-IT' });
        await admin.route('http://admin.test/**', async route => {
            const req = route.request(), endpoint = new URL(req.url()).pathname.split('/').pop();
            if (endpoint !== 'Configuration') return route.fulfill({ status: 404 });
            if (req.method() === 'POST') { savedConfiguration = req.postDataJSON(); savedAuthorization = req.headers().authorization; return route.fulfill({ status: 204 }); }
            return route.fulfill({ contentType: 'application/json', body: JSON.stringify({ Enabled: true, RootPath: '/srv/media/Adult', IdleMinutes: 5, HasPassword: true,
                Users:[{Id:'allowed-user',Name:'Allowed'},{Id:'blocked-user',Name:'Blocked'}],HomeTitle: 'Adult', HomeDescription: 'Area protetta', HomeImageFile: '', Categories: [{ FolderName: 'Categoria test', Title: 'Titolo iniziale', Description: 'Descrizione iniziale', ImageFile: 'folder.jpg' }] }) });
        });
        await admin.setContent(fs.readFileSync(path.join(__dirname, '../src/Adult/Web/config.html'), 'utf8'));
        await admin.evaluate(() => { window.ApiClient = { accessToken: () => 'admin-token', getUrl: p => 'http://admin.test/' + p }; document.querySelector('#GenreRowsAdultPage').dispatchEvent(new Event('pageshow')); });
        await admin.waitForFunction(() => !document.querySelector('#graSubmit').disabled);
        assert.equal(await admin.locator('#graRoot').inputValue(), '/srv/media/Adult'); assert(await admin.getByText('Categoria test', { exact: true }).isVisible());
        await admin.locator('#graHomeTitle').fill('Privato'); await admin.locator('#graHomeDescription').fill('Nuova descrizione Home'); await admin.locator('#graHomeImage').fill('nuova-home.png');
        await admin.locator('.gra-cat-title').fill('Titolo nuovo'); await admin.locator('.gra-cat-description').fill('Nuova descrizione categoria'); await admin.locator('.gra-cat-image').fill('categoria.webp');
        await admin.locator('#graVisibility').selectOption('SelectedUsers');await admin.locator('#graUsers input').first().check();await admin.locator('#graSubmit').click(); await admin.waitForFunction(() => document.querySelector('#graMessage').textContent.startsWith('Salvato'));
        assert.match(savedAuthorization, /^MediaBrowser Client=/);
        assert.equal(savedConfiguration.HomeVisibility,'SelectedUsers');assert.deepEqual(savedConfiguration.AllowedUserIds,['allowed-user']);
        assert.equal(await admin.locator('#graUsers').count(), 1); assert(await admin.locator('#graUsersBox').isVisible());
        assert.equal(savedConfiguration.HomeTitle, 'Privato'); assert.equal(savedConfiguration.HomeImageFile, 'nuova-home.png');
        assert.deepEqual(savedConfiguration.Categories[0], { FolderName: 'Categoria test', Title: 'Titolo nuovo', Description: 'Nuova descrizione categoria', ImageFile: 'categoria.webp' });
        pass('Dashboard edits Home and per-category presentation'); await admin.close();
        console.log('SUCCESS ' + checks + ' Adult browser checks');
    } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });



