const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path');
(async()=>{const browser=await chromium.launch({headless:true});try{
 const page=await browser.newPage();await page.setContent('<div id="homeTab"></div>');
 await page.evaluate(()=>{
  const library='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';window.genreCalls=[];
  window.ApiClient={getCurrentUserId:()=> 'user',serverAddress:()=>'/jellyfin',serverId:()=> 'server',getUrl:(p,q)=>JSON.stringify({p,q}),getImageUrl:()=>'',ajax:async req=>{
   const {p,q={}}=JSON.parse(req.url);if(p==='GenreRows/Settings')return{Enabled:true,SchemaVersion:3,Groups:['Series','Movie'].map(type=>({Id:type,Name:type,MediaType:type,LibraryIds:[library],Genres:['Action','Fantasy','Horror'],Limit:30,Enabled:true}))};
   if(p==='GenreRows/Libraries')return[{Id:library,Name:'Allowed'}];if(p==='Genres')return{Items:['Action','Fantasy','Horror'].map(Name=>({Id:Name,Name}))};
   if(p==='Items'){
    if(q.UserId!=='user'||q.ParentId!==library)throw Error('Unscoped request');genreCalls.push(q);
    await new Promise(r=>setTimeout(r,q.GenreIds==='Action'?180:10));
    return{Items:Array.from({length:80},(_,i)=>({Id:q.IncludeItemTypes+'-'+(i<30?'common-'+i:q.GenreIds+'-'+i),Name:'Title '+i,DateCreated:new Date(Date.UTC(2026,0,100-i)).toISOString()})).slice(0,q.Limit)};
   }throw Error(p);
  }};
 });
 for(const f of ['core.js','client.js'])await page.addScriptTag({path:path.join(__dirname,'../src/Web',f)});
 await page.waitForFunction(()=>document.querySelectorAll('.gr-section').length===6);
 const rows=await page.locator('.gr-section').evaluateAll(nodes=>nodes.map(n=>({name:n.querySelector('h3').textContent,ids:[...n.querySelectorAll('a')].map(a=>new URLSearchParams(a.hash.split('?')[1]).get('id'))})));
 assert.deepEqual(rows.map(r=>r.name),['Series — Action','Series — Fantasy','Series — Horror','Movie — Action','Movie — Fantasy','Movie — Horror']);
 for(const offset of [0,3]){
  const used=new Set();for(const row of rows.slice(offset,offset+3)){assert.equal(row.ids.length,30);assert.equal(new Set(row.ids).size,30);assert(row.ids.slice(0,15).every(id=>!used.has(id)));row.ids.slice(0,15).forEach(id=>used.add(id));}
  assert(rows[offset+2].ids.slice(15).some(id=>rows[offset].ids.includes(id)),'repetitions should remain after the leading positions');
 }
 const fallback=await page.evaluate(()=>{const a=[{Id:'one'},{Id:'two'},{Id:'three'}],used=new Set(['one','two']);return GenreRowsCore.diversify(a,used,20).map(x=>x.Id);});assert.deepEqual(fallback,['three','one','two']);
 assert(await page.evaluate(()=>genreCalls.every(q=>q.Limit<=100&&q.Recursive&&q.UserId==='user')));
 console.log('PASS Movie/Series leading 15 avoid earlier row prefixes; repeats retained later; configuration order wins over response order; scarce libraries keep all titles; scoped candidate queries bounded to 100');
 }finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
