using Jellyfin.Plugin.GenreRows;
public static class PopularityLive {
    public static async Task Run(Action<bool,string> check) {
        var root=Environment.GetEnvironmentVariable("GR_TMDB_TEST_CACHE")??throw new Exception("Live test cache directory required");
        using var service=new ActorPopularityService(root);
        var deadline=DateTimeOffset.UtcNow.AddMinutes(4);ActorPopularitySnapshot page;
        do{page=service.Get(["500","287"],true);if(!page.Loading)break;await Task.Delay(500);}while(DateTimeOffset.UtcNow<deadline);
        check(!page.Loading&&page.Values.Count==2&&page.Values.Values.All(v=>v>=0),"live official TMDB export downloaded, parsed and matched by numeric person ID");
        Console.WriteLine("LIVE_TMBD_CACHE_BYTES "+new FileInfo(Path.Combine(root,"persons.json.gz")).Length);
        using var restarted=new ActorPopularityService(root);var warm=restarted.Get(["500","287"],true);
        check(!warm.Loading&&warm.Values.Count==2,"live scores restored from local cache without another export request");
    }
}
