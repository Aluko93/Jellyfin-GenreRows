using System.Reflection;
using System.Text.Json;
using Jellyfin.Data.Enums;
using Jellyfin.Database.Implementations.Entities;
using Jellyfin.Plugin.GenreRows;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Controller.Drawing;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Serialization;

public static class ActorGroupingFixture {
    public static async Task Run(string directory,Action<bool,string> check){
        var paths=DispatchProxy.Create<IApplicationPaths,ActorPaths>();((ActorPaths)(object)paths).Root=directory;
        var plugin=new Plugin(paths,DispatchProxy.Create<IXmlSerializer,ActorSerializer>());plugin.UpdateConfiguration(new Configuration{ActorsEnabled=true,ActorsPopularityEnabled=false});
        var users=DispatchProxy.Create<IUserManager,ActorUsers>();var u=(ActorUsers)(object)users;var user=new User("Viewer","Default","Default"){Id=Guid.NewGuid()};u.Users=[user];
        var folder=new CollectionFolder{Id=Guid.NewGuid()};u.Policy=new(){EnableAllFolders=false,EnabledFolders=[folder.Id]};
        var library=DispatchProxy.Create<ILibraryManager,ActorLibrary>();var fixture=(ActorLibrary)(object)library;fixture.ExpectedUser=user.Id;fixture.Root=new ActorRoot();fixture.Root.Folders[user.Id]=[folder];
        var guest=new Person{Id=Guid.NewGuid(),Name="Guest"};fixture.Persons[guest.Name]=guest;
        var show=Guid.NewGuid();var hidden=Guid.NewGuid();var episodes=Enumerable.Range(0,186).Select(n=>new ActorTitle(Guid.NewGuid(),BaseItemKind.Episode,[(guest.Name,"Actor")],SeriesId:show,SeasonNumber:n<86?1:3,Name:"Episode "+n)).ToArray();
        fixture.Titles[folder.Id]=[new(show,BaseItemKind.Series,[],Name:"One series",HasImage:true),..episodes,new(Guid.NewGuid(),BaseItemKind.Movie,[(guest.Name,"Actor")],Name:"One movie",HasImage:true),new(hidden,BaseItemKind.Series,[],Hidden:true,Name:"Hidden parent"),new(Guid.NewGuid(),BaseItemKind.Episode,[(guest.Name,"GuestStar")],SeriesId:hidden,SeasonNumber:1,Name:"Visible credit with forbidden parent")];
        foreach(var number in new[]{1,2,3})fixture.Seasons[Guid.NewGuid()]=(show,number,false);
        fixture.Seasons[Guid.NewGuid()]=(show,99,true);fixture.Seasons[Guid.NewGuid()]=(hidden,7,false);
        using var service=new ActorsCatalogService(library,users,DispatchProxy.Create<IImageProcessor,ActorImages>());
        for(var i=0;i<300;i++){if(!(await service.Page(user.Id,0)).Loading)break;await Task.Delay(10);}
        var first=JsonSerializer.SerializeToElement(await service.Titles(user.Id,guest.Id,folder.Id,0));
        check(first.GetProperty("Items").GetArrayLength()==1&&first.GetProperty("Items")[0].GetProperty("Id").GetString()==show.ToString("N"),"100 matching episode credits become one authorized series card");
        var card=first.GetProperty("Items")[0];check(card.GetProperty("Type").GetString()=="Series"&&card.GetProperty("Name").GetString()=="One series"&&card.GetProperty("PrimaryImageTag").GetString()=="primary-"+show.ToString("N"),"grouped card uses series metadata and the series poster, not an episode thumbnail");
        check(first.GetProperty("NextStartIndex").GetInt32()==100&&first.GetProperty("HasMore").GetBoolean(),"grouped output keeps the original credit cursor across pagination");
        check(card.GetProperty("SeasonNumbers").EnumerateArray().Select(x=>x.GetInt32()).SequenceEqual(new[]{1,3})&&card.GetProperty("AvailableSeasonNumbers").EnumerateArray().Select(x=>x.GetInt32()).SequenceEqual(new[]{1,2,3}),"matching seasons and available authorized seasons are reported separately");
        check(card.GetProperty("SeasonCoverageKnown").GetBoolean()&&!card.GetProperty("AvailableSeasonNumbers").EnumerateArray().Any(n=>n.GetInt32()==99),"hidden seasons cannot be exposed or used to claim full-season coverage");
        var second=JsonSerializer.SerializeToElement(await service.Titles(user.Id,guest.Id,folder.Id,100));var rows=second.GetProperty("Items").EnumerateArray().ToArray();
        check(rows.Length==2&&rows.Count(x=>x.GetProperty("Type").GetString()=="Movie")==1&&rows.Count(x=>x.GetProperty("Type").GetString()=="Series")==1,"later credit pages return only movies and grouped series, with no episode cards");
        check(rows.All(x=>x.GetProperty("Id").GetString()!=hidden.ToString("N"))&&!second.ToString().Contains("Hidden parent"),"a visible episode never exposes an unauthorized parent series");
        check(second.GetProperty("NextStartIndex").GetInt32()==188&&!second.GetProperty("HasMore").GetBoolean(),"the final cursor accounts for source episodes, movies and skipped parent references");
        check(await service.Titles(user.Id,guest.Id,Guid.NewGuid(),0) is null,"client cannot choose an unauthorized library for series aggregation");
    }
}
