using System.Reflection;
using Jellyfin.Plugin.GenreRows;
using MediaBrowser.Common.Configuration;
using MediaBrowser.Model.Serialization;
using MediaBrowser.Model.Configuration;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Users;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Entities.Movies;
using MediaBrowser.Controller.Library;
using MediaBrowser.Controller.Drawing;
using Jellyfin.Database.Implementations.Entities;
using Jellyfin.Data.Enums;

public static class CatalogFixture
{
    public static async Task Run(string root, Action<bool,string> check) {
        var paths=DispatchProxy.Create<IApplicationPaths,ActorPaths>();((ActorPaths)(object)paths).Root=root;
        var plugin=new Plugin(paths,DispatchProxy.Create<IXmlSerializer,ActorSerializer>());plugin.UpdateConfiguration(new Configuration{ActorsEnabled=true,ActorsPopularityEnabled=false});
        var users=DispatchProxy.Create<IUserManager,ActorUsers>();var u=(ActorUsers)(object)users;
        var a=new User("actor-a","Default","Default"){Id=Guid.NewGuid()};var b=new User("actor-b","Default","Default"){Id=Guid.NewGuid()};u.Users=[a,b];
        var folderA=new CollectionFolder{Id=Guid.NewGuid(),Name="Allowed A"};var folderB=new CollectionFolder{Id=Guid.NewGuid(),Name="Allowed B"};
        var emptyFolder=new CollectionFolder{Id=Guid.NewGuid(),Name="Empty"};
        u.Policy=new UserPolicy{EnableAllFolders=false,EnabledFolders=[folderA.Id,emptyFolder.Id]};
        var library=DispatchProxy.Create<ILibraryManager,ActorLibrary>();var l=(ActorLibrary)(object)library;l.Root=new ActorRoot();l.Root.Folders[a.Id]=[folderA,emptyFolder];l.Root.Folders[b.Id]=[folderB];l.ExpectedUser=a.Id;
        for(int i=0;i<105;i++)l.Persons["Actor A "+i]=new Person{Id=Guid.NewGuid(),Name="Actor A "+i};
        l.Persons["Actor B only"]=new Person{Id=Guid.NewGuid(),Name="Actor B only"};
        // Global metadata not linked to the user's titles must never enter the catalog.
        for(int i=0;i<9000;i++)l.Persons["Orphan "+i]=new Person{Id=Guid.NewGuid(),Name="Orphan "+i};
        l.Persons["Hidden actor"]=new Person{Id=Guid.NewGuid(),Name="Hidden actor"};
        l.Persons["Writer only"]=new Person{Id=Guid.NewGuid(),Name="Writer only"};
        l.Persons["Actor A 0"].Overview="A biography from Jellyfin.";
        l.Persons["Actor A 0"].ProviderIds["Tmdb"]="100";
        l.Titles[folderA.Id]=Enumerable.Range(0,300).Select(n=>new ActorTitle(Guid.NewGuid(),(n%3) switch {0=>BaseItemKind.Movie,1=>BaseItemKind.Series,_=>BaseItemKind.Episode},[("Actor A "+(n%105),n%2==0?"Actor":"GuestStar"),("Actor A "+(n%105),"Actor"),("Writer only","Writer")])).ToArray();
        l.Titles[folderA.Id]=[..l.Titles[folderA.Id],new(Guid.NewGuid(),BaseItemKind.Movie,[("Hidden actor","Actor")],Hidden:true),new(Guid.NewGuid(),BaseItemKind.Movie,[("Hidden actor","Actor")],Virtual:true),new(Guid.NewGuid(),BaseItemKind.Movie,[("Hidden actor","Actor")],Missing:true),new(Guid.NewGuid(),BaseItemKind.Audio,[("Hidden actor","Actor")])];
        l.Titles[folderB.Id]=[new(Guid.NewGuid(),BaseItemKind.Movie,[("Actor B only","Actor")])];l.Titles[emptyFolder.Id]=[];
        var images=DispatchProxy.Create<IImageProcessor,ActorImages>();
        async Task<ActorCatalogPage> Ready(ActorsCatalogService service,Guid id){for(int i=0;i<500;i++){var page=await service.Page(id,0);if(!page.Loading)return page;await Task.Delay(10);}throw new Exception("Service build timed out");}
        using(var service=new ActorsCatalogService(library,users,images)){
            var first=await Ready(service,a.Id);
            check(!first.Failed&&first.TotalCount==105&&first.Items.All(x=>x.Name.StartsWith("Actor A")),"only cast linked to accessible movies/series/episodes is included, excluding 9000 orphan people");
            check(l.Calls==4&&l.AccessCalls==4&&l.CreditCalls==3,"128-title pages use user access and CollectionFolder scope, with batched credit queries");
            check(l.GlobalCalls==0&&l.Lookups==105,"no global people query; repeated credits and roles resolve each actor once");
            check(l.LookedUp.All(n=>n.StartsWith("Actor A")),"hidden/missing/virtual/audio-only titles, writers and foreign credit keys cannot add actors");
            var all=(await service.AccessibleActors(a.Id));
            check(all.Single(p=>p.Name=="Actor A 0").MovieCount==3&&all.Single(p=>p.Name=="Actor A 1").MovieCount==0,"Discover counts only movies, not hundreds of series/episode credits");
            check(all.Single(p=>p.Name=="Actor A 0").TmdbId=="100"&&all.All(p=>p.Prominence>0&&p.Prominence<=1||p.MovieCount==0),"cached ranking metadata includes existing provider IDs and cast-order prominence");
            var count=l.Calls;await Ready(service,a.Id);check(l.Calls==count,"warm service catalog performs no repeated title or cast query");
            u.Policy.BlockedTags=["changed-restriction"];var changed=await Ready(service,a.Id);
            check(l.Calls>count&&changed.Revision!=first.Revision,"a user-policy change invalidates the live service snapshot");
            await ActorApiFixture.Run(service,library,users,a.Id,b.Id,l,check);
            l.ExpectedUser=b.Id;var other=await Ready(service,b.Id);check(other.Items.Single().Name=="Actor B only","second user's service response cannot contain the first user's actor list");
            service.Invalidate();var before=l.Calls;await Ready(service,b.Id);check(l.Calls>before,"administrator/library invalidation forces a new service build");
            l.Titles[folderB.Id]=[];service.Invalidate();var creditCalls=l.CreditCalls;var empty=await Ready(service,b.Id);
            check(!empty.Failed&&empty.TotalCount==0&&l.CreditCalls==creditCalls,"empty libraries never issue an unfiltered or empty-ID cast lookup");
        }
        await Task.Delay(150);var calls=l.Calls;
        using(var cold=new ActorsCatalogService(library,users,images)){var restored=await Ready(cold,b.Id);check(restored.TotalCount==0&&l.Calls==calls,"new service instance restores the corrected permission-scoped snapshot from disk");}
        check(!Directory.EnumerateFiles(root,"*.json",SearchOption.AllDirectories).Any(p=>File.ReadAllText(p).Contains("Orphan ")),"unlinked global names are not written to the new cache");
    }
}
public record ActorTitle(Guid Id,BaseItemKind Kind,(string Name,string Type)[] Credits,bool Hidden=false,bool Virtual=false,bool Missing=false,Guid SeriesId=default,int? SeasonNumber=null,string? Name=null,bool HasImage=false);
public class ActorRoot : UserRootFolder {
    public Dictionary<Guid,CollectionFolder[]> Folders=new();
    public override IReadOnlyList<BaseItem> GetChildren(User user,bool includeLinkedChildren,InternalItemsQuery? query=null)=>Folders[user.Id];
}
public class ActorLibrary : DispatchProxy {
    public ActorRoot Root=null!;public Guid ExpectedUser;public int Calls,AccessCalls,CreditCalls,GlobalCalls,Lookups;
    public Dictionary<Guid,ActorTitle[]> Titles=new();public Dictionary<Guid,(Guid SeriesId,int Number,bool Hidden)> Seasons=new();public Dictionary<string,Person> Persons=new();public HashSet<string> LookedUp=new();
    protected override object? Invoke(MethodInfo? method,object?[]? args){
        var name=method!.Name;if(name.StartsWith("add_")||name.StartsWith("remove_"))return null;
        if(name=="GetUserRootFolder")return Root;
        if(name=="GetLibraryOptions")return new LibraryOptions{Enabled=true};
        if(name=="ConfigureUserAccess"){if(((User)args![1]!).Id!=ExpectedUser)throw new Exception("Wrong access user");AccessCalls++;return null;}
        if(name=="GetItemList"){
            var q=(InternalItemsQuery)args![0]!;var parents=(List<BaseItem>)args[1]!;
            var metadata=q.IncludeItemTypes.SequenceEqual(new[]{BaseItemKind.Series})&&q.ItemIds.Length>0||q.IncludeItemTypes.SequenceEqual(new[]{BaseItemKind.Season})&&q.AncestorIds.Length>0;
            if(metadata){
                if(q.User?.Id!=ExpectedUser||parents.Count!=1||q.ParentId!=parents[0].Id||!Root.Folders[ExpectedUser].Any(f=>f.Id==q.ParentId)||q.IsVirtualItem!=false||q.IsMissing!=false||q.PersonIds.Length!=0||q.Limit is <1 or >128)throw new Exception("Unscoped parent metadata");
                Calls++;
                if(q.IncludeItemTypes[0]==BaseItemKind.Series)return Titles[q.ParentId].Where(t=>t.Kind==BaseItemKind.Series&&!t.Hidden&&!t.Virtual&&!t.Missing&&q.ItemIds.Contains(t.Id)).Select(Render).ToArray();
                var ids=Titles[q.ParentId].Where(t=>t.Kind==BaseItemKind.Series&&!t.Hidden).Select(t=>t.Id).ToHashSet();
                return Seasons.Where(p=>ids.Contains(p.Value.SeriesId)&&q.AncestorIds.Contains(p.Value.SeriesId)&&!p.Value.Hidden).Skip(q.StartIndex??0).Take(q.Limit??128).Select(p=>(BaseItem)new MediaBrowser.Controller.Entities.TV.Season{Id=p.Key,SeriesId=p.Value.SeriesId,IndexNumber=p.Value.Number}).ToArray();
            }
            if(q.PersonIds.Length==0&&(q.DtoOptions.EnableImages||q.DtoOptions.EnableUserData))throw new Exception("Catalog loaded heavyweight image/user metadata");
            if(q.User?.Id!=ExpectedUser||parents.Count!=1||q.ParentId!=parents[0].Id||!Root.Folders[ExpectedUser].Any(f=>f.Id==q.ParentId)||!q.Recursive||q.IsVirtualItem!=false||q.IsMissing!=false||!q.IncludeItemTypes.Order().SequenceEqual(new[]{BaseItemKind.Movie,BaseItemKind.Series,BaseItemKind.Episode}.Order())||q.Limit!=(q.PersonIds.Length>0?100:128))throw new Exception("Unscoped title query");
            Calls++;return Titles[q.ParentId].Where(t=>!t.Hidden&&(!t.Virtual||q.IsVirtualItem!=false)&&(!t.Missing||q.IsMissing!=false)&&q.IncludeItemTypes.Contains(t.Kind)&&(!q.PersonIds.Any()||t.Credits.Any(c=>Persons.TryGetValue(c.Name,out var person)&&q.PersonIds.Contains(person.Id)&&(c.Type=="Actor"||c.Type=="GuestStar")))).Skip(q.StartIndex??0).Take(q.Limit??128).Select(Render).ToArray();
        }
        if(name=="GetPeopleNamesByItems"){
            var ids=(IReadOnlyList<Guid>)args![0]!;var types=(IReadOnlyList<string>)args[1]!;
            if(ids.Count==0||ids.Count>128||!types.SequenceEqual(new[]{"Actor","GuestStar"}))throw new Exception("Invalid cast batch");
            var allowed=Root.Folders[ExpectedUser].SelectMany(f=>Titles[f.Id]).Where(t=>!t.Hidden&&!t.Virtual&&!t.Missing&&t.Kind!=BaseItemKind.Audio).ToDictionary(t=>t.Id);
            if(ids.Any(id=>!allowed.ContainsKey(id)))throw new Exception("Inaccessible title cast requested");CreditCalls++;
            var result=ids.ToDictionary(id=>id,id=>(IReadOnlyList<string>)allowed[id].Credits.Where(c=>types.Contains(c.Type)).Select(c=>c.Name).Distinct().ToArray());
            result[Guid.NewGuid()]=["Hidden actor"];return result;
        }
        if(name=="GetPerson"){Lookups++;var n=(string)args![0]!;LookedUp.Add(n);return Persons[n];}
        if(name is "GetPeopleItems" or "GetPeopleNames" or "GetPeople"){GlobalCalls++;throw new Exception("Forbidden global people query");}
        throw new NotSupportedException(name);
    }
    private static BaseItem Render(ActorTitle t){BaseItem item=t.Kind switch{BaseItemKind.Series=>new MediaBrowser.Controller.Entities.TV.Series(),BaseItemKind.Episode=>new MediaBrowser.Controller.Entities.TV.Episode{SeriesId=t.SeriesId,ParentIndexNumber=t.SeasonNumber},_=>new Movie()};item.Id=t.Id;item.Name=t.Name??"Title";item.Genres=["Drama"];item.ProductionYear=2024;item.CommunityRating=8.5f;if(t.HasImage)item.ImageInfos=[new ItemImageInfo{Type=MediaBrowser.Model.Entities.ImageType.Primary,Path="series-poster.jpg"}];return item;}
}
public class ActorUsers : DispatchProxy {
    public User[] Users=[];public UserPolicy Policy=new();
    protected override object? Invoke(MethodInfo? method,object?[]? args)=>method!.Name switch {
        "GetUserById"=>Users.FirstOrDefault(u=>u.Id==(Guid)args![0]!),
        "GetUserDto"=>new UserDto{Id=((User)args![0]!).Id,Policy=Policy},
        _=>throw new NotSupportedException(method.Name)
    };
}
public class ActorImages : DispatchProxy {protected override object? Invoke(MethodInfo? method,object?[]? args)=>method?.Name=="GetImageCacheTag"?"primary-"+((BaseItem)args![0]!).Id.ToString("N"):throw new NotSupportedException(method?.Name);}
public class ActorPaths : DispatchProxy {public string Root="";protected override object? Invoke(MethodInfo? method,object?[]? args)=>method?.Name.StartsWith("get_")==true?Root:null;}
public class ActorSerializer : DispatchProxy {protected override object? Invoke(MethodInfo? method,object?[]? args)=>null;}
