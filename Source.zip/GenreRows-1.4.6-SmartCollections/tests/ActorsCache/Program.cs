using Jellyfin.Plugin.GenreRows;
using System.Text.Json.Nodes;

var root=Path.Combine(Environment.GetEnvironmentVariable("GR_TEST_TEMP")??Path.GetTempPath(),"actor-cache-"+Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
var checks=0;
void Check(bool ok,string name){if(!ok)throw new Exception(name);Console.WriteLine("PASS "+name);checks++;}
try {
    if(args.Contains("--tmdb-live")){await PopularityLive.Run(Check);return;}
    var cache=new ActorsCache(root);var key=ActorsCache.Digest("user-a|policy-1|library-a");var builds=0;
    var first=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);var finish=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    async Task<ActorCard[]> Build(Action<ActorCard[]> publish){Interlocked.Increment(ref builds);var items=Enumerable.Range(0,600).Select(n=>new ActorCard(n.ToString(),"Actor "+n,"existing-image-tag")).ToArray();publish(items.Take(100).ToArray());first.SetResult();await finish.Task;return items;}
    await cache.Page(key,0,Build);await cache.Page(key,0,Build);await first.Task.WaitAsync(TimeSpan.FromSeconds(5));
    var partial=await cache.Page(key,0,Build);
    Check(partial.Loading && partial.Items.Length==100,"first 100 actors visible while the remaining scan is still running");
    Check(builds==1,"concurrent browsers join one server-side catalog build");
    finish.SetResult();ActorCatalogPage done;
    do{await Task.Delay(10);done=await cache.Page(key,0,Build);}while(done.Loading);
    Check(done.TotalCount==600 && done.Items.Length==100,"complete catalog served in bounded pages");
    var second=await cache.Page(key,100,Build);Check(second.Items[0].Id=="100" && second.NextStartIndex==200,"pagination has stable offsets");
    var file=Path.Combine(root,key+".json");for(int i=0;i<100 && !File.Exists(file);i++)await Task.Delay(10);
    Check(File.Exists(file),"catalog is persisted under the server Actors cache directory");
    var cold=new ActorsCache(root);var hit=await cold.Page(key,0,_=>throw new Exception("unexpected scan"));
    Check(!hit.Loading && hit.TotalCount==600 && hit.Revision==done.Revision,"plugin restart reuses the disk snapshot without querying every actor again");
    var otherKey=ActorsCache.Digest("user-b|policy-1|library-b");
    Task<ActorCard[]> Other(Action<ActorCard[]> _) => Task.FromResult(new[]{new ActorCard("b-only","Only B",null)});
    ActorCatalogPage other;do{other=await cold.Page(otherKey,0,Other);await Task.Delay(10);}while(other.Loading);
    Check(other.Items.Single().Id=="b-only","another user's scope never reuses the first user's actors");
    Check(ActorsCache.Digest("user-a|policy-2|library-a")!=key,"permission changes use a distinct snapshot key");
    var json=JsonNode.Parse(await File.ReadAllTextAsync(file))!;json["Saved"]=DateTimeOffset.UtcNow.AddHours(-7);await File.WriteAllTextAsync(file,json.ToJsonString());
    var expired=new ActorsCache(root);ActorCatalogPage refreshed;do{refreshed=await expired.Page(key,0,Other);await Task.Delay(10);}while(refreshed.Loading);
    Check(refreshed.Items.Single().Id=="b-only" && refreshed.Revision!=done.Revision,"expired snapshots rebuild and change the client revision");
    var rejected=false;try{await cache.Page("../outside",0,Other);}catch(ArgumentException){rejected=true;}
    Check(rejected,"cache keys cannot choose filesystem paths");
    await CatalogFixture.Run(root,Check);
    await ActorGroupingFixture.Run(Path.Combine(root,"grouping"),Check);
    await PopularityFixture.Run(root,Check);
Console.WriteLine($"SUCCESS {checks} persistent actor-cache checks");
} finally {Directory.Delete(root,true);}
