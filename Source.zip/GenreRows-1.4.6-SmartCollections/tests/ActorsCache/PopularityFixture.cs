using System.IO.Compression;
using System.Text;
using System.Net;
using System.Text.Json;
using Jellyfin.Plugin.GenreRows;

public static class PopularityFixture {
    public static async Task Run(string root,Action<bool,string> check) {
        byte[] Export(){using var output=new MemoryStream();using(var gz=new GZipStream(output,CompressionMode.Compress,true))gz.Write(Encoding.UTF8.GetBytes("{\"id\":100,\"popularity\":120,\"name\":\"Famous\"}\n{\"id\":101,\"popularity\":15}\n{\"id\":102,\"popularity\":999,\"adult\":true}\n{\"id\":999,\"popularity\":900}\n"));return output.ToArray();}
        using(var stream=new MemoryStream(Export())){var scores=await ActorPopularityService.ReadExport(stream,new HashSet<int>{100,101,102},CancellationToken.None);check(scores.Count==2&&scores[100]==120&&!scores.ContainsKey(999)&&!scores.ContainsKey(102),"TMDB export parser retains only requested normal-library IDs and excludes unrelated/adult rows");}
        var calls=0;var handler=new PopularityHandler(request=>{calls++;if(request.RequestUri?.Host!="files.tmdb.org"||!request.RequestUri.AbsolutePath.StartsWith("/p/exports/person_ids_")||request.RequestUri.Query.Length>0||request.Headers.Authorization is not null)throw new Exception("Unexpected/private request");return new(HttpStatusCode.OK){Content=new ByteArrayContent(Export())};});
        using var http=new HttpClient(handler);var cache=Path.Combine(root,"popularity");
        using(var service=new ActorPopularityService(cache,http)){
            var first=service.Get(["100","101"],true);check(first.Loading,"popularity refresh starts asynchronously without blocking the first gallery page");
            ActorPopularitySnapshot page;do{await Task.Delay(20);page=service.Get(["100","101"],true);}while(page.Loading);
            check(calls==1&&page.Values[100]==120,"one public export request supplies multiple actor scores without sending actor IDs");
            for(int i=0;i<20;i++)service.Get(["100","101"],true);check(calls==1,"warm popularity data does not trigger per-actor or per-browser downloads");
            check(service.Get(["100"],false).Values.Count==0,"disabling external popularity uses the local-only path");
        }
        using(var restored=new ActorPopularityService(cache,http)){var page=restored.Get(["100","101"],true);check(!page.Loading&&page.Values[101]==15&&calls==1,"popularity scores survive restart without another download");}
        using(var offlineHttp=new HttpClient(new PopularityHandler(_=>new(HttpStatusCode.ServiceUnavailable))))
        using(var offline=new ActorPopularityService(Path.Combine(root,"offline"),offlineHttp)){
            ActorPopularitySnapshot page;do{await Task.Delay(20);page=offline.Get(["100"],true);}while(page.Loading);check(page.Values.Count==0&&!page.Loading,"TMDB failure leaves local Discover usable and backs off retries");
        }
        check(!File.ReadAllText(Path.Combine(cache,"scores.json")).Contains("Famous"),"popularity cache stores numeric scores rather than unrelated names or biographies");
    }
}
public class PopularityHandler(Func<HttpRequestMessage,HttpResponseMessage> respond):HttpMessageHandler {
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>Task.FromResult(respond(request));
}
