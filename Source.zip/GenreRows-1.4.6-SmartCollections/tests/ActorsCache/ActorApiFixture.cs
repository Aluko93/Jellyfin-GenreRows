using System.Net.Http.Json;
using System.Reflection;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.Json;
using Jellyfin.Plugin.GenreRows;
using Jellyfin.Database.Implementations.Entities;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Dto;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.Extensions.Options;

public static class ActorApiFixture {
    public static async Task Run(ActorsCatalogService service,ILibraryManager library,IUserManager users,Guid a,Guid b,ActorLibrary fixture,Action<bool,string> check) {
        var data=DispatchProxy.Create<IUserDataManager,ActorData>();
        var builder=WebApplication.CreateBuilder();builder.Logging.ClearProviders();builder.WebHost.UseUrls("http://127.0.0.1:0");
        builder.Services.AddSingleton(service);builder.Services.AddSingleton(library);builder.Services.AddSingleton(users);builder.Services.AddSingleton(data);
        builder.Services.AddAuthentication("actor-test").AddScheme<AuthenticationSchemeOptions,ActorAuthentication>("actor-test",_=>{});
        builder.Services.AddAuthorization(o=>o.AddPolicy("RequiresElevation",p=>p.RequireRole("Admin")));
        builder.Services.AddControllers().AddJsonOptions(o=>o.JsonSerializerOptions.PropertyNamingPolicy=null).AddApplicationPart(typeof(ActorsController).Assembly);
        await using var app=builder.Build();app.UseAuthentication();app.UseAuthorization();app.MapControllers();await app.StartAsync();
        using var client=new HttpClient(new HttpClientHandler{UseProxy=false}){BaseAddress=new Uri(app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>()!.Addresses.Single())};
        var actor=fixture.Persons["Actor A 0"].Id.ToString("N");var foreign=fixture.Persons["Actor B only"].Id.ToString("N");
        foreach(var path in new[]{"Favorites","Details/"+actor,"Titles/"+actor+"?LibraryId="+fixture.Root.Folders[a][0].Id})check((int)(await client.GetAsync("GenreRows/Actors/"+path)).StatusCode==401,"anonymous ActorFlix route denied: "+path.Split('/')[0]);
        var logo=await client.GetAsync("GenreRows/Actors/TmdbLogo");check(logo.IsSuccessStatusCode&&logo.Content.Headers.ContentType?.MediaType=="image/svg+xml","TMDB attribution logo is a static public resource");
        client.DefaultRequestHeaders.Add("X-Actor-User",a.ToString());
        var response=await client.GetAsync("GenreRows/Actors/Details/"+actor);var details=await response.Content.ReadFromJsonAsync<JsonElement>();
        check(response.IsSuccessStatusCode&&details.GetProperty("Biography").GetString()=="A biography from Jellyfin."&&!details.GetProperty("IsFavorite").GetBoolean(),"authorized actor biography and native favorite status are returned");
        check(response.Headers.CacheControl?.NoStore==true,"ActorFlix profile responses are not cached publicly");
        check((int)(await client.GetAsync("GenreRows/Actors/Details/"+foreign)).StatusCode==404,"actor from another user's library is not exposed");
        var favorite=await client.PostAsJsonAsync("GenreRows/Actors/Favorite/"+actor,new{IsFavorite=true});
        var ids=await client.GetFromJsonAsync<JsonElement>("GenreRows/Actors/Favorites");
        check(favorite.IsSuccessStatusCode&&ids.GetProperty("Ids").EnumerateArray().Single().GetString()==actor,"actor favorite is saved and returned for the authenticated user");
        check((int)(await client.PostAsJsonAsync("GenreRows/Actors/Favorite/"+foreign,new{IsFavorite=true})).StatusCode==404,"inaccessible actor cannot be added to favorites");
        var titles=await client.GetFromJsonAsync<JsonElement>("GenreRows/Actors/Titles/"+actor+"?LibraryId="+fixture.Root.Folders[a][0].Id);
        check(titles.GetProperty("Items").GetArrayLength()==3&&titles.GetProperty("Items")[0].GetProperty("Genres")[0].GetString()=="Drama","profile titles use the actual actor and authorized library, with genre/year metadata");
        check(titles.GetProperty("Items")[0].GetProperty("CommunityRating").GetDouble()==8.5,"actor title endpoint exposes the stored Jellyfin rating for sorting");
        check((int)(await client.GetAsync("GenreRows/Actors/Titles/"+actor+"?LibraryId="+fixture.Root.Folders[b][0].Id)).StatusCode==404,"client cannot substitute a forbidden library ID");
        client.DefaultRequestHeaders.Remove("X-Actor-User");client.DefaultRequestHeaders.Add("X-Actor-User",b.ToString());fixture.ExpectedUser=b;
        for(int i=0;i<300;i++){var page=await service.Page(b,0);if(!page.Loading)break;await Task.Delay(10);}
        var others=await client.GetFromJsonAsync<JsonElement>("GenreRows/Actors/Favorites");
        check(others.GetProperty("Ids").GetArrayLength()==0,"favorites are separated by authenticated Jellyfin user");
        check((int)(await client.GetAsync("GenreRows/Actors/Details/"+actor)).StatusCode==404,"profile access is rechecked after account switch");
        fixture.ExpectedUser=a;client.DefaultRequestHeaders.Remove("X-Actor-User");client.DefaultRequestHeaders.Add("X-Actor-User",a.ToString());
        await client.PostAsJsonAsync("GenreRows/Actors/Favorite/"+actor,new{IsFavorite=false});
        check((await client.GetFromJsonAsync<JsonElement>("GenreRows/Actors/Favorites")).GetProperty("Ids").GetArrayLength()==0,"removing a favorite persists through the same native service");
        await app.StopAsync();
    }
}
public class ActorData:DispatchProxy {
    public readonly Dictionary<(Guid User,Guid Item),UserItemData> Values=new();
    private UserItemData Value(Guid user,Guid item){if(!Values.TryGetValue((user,item),out var data))Values[(user,item)]=data=new UserItemData{Key=item.ToString("N")};return data;}
    protected override object? Invoke(MethodInfo? m,object?[]? args){
        if(m!.Name=="GetUserData")return Value(((User)args![0]!).Id,((BaseItem)args[1]!).Id);
        if(m.Name=="GetUserDataBatch"){var user=(User)args![1]!;return ((IReadOnlyList<BaseItem>)args[0]!).ToDictionary(i=>i.Id,i=>Value(user.Id,i.Id));}
        if(m.Name=="SaveUserData"){var user=(User)args![0]!;var item=(BaseItem)args[1]!;var dto=(UpdateUserItemDataDto)args[2]!;if(dto.IsFavorite is{} favorite)Value(user.Id,item.Id).IsFavorite=favorite;return null;}
        throw new NotSupportedException(m.Name);
    }
}
public class ActorAuthentication(IOptionsMonitor<AuthenticationSchemeOptions> options,ILoggerFactory logger,UrlEncoder encoder):AuthenticationHandler<AuthenticationSchemeOptions>(options,logger,encoder) {
    protected override Task<AuthenticateResult> HandleAuthenticateAsync(){
        if(!Guid.TryParse(Request.Headers["X-Actor-User"],out var user))return Task.FromResult(AuthenticateResult.NoResult());
        return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(new ClaimsIdentity([new Claim("Jellyfin-UserId",user.ToString())],"actor-test")),"actor-test")));
    }
}
