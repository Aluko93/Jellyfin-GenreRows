using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Text.Json;

namespace Jellyfin.Plugin.GenreRows;

public sealed record ActorPopularitySnapshot(string Version, IReadOnlyDictionary<int, double> Values, bool Loading);

/// <summary>One public TMDB export download per week; retain scores only for locally requested person IDs.</summary>
public sealed class ActorPopularityService : IDisposable
{
    private static readonly HttpClient SharedClient = new(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = TimeSpan.FromMinutes(3) };
    private readonly HttpClient client;
    private readonly string directory;
    private readonly Func<DateTimeOffset> clock;
    private readonly object gate = new();
    private readonly HashSet<int> wanted = [];
    private HashSet<int> known = [];
    private Dictionary<int, double> values = [];
    private DateTimeOffset saved, retry;
    private string version = "none";
    private bool loaded, running;
    private readonly CancellationTokenSource stopping = new();
    private sealed record DiskScores(DateTimeOffset Saved, string Version, int[] Known, Dictionary<int, double> Values);
    public ActorPopularityService(string directory, HttpClient? client = null, Func<DateTimeOffset>? clock = null) {
        this.directory = directory; this.client = client ?? SharedClient; this.clock = clock ?? (() => DateTimeOffset.UtcNow);
    }
    public ActorPopularitySnapshot Get(IEnumerable<string?> ids, bool enabled) {
        if (!enabled) return new("disabled", new Dictionary<int, double>(), false);
        lock (gate) {
            if (!loaded) {
                loaded = true;
                try {
                    var file = Path.Combine(directory, "scores.json");
                    if (File.Exists(file) && new FileInfo(file).Length <= 8 * 1024 * 1024) {
                        var disk = JsonSerializer.Deserialize<DiskScores>(File.ReadAllText(file));
                        if (disk?.Known is not null && disk.Values is not null && disk.Known.Length <= 100000 && disk.Values.Count <= 100000 && disk.Saved <= clock().AddMinutes(1)) {
                            saved = disk.Saved; version = disk.Version; known = disk.Known.ToHashSet();
                            values = disk.Values.Where(p => p.Key > 0 && double.IsFinite(p.Value) && p.Value >= 0).ToDictionary();
                        }
                    }
                } catch (Exception e) when (e is IOException or UnauthorizedAccessException or JsonException) { }
            }
            foreach (var id in ids) if (wanted.Count < 100000 && int.TryParse(id, out var number) && number > 0) wanted.Add(number);
            if (!running && wanted.Count > 0 && clock() >= retry && (clock() - saved >= TimeSpan.FromDays(7) || wanted.Except(known).Any())) {
                running = true; _ = Task.Run(Refresh);
            }
            return new(version, values, running); // Published dictionaries are replaced, never mutated.
        }
    }
    private async Task Refresh() {
        try {
            await Task.Delay(750, stopping.Token).ConfigureAwait(false); // Collect IDs from progressive catalog pages.
            Directory.CreateDirectory(directory);
            var archive = Path.Combine(directory, "persons.json.gz");
            if (!File.Exists(archive) || clock().UtcDateTime - File.GetLastWriteTimeUtc(archive) >= TimeSpan.FromDays(7)) {
                var date = clock().AddDays(-1).ToString("MM_dd_yyyy", CultureInfo.InvariantCulture);
                using var response = await client.GetAsync("https://files.tmdb.org/p/exports/person_ids_" + date + ".json.gz", HttpCompletionOption.ResponseHeadersRead, stopping.Token).ConfigureAwait(false);
                response.EnsureSuccessStatusCode();
                if (response.Content.Headers.ContentLength is > 128 * 1024 * 1024) throw new IOException("TMDB export exceeds download limit.");
                var temporary = archive + "." + Guid.NewGuid().ToString("N") + ".tmp";
                try {
                    await using (var input = await response.Content.ReadAsStreamAsync(stopping.Token).ConfigureAwait(false))
                    await using (var output = File.Create(temporary)) {
                        var buffer = new byte[81920]; long total = 0; int count;
                        while ((count = await input.ReadAsync(buffer, stopping.Token).ConfigureAwait(false)) > 0) {
                            total += count; if (total > 128L * 1024 * 1024) throw new IOException("TMDB export exceeds download limit.");
                            await output.WriteAsync(buffer.AsMemory(0, count), stopping.Token).ConfigureAwait(false);
                        }
                    }
                    File.Move(temporary, archive, true);
                } finally { if (File.Exists(temporary)) File.Delete(temporary); }
            }
            HashSet<int> requested;
            lock (gate) requested = wanted.ToHashSet();
            await using var source = File.OpenRead(archive);
            var result = await ReadExport(source, requested, stopping.Token).ConfigureAwait(false);
            var now = clock(); var nextVersion = now.ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
            lock (gate) { values = result; known = requested; saved = now; version = nextVersion; retry = now.AddMinutes(1); }
            var scoresFile = Path.Combine(directory, "scores.json"); var pending = scoresFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try { await File.WriteAllTextAsync(pending, JsonSerializer.Serialize(new DiskScores(now, nextVersion, requested.ToArray(), result)), stopping.Token).ConfigureAwait(false); File.Move(pending, scoresFile, true); }
            finally { if (File.Exists(pending)) File.Delete(pending); }
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or HttpRequestException or OperationCanceledException or JsonException) {
            lock (gate) retry = clock().AddHours(6); // Offline operation uses retained/local metadata; never block the gallery.
        } finally { lock (gate) running = false; }
    }
    public static async Task<Dictionary<int, double>> ReadExport(Stream source, IReadOnlySet<int> wanted, CancellationToken token) {
        using var gzip = new GZipStream(source, CompressionMode.Decompress, leaveOpen: true);
        using var reader = new StreamReader(gzip, Encoding.UTF8);
        var scores = new Dictionary<int, double>(); long expanded = 0;
        while (await reader.ReadLineAsync(token).ConfigureAwait(false) is { } line) {
            expanded += line.Length;
            if (expanded > 1024L * 1024 * 1024 || line.Length > 32768) throw new IOException("TMDB export exceeds parsing limit.");
            if (string.IsNullOrWhiteSpace(line)) continue;
            using var json = JsonDocument.Parse(line); var row = json.RootElement;
            if (row.TryGetProperty("id", out var id) && id.ValueKind == JsonValueKind.Number && id.TryGetInt32(out var number) && wanted.Contains(number) &&
                row.TryGetProperty("popularity", out var score) && score.ValueKind == JsonValueKind.Number && score.TryGetDouble(out var value) && double.IsFinite(value) && value >= 0 &&
                (!row.TryGetProperty("adult", out var adult) || adult.ValueKind != JsonValueKind.True)) scores[number] = value;
        }
        return scores;
    }
    public void Dispose() => stopping.Cancel();
}
