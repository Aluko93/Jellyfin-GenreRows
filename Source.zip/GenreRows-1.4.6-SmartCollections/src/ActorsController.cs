using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Entities;

namespace Jellyfin.Plugin.GenreRows;

[ApiController, Authorize, Route("GenreRows/Actors")]
public sealed class ActorsController : ControllerBase
{
    [HttpGet("TmdbLogo"), AllowAnonymous, ResponseCache(Duration = 86400)]
    public IActionResult TmdbLogo() => File(typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.Web.tmdb.svg")!, "image/svg+xml");
    private Guid CurrentUser => Guid.TryParse(User.FindFirst("Jellyfin-UserId")?.Value, out var user) ? user : Guid.Empty;
    private bool Enabled => Plugin.Instance?.Configuration.ActorsEnabled == true;
    [HttpGet("Catalog")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Catalog([FromServices] ActorsCatalogService catalog, int startIndex = 0) {
        if (Plugin.Instance?.Configuration.ActorsEnabled != true) return Forbid();
        if (!Guid.TryParse(User.FindFirst("Jellyfin-UserId")?.Value, out var user)) return Unauthorized();
        try { return Ok(await catalog.Page(user, Math.Max(0, startIndex))); }
        catch (UnauthorizedAccessException) { return Forbid(); }
    }
    [HttpPost("Refresh"), Authorize(Policy = "RequiresElevation")]
    public IActionResult Refresh([FromServices] ActorsCatalogService catalog) { catalog.Invalidate(); return NoContent(); }
    [HttpGet("Status")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public object Status() => new { Enabled, PopularityEnabled = Plugin.Instance?.Configuration.ActorsPopularityEnabled == true };

    [HttpGet("Favorites")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Favorites([FromServices] ActorsCatalogService catalog, [FromServices] IUserManager users, [FromServices] IUserDataManager data) {
        if (!Enabled || CurrentUser == Guid.Empty) return Forbid();
        var user = users.GetUserById(CurrentUser); if (user is null) return Forbid();
        var actors = await catalog.AccessibleActors(CurrentUser); var favorites = new List<string>();
        foreach (var group in actors.Chunk(256)) {
            var items = group.Select(p => (BaseItem)new Person { Id = Guid.Parse(p.Id), Name = p.Name }).ToArray();
            var allowed = items.Select(p => p.Id).ToHashSet();
            favorites.AddRange(data.GetUserDataBatch(items, user).Where(p => allowed.Contains(p.Key) && p.Value.IsFavorite).Select(p => p.Key.ToString("N")));
        }
        return Ok(new { Ids = favorites });
    }
    [HttpGet("Details/{actorId:guid}")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Details(Guid actorId, [FromServices] ActorsCatalogService catalog, [FromServices] ILibraryManager library,
        [FromServices] IUserManager users, [FromServices] IUserDataManager data) {
        if (!Enabled || CurrentUser == Guid.Empty) return Forbid();
        var actor = (await catalog.AccessibleActors(CurrentUser)).FirstOrDefault(p => p.Id == actorId.ToString("N"));
        if (actor is null) return NotFound();
        var user = users.GetUserById(CurrentUser); if (user is null) return Forbid();
        var person = library.GetPerson(actor.Name); if (person?.Id != actorId) return NotFound();
        return Ok(new { actor.Id, actor.Name, actor.PrimaryImageTag, actor.MovieCount, Biography = person.Overview ?? "",
            BirthDate = person.PremiereDate, BirthPlaces = person.ProductionLocations ?? [], IsFavorite = data.GetUserData(user, person)?.IsFavorite == true });
    }
    public sealed record FavoriteRequest(bool IsFavorite);
    [HttpPost("Favorite/{actorId:guid}"), RequestSizeLimit(1024)]
    public async Task<IActionResult> Favorite(Guid actorId, FavoriteRequest request, [FromServices] ActorsCatalogService catalog,
        [FromServices] ILibraryManager library, [FromServices] IUserManager users, [FromServices] IUserDataManager data) {
        if (!Enabled || CurrentUser == Guid.Empty) return Forbid();
        var actor = (await catalog.AccessibleActors(CurrentUser)).FirstOrDefault(p => p.Id == actorId.ToString("N"));
        if (actor is null) return NotFound();
        var user = users.GetUserById(CurrentUser); if (user is null) return Forbid();
        var person = library.GetPerson(actor.Name); if (person?.Id != actorId) return NotFound();
        data.SaveUserData(user, person, new UpdateUserItemDataDto { IsFavorite = request.IsFavorite }, UserDataSaveReason.UpdateUserData);
        return NoContent();
    }
    [HttpGet("Titles/{actorId:guid}")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Titles(Guid actorId, Guid libraryId, int startIndex, [FromServices] ActorsCatalogService catalog) {
        if (!Enabled || CurrentUser == Guid.Empty) return Forbid();
        var result = await catalog.Titles(CurrentUser, actorId, libraryId, startIndex); return result is null ? NotFound() : Ok(result);
    }

    public sealed record Settings(bool Enabled, bool? PopularityEnabled = null);
    [HttpPost("Configuration"), Authorize(Policy = "RequiresElevation"), RequestSizeLimit(1024)]
    public IActionResult Configure(Settings settings)
    {
        if (Plugin.Instance is not { } plugin) return StatusCode(503);
        plugin.Configuration.ActorsEnabled = settings.Enabled;
        if (settings.PopularityEnabled is { } popularity) plugin.Configuration.ActorsPopularityEnabled = popularity;
        plugin.SaveConfiguration();
        return NoContent();
    }
}
