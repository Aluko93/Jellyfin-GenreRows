using MediaBrowser.Common.Configuration;
using MediaBrowser.Common.Plugins;
using MediaBrowser.Model.Plugins;
using MediaBrowser.Model.Serialization;

namespace Jellyfin.Plugin.GenreRows;

public sealed class Configuration : BasePluginConfiguration
{
    public SmartCollections.SmartConfiguration SmartCollections { get; set; } = new();
    public bool ActorsEnabled { get; set; }
    public bool ActorsPopularityEnabled { get; set; } = true;
    public Adult.AdultConfiguration Adult { get; set; } = new();
    // Keep legacy fields for XML compatibility and rollback; version 2 uses rows below.
    public int SchemaVersion { get; set; }
    public bool Enabled { get; set; } = true;
    public bool AllGenres { get; set; } = true;
    public string[] Genres { get; set; } = [];
    public int Limit { get; set; } = 20;
    public string MediaType { get; set; } = "Both";
    public GenreSelection[] MovieRows { get; set; } = [];
    public GenreSelection[] SeriesRows { get; set; } = [];
    public int MovieLimit { get; set; } = 20;
    public int SeriesLimit { get; set; } = 20;
    public GenreGroup[] Groups { get; set; } = [];
}

public sealed class GenreGroup
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public string MediaType { get; set; } = "Movie";
    public string[] LibraryIds { get; set; } = [];
    public string[] Genres { get; set; } = [];
    public int Limit { get; set; } = 20;
}

public sealed class GenreSelection
{
    public string Genre { get; set; } = "";
    public string[] LibraryIds { get; set; } = [];
}

public sealed class Plugin : BasePlugin<Configuration>, IHasWebPages
{
    public Plugin(IApplicationPaths paths, IXmlSerializer serializer) : base(paths, serializer) => Instance = this;
    public static Plugin? Instance { get; private set; }
    public override string Name => "Genre Rows";
    public override string Description => "Righe per genere nella Home web, senza dipendenze da altri plugin.";
    public override Guid Id => new("f6a47162-497f-472f-aadf-323c766ac182");
    public IEnumerable<PluginPageInfo> GetPages() => [new() {
        Name = "GenreRows", DisplayName = "Genre Rows", EnableInMainMenu = true,
        MenuIcon = "category", EmbeddedResourcePath = "Jellyfin.Plugin.GenreRows.Web.config.html"
    }, new() {
        Name = "GenreRowsAdult", DisplayName = "Genre Rows — Adult", EnableInMainMenu = true,
        MenuIcon = "lock", EmbeddedResourcePath = "Jellyfin.Plugin.GenreRows.Adult.Web.config.html"
    }, new() {
        Name = "GenreRowsActors", DisplayName = "Genre Rows — Actors", EnableInMainMenu = true,
        MenuIcon = "people", EmbeddedResourcePath = "Jellyfin.Plugin.GenreRows.Web.actors-config.html"
    }, new() {
        Name = "GenreRowsSmartCollections", DisplayName = "Genre Rows — Smart Collections", EnableInMainMenu = true,
        MenuIcon = "auto_awesome", EmbeddedResourcePath = "Jellyfin.Plugin.GenreRows.SmartCollections.Web.config.html"
    }];
}
