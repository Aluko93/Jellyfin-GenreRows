using System.Text;
using MediaBrowser.Common.Net;
using MediaBrowser.Controller;
using MediaBrowser.Controller.Configuration;
using MediaBrowser.Controller.Plugins;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace Jellyfin.Plugin.GenreRows;

public sealed class ServiceRegistration : IPluginServiceRegistrator
{
    public void RegisterServices(IServiceCollection services, IServerApplicationHost host) {
        services.AddTransient<IStartupFilter, WebStartup>();
        services.AddHostedService<Adult.AdultPlaybackReaper>();
        services.AddSingleton<ActorsCatalogService>();
        services.AddSingleton<SmartCollections.SmartService>();
    }
}

public sealed class WebStartup(IServerConfigurationManager config) : IStartupFilter
{
    public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next) => app => {
        app.UseMiddleware<IndexMiddleware>(config.GetNetworkConfiguration().BaseUrl);
        next(app);
    };
}

// Buffer only the small index response. The original Jellyfin pipeline still handles
// BaseUrl, HTTPS redirects and static-file selection. No files on disk are changed.
public sealed class IndexMiddleware(RequestDelegate next, string baseUrl)
{
    private readonly string prefix = "/" + baseUrl.Trim('/');
    public async Task InvokeAsync(HttpContext context)
    {
        var root = prefix == "/" ? "" : prefix;
        var path = context.Request.Path.Value;
        if (!HttpMethods.IsGet(context.Request.Method) ||
            (path != root + "/web/index.html" && path != root + "/web/"))
        {
            await next(context);
            return;
        }

        var names = new[] { "Accept-Encoding", "If-None-Match", "If-Modified-Since", "Range", "If-Range" };
        var saved = names.ToDictionary(n => n, n => context.Request.Headers[n]);
        foreach (var name in names) context.Request.Headers.Remove(name);
        var original = context.Response.Body;
        await using var buffer = new MemoryStream();
        context.Response.Body = buffer;
        try
        {
            await next(context);
            var bytes = buffer.ToArray();
            if (context.Response.StatusCode == 200 &&
                context.Response.ContentType?.StartsWith("text/html", StringComparison.OrdinalIgnoreCase) == true &&
                !context.Response.Headers.ContainsKey("Content-Encoding"))
            {
                var html = Encoding.UTF8.GetString(bytes);
                var closing = html.LastIndexOf("</body>", StringComparison.OrdinalIgnoreCase);
                if (closing >= 0 && !html.Contains("id=\"genre-rows-loader\"", StringComparison.Ordinal))
                {
                    // Relative URL also works behind a reverse proxy with a path prefix.
                    html = html.Insert(closing, "<script id=\"genre-rows-loader\" defer src=\"../GenreRows/client.js\"></script>");
                    bytes = Encoding.UTF8.GetBytes(html);
                }
                context.Response.Headers.Remove("ETag");
                context.Response.Headers.Remove("Last-Modified");
                context.Response.Headers.CacheControl = "no-store";
                context.Response.ContentLength = bytes.Length;
            }
            context.Response.Body = original;
            await original.WriteAsync(bytes, context.RequestAborted);
        }
        finally
        {
            context.Response.Body = original;
            foreach (var pair in saved) context.Request.Headers[pair.Key] = pair.Value;
        }
    }
}
