using MediaBrowser.Controller.Library;

namespace Jellyfin.Plugin.GenreRows.Adult;

// Read-only, direct filesystem access. Never create Jellyfin BaseItems or playback events.
public sealed class AdultLibraryService(ILibraryManager library)
{
    public static readonly HashSet<string> VideoExtensions = new(StringComparer.OrdinalIgnoreCase)
        { ".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".ts", ".wmv" };
    public static readonly HashSet<string> ImageExtensions = new(StringComparer.OrdinalIgnoreCase)
        { ".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp" };
    private static readonly StringComparison Comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
    private static string Full(string path) => Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
    private static bool Within(string child, string parent) => child.Equals(parent, Comparison) ||
        child.StartsWith(Path.TrimEndingDirectorySeparator(parent) + Path.DirectorySeparatorChar, Comparison);
    public static bool Overlaps(string a, string b) => Within(Full(a), Full(b)) || Within(Full(b), Full(a));
    public static void NoLinks(string path)
    {
        for (var p = Path.GetFullPath(path); !string.IsNullOrEmpty(p); p = Path.GetDirectoryName(p))
            if ((File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0) throw new IOException("Collegamenti non ammessi.");
    }
    public string Root(AdultConfiguration c)
    {
        if (!Path.IsPathFullyQualified(c.RootPath)) throw new IOException("Percorso assoluto richiesto.");
        var root = Full(c.RootPath);
        if (!Directory.Exists(root)) throw new IOException("Cartella non disponibile.");
        NoLinks(root);
        // Refuse parents as well as children of any configured library, including disabled libraries.
        foreach (var folder in library.GetVirtualFolders())
        foreach (var location in folder.Locations ?? []) {
            NoLinks(location);
            if (Overlaps(root, location) || MountAliasesOverlap(root, location)) throw new IOException("Sovrapposizione con una libreria Jellyfin.");
        }
        return root;
    }
    // Bind mounts can expose the same backing directory under unrelated container paths.
    public static bool MountAliasesOverlap(string first, string second) {
        if (!OperatingSystem.IsLinux()) return false;
        var mounts = File.ReadAllLines("/proc/self/mountinfo").Select(line => line.Split(' ')).Where(x => x.Length > 5).ToArray();
        static string Decode(string s) => s.Replace("\\040", " ").Replace("\\011", "\t").Replace("\\134", "\\");
        (string Device, string Path) Resolve(string value) {
            var path = Full(value);
            var mount = mounts.Where(x => Within(path, Decode(x[4]))).OrderByDescending(x => Decode(x[4]).Length).FirstOrDefault()
                ?? throw new IOException("Mount identity unavailable.");
            return (mount[2], Full(Path.Combine(Decode(mount[3]), Path.GetRelativePath(Decode(mount[4]), path))));
        }
        var a = Resolve(first); var b = Resolve(second);
        return a.Device == b.Device && Overlaps(a.Path, b.Path);
    }
    public static string Child(string parent, string name, bool directory)
    {
        if (string.IsNullOrWhiteSpace(name) || name is "." or ".." || name.Length > 255 || name.IndexOfAny(['/', '\\', ':', '\0']) >= 0)
            throw new IOException("Nome non valido.");
        var path = Full(Path.Combine(parent, name));
        if (!Within(path, Full(parent)) || (directory ? !Directory.Exists(path) : !File.Exists(path))) throw new IOException("Elemento non disponibile.");
        NoLinks(path); return path;
    }
    public string[] CategoryFolders(AdultConfiguration c) => Directory.EnumerateDirectories(Root(c))
        .Where(p => (File.GetAttributes(p) & FileAttributes.ReparsePoint) == 0)
        .Select(Path.GetFileName).Where(n => !string.IsNullOrEmpty(n)).Cast<string>()
        .OrderBy(n => n, StringComparer.CurrentCultureIgnoreCase).Take(500).ToArray();
    private static AdultCategoryConfiguration Presentation(AdultConfiguration c, string folder) =>
        (c.Categories ?? []).FirstOrDefault(x => string.Equals(x.FolderName, folder, Comparison)) ?? new() { FolderName = folder };
    private static string ImageName(string directory, string configured, bool legacyFolderCover)
    {
        if (!string.IsNullOrWhiteSpace(configured)) return configured.Trim();
        if (legacyFolderCover) {
            var images = Directory.EnumerateFiles(directory)
                .Select(Path.GetFileName).Where(n => !string.IsNullOrWhiteSpace(n) && ImageExtensions.Contains(Path.GetExtension(n)))
                .Cast<string>().OrderBy(n => n, StringComparer.OrdinalIgnoreCase).ToArray();
            return images.FirstOrDefault(n => string.Equals(Path.GetFileNameWithoutExtension(n), "cover", StringComparison.OrdinalIgnoreCase))
                ?? images.FirstOrDefault(n => string.Equals(Path.GetFileNameWithoutExtension(n), "folder", StringComparison.OrdinalIgnoreCase))
                ?? images.FirstOrDefault() ?? "";
        }
        return "";
    }
    private static bool ImageExists(string directory, string name)
    {
        try {
            return !string.IsNullOrEmpty(name) && ImageExtensions.Contains(Path.GetExtension(name)) &&
                (File.GetAttributes(Child(directory, name, false)) & FileAttributes.ReparsePoint) == 0;
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return false; }
    }
    public object[] Categories(AdultConfiguration c)
    {
        var root = Root(c);
        return CategoryFolders(c).Select(folder => {
            var item = Presentation(c, folder); var dir = Child(root, folder, true);
            var image = ImageName(dir, item.ImageFile, true);
            return (object)new { Name = folder, Title = string.IsNullOrWhiteSpace(item.Title) ? folder : item.Title.Trim(),
                Description = item.Description?.Trim() ?? "", HasCover = ImageExists(dir, image) };
        }).ToArray();
    }
    public object[] Videos(AdultConfiguration c, string category)
    {
        var dir = Child(Root(c), category, true);
        return Directory.EnumerateFiles(dir).Where(p => VideoExtensions.Contains(Path.GetExtension(p)) &&
            (File.GetAttributes(p) & FileAttributes.ReparsePoint) == 0).OrderBy(Path.GetFileName).Take(1000)
            .Select(p => (object)new { Name = Path.GetFileName(p) }).ToArray();
    }
    public string VideoFile(AdultConfiguration c, string category, string video)
    {
        var dir = Child(Root(c), category, true);
        var path = Child(dir, video, false);
        if (!VideoExtensions.Contains(Path.GetExtension(path))) throw new IOException("File video non ammesso.");
        return path;
    }
    // Called only with a video path already validated by VideoFile. A sidecar is
    // read through the same size, content and symlink checks as category covers.
    public static (byte[] Bytes, string ContentType)? CustomVideoCover(string videoPath)
    {
        var directory = Path.GetDirectoryName(videoPath)!;
        var stem = Path.GetFileNameWithoutExtension(videoPath);
        string[] priority = [".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"];
        foreach (var name in Directory.EnumerateFiles(directory).Select(Path.GetFileName)
            .Where(n => n is not null && ImageExtensions.Contains(Path.GetExtension(n)) &&
                string.Equals(Path.GetFileNameWithoutExtension(n), stem, Comparison))
            .OrderBy(n => Array.IndexOf(priority, Path.GetExtension(n)!.ToLowerInvariant()))
            .ThenBy(n => n, StringComparer.Ordinal)) {
            try { return ReadImage(directory, name!); }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { }
        }
        return null; // Invalid/missing custom images retain the existing FFmpeg fallback.
    }
    public (byte[] Bytes, string ContentType) Cover(AdultConfiguration c, string category)
    {
        var dir = Child(Root(c), category, true); var item = Presentation(c, category);
        return ReadImage(dir, ImageName(dir, item.ImageFile, true));
    }
    public (byte[] Bytes, string ContentType)? CustomHomeCover(AdultConfiguration c)
    {
        if (string.IsNullOrWhiteSpace(c.HomeImageFile)) return null;
        return ReadImage(Root(c), c.HomeImageFile.Trim());
    }
    public static (byte[] Bytes, string ContentType) ReadImage(string parent, string name)
    {
        if (!ImageExtensions.Contains(Path.GetExtension(name))) throw new IOException("Formato immagine non ammesso.");
        var file = Child(parent, name, false);
        if (new FileInfo(file).Length > 8 * 1024 * 1024) throw new IOException("Immagine troppo grande.");
        var bytes = File.ReadAllBytes(file);
        if (bytes.Length >= 3 && bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[2] == 0xff) return (bytes, "image/jpeg");
        if (bytes.Length >= 8 && bytes.AsSpan(0, 8).SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 })) return (bytes, "image/png");
        if (bytes.Length >= 12 && bytes.AsSpan(0, 4).SequenceEqual("RIFF"u8) && bytes.AsSpan(8, 4).SequenceEqual("WEBP"u8)) return (bytes, "image/webp");
        if (bytes.Length >= 6 && (bytes.AsSpan(0, 6).SequenceEqual("GIF87a"u8) || bytes.AsSpan(0, 6).SequenceEqual("GIF89a"u8))) return (bytes, "image/gif");
        if (bytes.Length >= 2 && bytes[0] == (byte)'B' && bytes[1] == (byte)'M') return (bytes, "image/bmp");
        throw new IOException("Contenuto immagine non valido.");
    }
}
