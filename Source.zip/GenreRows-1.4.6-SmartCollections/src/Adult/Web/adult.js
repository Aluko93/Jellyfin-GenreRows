/* Isolated Adult test browser. No Jellyfin Items, playback or persistent Adult storage. */
(() => {
    'use strict';
    if (window.__grAdultLoaded) return;
    window.__grAdultLoaded = true;
    const css = document.createElement('style');
    css.textContent = `
    .gra-home{padding:1.5em 3.3%;clear:both}.gra-card{display:block;color:#eee;width:min(700px,100%);border:0;border-radius:12px;cursor:pointer;background:#17191b;padding:0;font:inherit;text-align:left;overflow:hidden;box-shadow:0 8px 24px #0006}.gra-card img{display:block;width:100%;aspect-ratio:11/3;object-fit:cover;background:#17191b}.gra-home-copy{display:block;padding:.8em 1em}.gra-home-title{display:block;font-size:1.25em;font-weight:600}.gra-home-description{display:block;margin-top:.25em;opacity:.75;white-space:pre-wrap}
    .gra-dialog{position:fixed;inset:0;z-index:10000;background:#111;color:#eee;overflow:auto;padding:2em max(1em,5vw);box-sizing:border-box}.gra-dialog button,.gra-dialog input{font:inherit;padding:.7em;border-radius:.4em;border:1px solid #777;background:#242424;color:#fff}.gra-dialog button{cursor:pointer}.gra-dialog button:focus-visible,.gra-card:focus-visible{outline:3px solid #00a4dc}.gra-top{display:flex;align-items:center;gap:1em;flex-wrap:wrap}.gra-top h1{flex:1}.gra-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:1em;margin-top:2em}.gra-category{min-width:0;overflow-wrap:anywhere;text-align:left;padding:0!important;overflow:hidden}.gra-category img{display:block;width:100%;height:210px;object-fit:cover}.gra-category-copy{display:block;padding:.8em}.gra-category-title{display:block;font-weight:600;font-size:1.08em}.gra-category-description{display:block;margin-top:.35em;opacity:.72;white-space:pre-wrap}.gra-video-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1.2em;margin-top:1em}.gra-video-card{min-width:0;padding:0!important;overflow:hidden;text-align:left}.gra-video-card img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#181818}.gra-video-name{display:block;padding:.7em;overflow-wrap:anywhere}.gra-dialog li{padding:.6em;overflow-wrap:anywhere}.gra-login{max-width:420px;margin:8vh auto}.gra-login input{box-sizing:border-box;width:100%;margin:1em 0}.gra-error{color:#ffb4ab}.gra-dialog [hidden]{display:none!important}
    `;
    document.head.append(css);
    const jellyfinStyle = document.createElement('style');
    jellyfinStyle.textContent = `
      .gra-dialog{--gra-accent:#00a4dc;font-family:inherit;background:#101010}
      .gra-dialog button{transition:background-color .14s,border-color .14s,transform .14s}
      .gra-grid{grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1.15em}
      .gra-category{background:#202020!important;border-radius:.35em!important;box-shadow:0 2px 8px #0008;text-align:left;transition:transform .16s,box-shadow .16s}
      .gra-category:hover{transform:scale(1.025);box-shadow:0 8px 22px #000a}
      .gra-category img{height:auto;aspect-ratio:2/3;object-fit:cover}
      .gra-video-grid{grid-template-columns:repeat(auto-fill,minmax(205px,1fr));gap:1.25em}
      .gra-video-card{min-width:0;background:transparent!important;border:0!important;box-shadow:none!important;overflow:visible!important}
      .gra-video-poster{position:relative;display:block;width:100%;aspect-ratio:16/9;padding:0!important;overflow:hidden;border:0!important;border-radius:.35em!important;background:#222;cursor:pointer;box-shadow:0 2px 8px #0008}
      .gra-video-poster img{display:block;width:100%;height:100%;object-fit:cover;transition:transform .18s,filter .18s}
      .gra-video-card:hover .gra-video-poster img,.gra-video-poster:focus-visible img{transform:scale(1.04);filter:brightness(.68)}
      .gra-video-play{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:3.4em;height:3.4em;padding:0!important;border:0!important;border-radius:50%!important;background:var(--gra-accent)!important;color:white!important;font-size:1.2em;box-shadow:0 3px 12px #0008;opacity:.92}
      .gra-video-play:hover{transform:translate(-50%,-50%) scale(1.08);background:#19b8e8!important}
      .gra-video-title{display:block;width:100%;padding:.55em .1em!important;border:0!important;background:transparent!important;text-align:left;color:#eee!important;white-space:normal;overflow-wrap:anywhere;line-height:1.35}
      .gra-video-title:hover{color:#fff!important;text-decoration:underline}
      .gra-detail{display:grid;grid-template-columns:minmax(240px,32%) minmax(0,1fr);gap:2em;align-items:center;max-width:1100px;margin:3em auto}
      .gra-detail-poster{width:100%;aspect-ratio:16/9;object-fit:cover;border:0!important;padding:0!important;background:#080808!important}
      .gra-detail-copy h2{font-size:clamp(1.5em,3vw,2.3em);overflow-wrap:anywhere}
      .gra-detail-play{background:var(--gra-accent)!important;color:#fff!important;border:0!important;border-radius:.25em!important;padding:.8em 1.4em!important;font-weight:600}
      .gra-player-page{max-width:1500px;margin:1.2em auto}
      .gra-player-shell{position:relative;width:100%;aspect-ratio:16/9;max-height:78vh;margin:.7em 0;background:#000;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 30px #0008}
      .gra-player{display:block;width:100%;height:100%;max-height:78vh;background:#000;object-fit:contain}
      .gra-player-controls{display:flex;align-items:center;gap:.7em;flex-wrap:wrap;padding:.65em .8em;background:#202020;border-radius:0 0 .35em .35em}
      .gra-player-controls button{min-width:2.7em;background:#303030;border-color:#555}
      .gra-player-controls button:hover{background:#444;border-color:#888}
      .gra-player-time{font-variant-numeric:tabular-nums;white-space:nowrap;opacity:.9}
      .gra-player-seek{flex:1 1 180px;accent-color:var(--gra-accent);min-width:100px}
      .gra-player-volume{width:100px;accent-color:var(--gra-accent)}
      .gra-player-tracks{display:flex;gap:.8em;flex-wrap:wrap;margin:.8em 0}
      .gra-player-tracks select{font:inherit;padding:.5em;background:#242424;color:#fff;border:1px solid #666;border-radius:.3em;max-width:min(320px,90vw)}
      .gra-player-shell:fullscreen{max-height:none;aspect-ratio:auto}
      .gra-player-shell:fullscreen .gra-player{max-height:none}
      @media(max-width:700px){.gra-dialog{padding:1em}.gra-grid{grid-template-columns:repeat(auto-fill,minmax(145px,1fr))}.gra-video-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}.gra-detail{grid-template-columns:1fr;gap:.8em;margin:1.2em auto}.gra-detail-poster{max-height:42vh}.gra-player-controls{gap:.45em}.gra-player-volume{width:76px}}
      @media(hover:none){.gra-video-play{opacity:.88}}
    `;
    document.head.append(jellyfinStyle);
    const el = (tag, text, cls) => { const n = document.createElement(tag); if (text !== undefined) n.textContent = text; if (cls) n.className = cls; return n; };
    let home, homeIdentity = '', homeUrl = '', homePresentation = { HomeTitle: 'Adult', HomeDescription: '' };
    let dialog, body, token = '', identity = '', ctx, generation = 0, idleMinutes = 5;
    let lastActivity = 0, lastTick = Date.now(), lastBeat = 0, beatPending = false, activity = false, statusAt = 0, statusPending = false;
    let savedFocus, inertNodes = [], urls = [], navigation = 0, category = null, thumbnailObserver = null, activePlayer = null, activeHls = null;
    const resumePositions = new Map();
    const language = (() => { try { const value = window.ApiClient?.getCurrentUser?.()?.Configuration?.DisplayLanguage || navigator.language || 'it'; const code = value.split(/[-_]/)[0].toLowerCase(); return ['it','en','fr','de','es','pt'].includes(code) ? code : 'it'; } catch (_) { return 'it'; } })();
    const words = {
        it: { lock:'🔒 Blocca e chiudi', locked:'🔒 Area protetta', password:'Password / PIN', unlock:'Sblocca', denied:'Accesso negato. Controlla la password o attendi un minuto; verifica anche la configurazione.', loadingCategories:'Caricamento categorie…', loadingVideos:'Caricamento elenco…', test:'Anteprime automatiche · riproduzione nella sessione Adult.', noCategories:'Nessuna categoria. Crea sottocartelle nella cartella Adult.', back:'← Categorie', files:n=>n===1?'1 video':`${n} video`, previewUnavailable:'Anteprima non disponibile', play:'▶ Riproduci', playbackError:'Impossibile avviare il video. Controlla formato e codec supportati dal browser.', backVideos:'← Video', audio:'Traccia audio', audioUnavailable:'Il browser non permette di cambiare traccia audio per questo file.', subtitles:'Sottotitoli', off:'Disattivati', duration:'Durata', resume:'Riprendi' },
        en: { lock:'🔒 Lock and close', locked:'🔒 Protected area', password:'Password / PIN', unlock:'Unlock', denied:'Access denied. Check the password, wait a minute, and verify the settings.', loadingCategories:'Loading categories…', loadingVideos:'Loading videos…', test:'Automatic previews · playback stays inside the Adult session.', noCategories:'No categories. Create subfolders inside the Adult folder.', back:'← Categories', files:n=>n===1?'1 video':`${n} videos`, previewUnavailable:'Preview unavailable', play:'▶ Play', playbackError:'Could not start the video. Check browser-supported formats and codecs.', backVideos:'← Videos', audio:'Audio track', audioUnavailable:'This browser cannot switch audio tracks for this file.', subtitles:'Subtitles', off:'Off', duration:'Duration', resume:'Resume' },
        fr: { lock:'🔒 Verrouiller et fermer', locked:'🔒 Espace protégé', password:'Mot de passe / PIN', unlock:'Déverrouiller', denied:'Accès refusé. Vérifiez le mot de passe, attendez une minute et vérifiez la configuration.', loadingCategories:'Chargement des catégories…', loadingVideos:'Chargement des vidéos…', test:'Aperçus automatiques · lecture limitée à la session Adult.', noCategories:'Aucune catégorie. Créez des sous-dossiers dans le dossier Adult.', back:'← Catégories', files:n=>n===1?'1 vidéo':`${n} vidéos`, previewUnavailable:'Aperçu indisponible', play:'▶ Lire', playbackError:'Impossible de lire la vidéo. Vérifiez les formats pris en charge par le navigateur.', backVideos:'← Vidéos', audio:'Piste audio', audioUnavailable:'Ce navigateur ne peut pas changer la piste audio de ce fichier.', subtitles:'Sous-titres', off:'Désactivés', duration:'Durée', resume:'Reprendre' },
        de: { lock:'🔒 Sperren und schließen', locked:'🔒 Geschützter Bereich', password:'Passwort / PIN', unlock:'Entsperren', denied:'Zugriff verweigert. Passwort prüfen, eine Minute warten und Einstellungen überprüfen.', loadingCategories:'Kategorien werden geladen…', loadingVideos:'Videos werden geladen…', test:'Automatische Vorschauen · Wiedergabe nur in der Adult-Sitzung.', noCategories:'Keine Kategorien. Erstellen Sie Unterordner im Adult-Ordner.', back:'← Kategorien', files:n=>n===1?'1 Video':`${n} Videos`, previewUnavailable:'Vorschau nicht verfügbar', play:'▶ Abspielen', playbackError:'Video kann nicht gestartet werden. Browserformate und Codecs überprüfen.', backVideos:'← Videos', audio:'Audiospur', audioUnavailable:'Dieser Browser kann die Audiospur dieser Datei nicht wechseln.', subtitles:'Untertitel', off:'Aus', duration:'Dauer', resume:'Fortsetzen' },
        es: { lock:'🔒 Bloquear y cerrar', locked:'🔒 Área protegida', password:'Contraseña / PIN', unlock:'Desbloquear', denied:'Acceso denegado. Comprueba la contraseña, espera un minuto y revisa la configuración.', loadingCategories:'Cargando categorías…', loadingVideos:'Cargando vídeos…', test:'Vistas previas automáticas · reproducción dentro de la sesión Adult.', noCategories:'No hay categorías. Crea subcarpetas en la carpeta Adult.', back:'← Categorías', files:n=>n===1?'1 vídeo':`${n} vídeos`, previewUnavailable:'Vista previa no disponible', play:'▶ Reproducir', playbackError:'No se pudo iniciar el vídeo. Comprueba los formatos y códecs del navegador.', backVideos:'← Vídeos', audio:'Pista de audio', audioUnavailable:'Este navegador no puede cambiar la pista de audio de este archivo.', subtitles:'Subtítulos', off:'Desactivados', duration:'Duración', resume:'Reanudar' },
        pt: { lock:'🔒 Bloquear e fechar', locked:'🔒 Área protegida', password:'Senha / PIN', unlock:'Desbloquear', denied:'Acesso negado. Verifique a senha, aguarde um minuto e confira as configurações.', loadingCategories:'Carregando categorias…', loadingVideos:'Carregando vídeos…', test:'Pré-visualizações automáticas · reprodução na sessão Adult.', noCategories:'Nenhuma categoria. Crie subpastas na pasta Adult.', back:'← Categorias', files:n=>n===1?'1 vídeo':`${n} vídeos`, previewUnavailable:'Pré-visualização indisponível', play:'▶ Reproduzir', playbackError:'Não foi possível iniciar o vídeo. Verifique os formatos e codecs do navegador.', backVideos:'← Vídeos', audio:'Faixa de áudio', audioUnavailable:'Este navegador não consegue trocar a faixa de áudio deste arquivo.', subtitles:'Legendas', off:'Desativadas', duration:'Duração', resume:'Retomar' }
    };
    const extra={it:['Cerca','Nome A–Z','Nome Z–A','Pausa','Volume','Schermo intero'],en:['Search','Name A–Z','Name Z–A','Pause','Volume','Fullscreen'],fr:['Rechercher','Nom A–Z','Nom Z–A','Pause','Volume','Plein écran'],de:['Suchen','Name A–Z','Name Z–A','Pause','Lautstärke','Vollbild'],es:['Buscar','Nombre A–Z','Nombre Z–A','Pausa','Volumen','Pantalla completa'],pt:['Pesquisar','Nome A–Z','Nome Z–A','Pausar','Volume','Tela cheia']}[language];
    Object.assign(words[language],{search:extra[0],ascending:extra[1],descending:extra[2],pause:extra[3],volume:extra[4],fullscreen:extra[5]});
    const t = key => words[language][key];
    function mediaIcon(button,kind){
        const paths={play:'M8 5v14l11-7z',pause:'M6 5h4v14H6zm8 0h4v14h-4z',volume:'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.8-1-3.3-2.5-4.1v8.2c1.5-.8 2.5-2.3 2.5-4.1zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z',muted:'M3 9v6h4l5 5V4L7 9H3zm13-1 2 2 2-2 1.4 1.4-2 2 2 2L20 14.8l-2-2-2 2-1.4-1.4 2-2-2-2z',fullscreen:'M7 14H5v5h5v-2H7zm-2-4h2V7h3V5H5zm12 7h-3v2h5v-5h-2zm-3-12v2h3v3h2V5z'};
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg'),p=document.createElementNS('http://www.w3.org/2000/svg','path');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('width','24');svg.setAttribute('height','24');svg.setAttribute('aria-hidden','true');p.setAttribute('fill','currentColor');p.setAttribute('d',paths[kind]);svg.append(p);button.replaceChildren(svg);
    }
    const skin=document.createElement('style');skin.textContent=`
      .gra-dialog{background:var(--background-color,#101010);color:var(--text-color,#eee);--gra-accent:var(--accent,#00a4dc)}
      .gra-tools{display:flex;gap:.7em;flex-wrap:wrap;margin:1em 0}.gra-tools select{font:inherit;padding:.6em;background:var(--input-background-color,#242424);color:inherit;border:1px solid #666;border-radius:.3em}
      .gra-duration{position:absolute;bottom:.4em;right:.4em;padding:.2em .4em;background:#000c;color:#fff;font-variant-numeric:tabular-nums;pointer-events:none}
      .gra-player-shell{overflow:hidden}.gra-player-deck{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,#000e);padding-top:2em;transition:opacity .2s}
      .gra-player-deck .gra-player-controls{background:transparent}.gra-player-deck .gra-player-tracks{margin:.4em .8em}.gra-player-shell.gra-controls-hidden{cursor:none}.gra-controls-hidden .gra-player-deck{opacity:0;pointer-events:none}
      .gra-controls-hidden:focus-within .gra-player-deck{opacity:1;pointer-events:auto}
      @media(max-width:700px){.gra-player-controls{gap:.3em;padding:.35em}.gra-player-controls button{padding:.3em;min-width:2em;min-height:2em}.gra-player-volume{display:none}.gra-player-seek{order:-1;flex-basis:100%}.gra-player-tracks{margin:.2em .5em!important;gap:.4em}.gra-player-tracks label{font-size:.85em}.gra-player-tracks select{max-width:120px;padding:.25em}.gra-player-deck{padding-top:1em}}
    `;document.head.append(skin);const tvStyle=document.createElement('style');tvStyle.textContent=`
 .gra-dialog .gra-video-poster{aspect-ratio:auto;display:block;width:100%;height:0;padding:0 0 150%!important;border:0;border-radius:.35em;overflow:hidden;background:#242424;cursor:pointer}
 .gra-video-poster img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
 .gra-dialog .gra-video-title{display:block;padding:.5em 0;color:inherit;text-align:left;background:transparent;border:0;overflow-wrap:anywhere}
 .gra-video-grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}
 .gra-category:focus,.gra-video-poster:focus,.gr-explicit-search:focus{outline:3px solid var(--gra-accent,#00a4dc);outline-offset:3px}
 .gra-category{display:flex;flex-direction:column;justify-content:flex-end}.gra-category:not(:has(img)){min-height:260px}
 .gra-tools [hidden]{display:none!important}
`;document.head.append(tvStyle);
    function galleryTools(grid){const bar=el('div',undefined,'gra-tools'),search=el('input'),sort=el('select');search.type='search';search.placeholder=t('search');search.setAttribute('aria-label',t('search'));sort.setAttribute('aria-label',t('ascending')+' / '+t('descending'));sort.append(new Option(t('ascending'),'asc'),new Option(t('descending'),'desc'));const draw=()=>{const children=[...grid.children].sort((a,b)=>(a.dataset.name||'').localeCompare(b.dataset.name||'')*(sort.value==='desc'?-1:1));for(const card of children){card.hidden=!(card.dataset.name||'').toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase());grid.append(card);}};search.oninput=sort.onchange=draw;bar.append(search,sort);window.GenreRowsTV.explicitSearch(search,t('search'));return bar;}
    const clockText=value=>{const n=Math.max(0,Math.floor(value||0));return [Math.floor(n/3600),Math.floor(n/60)%60,n%60].map(x=>String(x).padStart(2,'0')).join(':');};
    const current = () => {
        const api = window.ApiClient, user = api?.getCurrentUserId?.(), key = api?.accessToken?.();
        return user && key ? { api, key, id: api.serverAddress() + '|' + user + '|' + key } : null;
    };
    async function request(context, path, { method = 'GET', data, session = '', keepalive = false } = {}) {
        const r = await fetch(context.api.getUrl('GenreRows/Adult/' + path), {
            method, cache: 'no-store', credentials: 'same-origin', referrerPolicy: 'no-referrer', keepalive,
            headers: { 'Authorization': 'MediaBrowser Client="Jellyfin Web", Device="Browser", DeviceId="GenreRowsAdult", Version="1.4.1", Token="' + context.key + '"', 'X-Adult-Session': session, ...(data ? { 'Content-Type': 'application/json' } : {}) },
            ...(data ? { body: JSON.stringify(data) } : {})
        });
        if (!r.ok) { const error = Error('Accesso non disponibile (' + r.status + ').'); error.status = r.status; throw error; }
        return r;
    }
    const json = async (c, path, options) => (await request(c, path, options)).json();
    function revoke(c, t) { if (c && t) void request(c, 'Lock', { method: 'POST', session: t, keepalive: true }).catch(() => {}); }
    function clearUrls() { thumbnailObserver?.disconnect(); thumbnailObserver = null; for (const u of urls) URL.revokeObjectURL(u); urls = []; }
    function stopMedia() {
        if (activePlayer && ctx && token) void request(ctx, 'Playback/Close', { method: 'POST', session: token, keepalive: true }).catch(() => {});
        try { activeHls?.destroy(); } catch (_) {} activeHls = null;
        if (activePlayer) { activePlayer.__dispose?.(); try { activePlayer.pause(); activePlayer.removeAttribute('src'); activePlayer.load(); } catch (_) {} }
        activePlayer = null;
    }
    function clearHome() { home?.remove(); home = null; homeIdentity = ''; if (homeUrl) URL.revokeObjectURL(homeUrl); homeUrl = ''; }
    let detachTV,playPending=0;function lock() {
        detachTV?.();detachTV=null;
        const oldContext = ctx, oldToken = token;
        generation++; navigation++; token = ''; ctx = null; identity = ''; category = null; resumePositions.clear(); stopMedia();
        dialog?.remove(); dialog = null; body = null; clearUrls();
        for (const [n, previous] of inertNodes) n.inert = previous;
        inertNodes = []; savedFocus?.focus?.(); savedFocus = null;
        revoke(oldContext, oldToken);
    }
    function valid(run) { return !!dialog && run === generation && current()?.id === identity && !document.hidden; }
    function fail(run) { if (run === generation) lock(); }
    function open() {
        lock(); const c = current(); if (!c || document.hidden) return;
        ctx = c; identity = c.id; const run = ++generation;
        savedFocus = document.activeElement;
        dialog = el('div', undefined, 'gra-dialog'); dialog.setAttribute('role', 'dialog'); dialog.setAttribute('aria-modal', 'true'); dialog.setAttribute('aria-label', 'Sezione Adult');
        const top = el('header', undefined, 'gra-top'), exit = el('button', t('lock'));
        exit.onclick = lock; top.append(el('h1', homePresentation.HomeTitle || 'Adult'), exit); body = el('div'); dialog.append(top, body);
        for (const n of document.body.children) { inertNodes.push([n, n.inert]); n.inert = true; }
        document.body.append(dialog);detachTV=window.GenreRowsTV.attach(dialog,{trap:true,onBack:()=>{if(activePlayer&&category)void videos(generation,category);else if(category)history.back();else lock();}});
        history.pushState({ grAdult: true }, '', location.href);
        const form = el('form', undefined, 'gra-login'), label = el('label', t('password')), input = el('input'), submit = el('button', t('unlock')), message = el('p', '', 'gra-error');
        input.type = 'password'; input.id = 'gra-secret'; input.autocomplete = 'off'; input.required = true; input.maxLength = 256; label.htmlFor = input.id; submit.type = 'submit';
        form.append(el('h2', t('locked')), label, input, submit, message); body.append(form); input.focus();
        form.onsubmit = async e => {
            e.preventDefault(); if (!valid(run) || submit.disabled) return; submit.disabled = true;
            const secret = input.value; input.value = '';
            try {
                const result = await json(c, 'Unlock', { method: 'POST', data: { Password: secret } });
                if (!valid(run)) { revoke(c, result.Token); return; }
                token = result.Token; idleMinutes = result.IdleMinutes; activity = false;
                lastActivity = lastBeat = lastTick = Date.now(); beatPending = false;
                await categories(run);
            } catch (_) { if (valid(run)) { message.textContent = t('denied'); submit.disabled = false; input.focus(); } }
        };
    }
    async function categories(run) {
        const nav = ++navigation; category = null; stopMedia(); clearUrls(); body.replaceChildren(el('p', t('loadingCategories')));
        try {
            const rows = await json(ctx, 'Categories', { session: token });
            if (!valid(run) || nav !== navigation) return;
            const grid = el('div', undefined, 'gra-grid'); body.replaceChildren(galleryTools(grid), grid);
            if (!rows.length) body.append(el('p', t('noCategories')));
            let cursor = 0; const covers = [];
            for (const row of rows) {
                const b = el('button', undefined, 'gra-category'), copy = el('span', undefined, 'gra-category-copy'); b.type = 'button';
                copy.append(el('span', row.Title || row.Name, 'gra-category-title'));
                if (row.Description) copy.append(el('span', row.Description, 'gra-category-description'));
                b.dataset.name=row.Title||row.Name;b.append(copy);
                b.onclick = () => { history.pushState({ grAdult: true, category: row.Name }, '', location.href); void videos(run, row.Name); };
                grid.append(b); if (row.HasCover) covers.push({ row, b });
            }
            async function worker() { while (cursor < covers.length && valid(run) && nav === navigation) {
                const { row, b } = covers[cursor++];
                try {
                    const r = await request(ctx, 'Cover?category=' + encodeURIComponent(row.Name), { session: token }); const blob = await r.blob();
                    if (!valid(run) || nav !== navigation) return;
                    const url = URL.createObjectURL(blob); urls.push(url); const image = el('img'); image.alt = ''; image.src = url; b.prepend(image);
                } catch (error) { if (error.status === 403) { fail(run); return; } }
            } }
            window.GenreRowsTV.focus(grid.querySelector('button')||dialog.querySelector('button'));void Promise.all([worker(), worker(), worker()]);
        } catch (_) { fail(run); }
    }
    async function videos(run, name) {
        const nav = ++navigation; category = name; stopMedia(); clearUrls(); body.replaceChildren(el('p', t('loadingVideos')));
        try {
            const rows = await json(ctx, 'Videos?category=' + encodeURIComponent(name), { session: token });
            if (!valid(run) || nav !== navigation) return;
            const back = el('button', t('back')); back.onclick = () => history.back(); const grid = el('div', undefined, 'gra-video-grid');
            body.replaceChildren(back, el('h2', name), el('p', t('files')(rows.length)), galleryTools(grid), grid);
            for (const row of rows) {
                const card=el('article',undefined,'gra-video-card'),poster=el('button',undefined,'gra-video-poster focusable'),image=el('img'),title=el('span',row.Name,'gra-video-title');
                poster.type='button';poster.setAttribute('aria-label',t('play')+': '+row.Name);image.alt='';image.loading='lazy';image.decoding='async';image.dataset.video=row.Name;image.dataset.category=name;
                poster.onclick=()=>{void playVideo(run,name,row.Name);};
                const duration=el('span','', 'gra-duration');duration.hidden=true;poster.append(image,duration);card.dataset.name=row.Name;card.append(poster,title);grid.append(card);
            }
            window.GenreRowsTV.focus(grid.querySelector('button')||back);
            const loadThumbnail = async image => {
                const video = image.dataset.video, cat = image.dataset.category;
                try {
                    const r = await request(ctx, 'Thumbnail?category=' + encodeURIComponent(cat) + '&video=' + encodeURIComponent(video), { session: token });
                    const blob = await r.blob(); if (!valid(run) || nav !== navigation) return;
                    const url = URL.createObjectURL(blob); urls.push(url); image.src = url;
                    void json(ctx,'Metadata?category='+encodeURIComponent(cat)+'&video='+encodeURIComponent(video),{session:token}).then(info=>{if(!valid(run)||nav!==navigation)return;const badge=image.closest('.gra-video-card')?.querySelector('.gra-duration');if(badge&&info.DurationSeconds>0){badge.textContent=clockText(info.DurationSeconds);badge.hidden=false;}}).catch(()=>{});
                } catch (error) { if (error.status === 403) { fail(run); return; } image.alt = t('previewUnavailable'); image.title = t('previewUnavailable'); }
            };
            if ('IntersectionObserver' in window) {
                thumbnailObserver = new IntersectionObserver(entries => { for (const entry of entries) if (entry.isIntersecting) { thumbnailObserver.unobserve(entry.target); void loadThumbnail(entry.target); } }, { root: dialog, rootMargin: '500px 0px' });
                for (const image of grid.querySelectorAll('img')) thumbnailObserver.observe(image);
            } else for (const image of grid.querySelectorAll('img')) void loadThumbnail(image);
        } catch (_) { fail(run); }
    }
    function videoDetails(run, cat, row, posterUrl) {
        if (!valid(run)) return;
        const back = el('button', t('back')); back.onclick = () => { void videos(run, cat); };
        const panel = el('section', undefined, 'gra-detail'), poster = el('img', undefined, 'gra-detail-poster');
        poster.alt = ''; if (posterUrl && posterUrl.startsWith('blob:')) poster.src = posterUrl;
        const copy = el('div', undefined, 'gra-detail-copy'), play = el('button', t('play'), 'gra-detail-play');
        play.type = 'button'; play.onclick = () => { void playVideo(run, cat, row.Name); };
        copy.append(el('h2', row.Name), el('p', cat), play); panel.append(poster, copy); body.replaceChildren(back, panel);
    }
    async function playVideo(run, cat, file) {
        if(playPending===run)return;
        playPending=run;const nav=navigation,owner=ctx,ownerToken=token;
        try {
            const details = await json(owner, 'Playback/Open', { method: 'POST', data: { Category: cat, Video: file }, session: ownerToken });
            if (!valid(run)||nav!==navigation) {await request(owner,'Playback/Close',{method:'POST',session:ownerToken,keepalive:true}).catch(()=>{});return;}
            navigation++;
            clearUrls();
            const back = el('button', t('backVideos')); back.onclick = () => { void videos(run, cat); };
            const player = el('video', undefined, 'gra-player'); player.controls = false; player.playsInline = true; player.preload = 'metadata';
            activePlayer = player;let timelineOffset=0, hlsMode=false, fallbackStarted=false;const absoluteTime=()=>timelineOffset+(player.currentTime||0);
            const message = el('p', '', 'gra-error'), resumeKey = cat + '\0' + file;
            const duration = Math.max(0, Math.floor(details.DurationSeconds || 0));
            const durationText = duration ? `${t('duration')}: ${String(Math.floor(duration / 3600)).padStart(2,'0')}:${String(Math.floor(duration / 60) % 60).padStart(2,'0')}:${String(duration % 60).padStart(2,'0')}` : '';
            const page = el('section', undefined, 'gra-player-page'), shell = el('div', undefined, 'gra-player-shell'); shell.append(player);
            const controls = el('div', undefined, 'gra-player-controls'), playToggle = el('button', '▶'), now = el('span', '00:00', 'gra-player-time');
            const seek = el('input'), total = el('span', durationText ? durationText.replace(t('duration') + ': ', '') : '00:00', 'gra-player-time');
            const mute = el('button', '🔊'), volume = el('input'), fullscreen = el('button', '⛶');
            playToggle.type = mute.type = fullscreen.type = 'button';
            playToggle.setAttribute('aria-label', t('play')); playToggle.title = t('play');
            mute.setAttribute('aria-label', 'Mute'); mute.title = 'Mute'; fullscreen.setAttribute('aria-label', t('fullscreen')); fullscreen.title = t('fullscreen');
            seek.type = volume.type = 'range'; seek.min = '0'; seek.max = String(duration || 0); seek.step = '0.1'; seek.value = '0'; seek.disabled = duration <= 0; seek.className = 'gra-player-seek'; seek.setAttribute('aria-label', t('duration'));
            volume.min = '0'; volume.max = '1'; volume.step = '0.05'; volume.value = '1'; volume.className = 'gra-player-volume'; volume.setAttribute('aria-label', t('volume'));
            const clock = seconds => { seconds = Math.max(0, Math.floor(Number(seconds) || 0)); return duration >= 3600 ? `${String(Math.floor(seconds / 3600)).padStart(2,'0')}:${String(Math.floor(seconds / 60) % 60).padStart(2,'0')}:${String(seconds % 60).padStart(2,'0')}` : `${String(Math.floor(seconds / 60)).padStart(2,'0')}:${String(seconds % 60).padStart(2,'0')}`; };
            const refreshControls = () => { now.textContent = clock(absoluteTime());const length=duration||player.duration;if(Number.isFinite(length)&&length>0){seek.max=String(length);seek.disabled=false;seek.value=String(Math.min(length,absoluteTime()));total.textContent=clock(length);}mediaIcon(playToggle,player.paused?'play':'pause');playToggle.setAttribute('aria-label',player.paused?t('play'):t('pause')); };
            playToggle.onclick = () => { if (player.paused) void player.play().catch(() => { message.textContent = t('playbackError'); }); else player.pause(); };
            player.addEventListener('click', () => { if (player.paused) void player.play().catch(() => {}); else player.pause(); });
            player.addEventListener('playing',()=>{seek.disabled=audioSelect.disabled=false;});player.addEventListener('play', refreshControls); player.addEventListener('pause', refreshControls);
            player.addEventListener('timeupdate', refreshControls); player.addEventListener('loadedmetadata', refreshControls);
            seek.addEventListener('input',()=>{now.textContent=clock(Number(seek.value));});seek.addEventListener('change',()=>{const value=Number(seek.value);if(hlsMode){void useHls(audioTracks[Number(audioSelect.value)]?.Index??selectedAudio,true,value).catch(onError);}else player.currentTime=value;});
            volume.addEventListener('input', () => { player.volume = Number(volume.value); player.muted = player.volume === 0; mediaIcon(mute,player.muted?'muted':'volume'); });
            mute.onclick = () => { player.muted = !player.muted; mediaIcon(mute,player.muted?'muted':'volume'); mute.title = player.muted ? 'Unmute' : 'Mute'; };
            fullscreen.onclick = () => { const target = shell.requestFullscreen ? shell : player; if(target.requestFullscreen)void target.requestFullscreen().catch(()=>{});else player.webkitEnterFullscreen?.(); };
            player.addEventListener('volumechange',()=>{volume.value=String(player.volume);mediaIcon(mute,player.muted?'muted':'volume');});mediaIcon(mute,'volume');mediaIcon(fullscreen,'fullscreen');const rewind=el('button','−10s'),forward=el('button','+10s');rewind.type=forward.type='button';rewind.onclick=()=>keyHandler({key:'ArrowLeft',target:rewind,preventDefault(){}});forward.onclick=()=>keyHandler({key:'ArrowRight',target:forward,preventDefault(){}});controls.append(playToggle,rewind,forward,now,seek,total,mute,volume,fullscreen);controls.addEventListener('click',e=>{if(e.detail>0)e.target.closest('button')?.blur();});
            const audioTracks = details.AudioTracks || [], subtitleTracks = details.SubtitleTracks || [];
            const audioSelect = el('select'), audioLabel = el('label', t('audio') + ' '); audioSelect.append(new Option(t('off'), '-1'));
            for (const [index, track] of audioTracks.entries()) audioSelect.append(new Option(track.Title || `${track.Language} · ${track.Codec}`, String(index)));
            if(audioTracks.length){audioSelect.options[0].remove();audioSelect.value='0';}audioLabel.append(audioSelect); if (audioTracks.length < 2) audioLabel.hidden = true;
            const subtitleSelect = el('select'), subtitleLabel = el('label', t('subtitles') + ' '); subtitleSelect.append(new Option(t('off'), '-1'));
            for (const track of subtitleTracks) subtitleSelect.append(new Option(track.Title || `${track.Language} · ${track.Codec}`, String(track.Index)));
            subtitleLabel.append(subtitleSelect); subtitleLabel.hidden = subtitleTracks.length === 0;
            const trackPanel = el('div', undefined, 'gra-player-tracks'); trackPanel.append(audioLabel, subtitleLabel);
            const deck=el('div',undefined,'gra-player-deck');deck.append(controls,trackPanel);shell.append(deck);page.append(el('h2',file),shell);page.tabIndex=0;body.replaceChildren(back,page,message);page.focus();
            let hideTimer;const reveal=()=>{clearTimeout(hideTimer);shell.classList.remove('gra-controls-hidden');hideTimer=setTimeout(()=>{if(!player.paused&&!deck.contains(document.activeElement))shell.classList.add('gra-controls-hidden');},3000);};
            shell.addEventListener('pointermove',reveal);shell.addEventListener('touchstart',reveal,{passive:true});shell.addEventListener('focusin',reveal);player.addEventListener('play',reveal);player.addEventListener('pause',reveal);
            const keyHandler=e=>{if(!valid(run)||activePlayer!==player||e.target.matches('input,select,textarea'))return;const key=e.key.toLowerCase();if([' ','k','arrowleft','arrowright','arrowup','arrowdown','m','f'].includes(key))e.preventDefault();if(key===' '||key==='k')playToggle.click();if(key==='m')mute.click();if(key==='f')fullscreen.click();if(key==='arrowup'||key==='arrowdown')player.volume=Math.max(0,Math.min(1,player.volume+(key==='arrowup'?.1:-.1)));if(key==='arrowleft'||key==='arrowright'){seek.value=String(Math.max(0,Math.min(duration||player.duration,absoluteTime()+(key==='arrowright'?10:-10))));seek.dispatchEvent(new Event('change'));}reveal();};document.addEventListener('keydown',keyHandler);player.__dispose=()=>{clearTimeout(hideTimer);document.removeEventListener('keydown',keyHandler);};reveal();
            for (const track of subtitleTracks) {
                const caption = el('track'); caption.kind = 'subtitles'; caption.id = String(track.Index); caption.label = track.Title || `${track.Language} · ${track.Codec}`; caption.srclang = /^[a-z]{2,3}$/i.test(track.Language) ? track.Language : 'und';
                caption.src = ctx.api.getUrl('GenreRows/Adult/Playback/Subtitle/' + encodeURIComponent(track.Index)); player.append(caption);
            }
            subtitleSelect.onchange = () => { for (let i = 0; i < player.textTracks.length; i++) player.textTracks[i].mode = player.textTracks[i].id === subtitleSelect.value ? 'showing' : 'disabled'; };
            let hlsChange=Promise.resolve();const useHls=(audioIndex,restart=false,position=0)=>hlsChange=hlsChange.catch(()=>{}).then(()=>startHls(audioIndex,restart,position));const startHls = async (audioIndex, restart = false, position = 0) => {
                player.pause();seek.disabled=audioSelect.disabled=true;
                const result = await json(ctx, 'Playback/Transcode', { method: 'POST', data: { AudioIndex: audioIndex, Restart: restart, StartSeconds: position }, session: token });
                if (!valid(run) || activePlayer !== player) return;
                try { activeHls?.destroy(); } catch (_) {} activeHls = null;
                player.removeAttribute('src'); player.load();timelineOffset=position;hlsMode=true;
                if (window.Hls?.isSupported()) {
                    const hls = new window.Hls({ xhrSetup: xhr => { xhr.withCredentials = true; } }); activeHls = hls;
                    hls.loadSource(ctx.api.getUrl(result.ManifestUrl)); hls.attachMedia(player);
                    hls.on(window.Hls.Events.MANIFEST_PARSED, () => { void player.play().catch(onError); });
                    hls.on(window.Hls.Events.ERROR, (_event, data) => { if (data?.fatal && valid(run)) message.textContent = t('playbackError'); });
                } else if (player.canPlayType('application/vnd.apple.mpegurl')) {
                    player.src = ctx.api.getUrl(result.ManifestUrl); player.addEventListener('loadedmetadata', () => { void player.play().catch(onError); }, { once: true });
                } else throw Error('HLS unsupported');
            };
            const browserType = `${details.Container || ''}`.toLowerCase();
            const videoCodec = `${details.VideoCodec || ''}`.toLowerCase();
            const audioCodec = `${audioTracks[0]?.Codec || ''}`.toLowerCase();
            const directPossible = /(^|[,\s])(mp4|mov|m4v)([,\s]|$)/.test(browserType) && ['h264','avc1'].includes(videoCodec) && (!audioCodec || ['aac','mp3'].includes(audioCodec)) && player.canPlayType(details.ContentType || '') !== '';
            const selectedAudio = audioTracks[0]?.Index ?? -1;
            if (directPossible) { player.src = ctx.api.getUrl(details.StreamUrl); }
            else await useHls(selectedAudio,false,resumePositions.get(resumeKey)||0);
            audioSelect.onchange = async () => {
                const chosen = audioTracks[Number(audioSelect.value)]; if (!chosen) return;
                if (activeHls || !directPossible) { const position = absoluteTime(); try { await useHls(chosen.Index, true, position); } catch (_) { message.textContent = t('playbackError'); } return; }
                const tracks = player.audioTracks;
                if (!tracks || !tracks.length) {try{await useHls(chosen.Index,true,absoluteTime());}catch(_){message.textContent=t('audioUnavailable');}return;}
                for (let i = 0; i < tracks.length; i++) tracks[i].enabled = i === Number(audioSelect.value);
            };
            player.addEventListener('loadedmetadata', () => { const position = resumePositions.get(resumeKey) || 0; if(!activeHls&&timelineOffset===0&&position>1&&position<player.duration-1)player.currentTime=position; }, { once: true });
            player.addEventListener('timeupdate', () => { if (valid(run) && Number.isFinite(player.currentTime)) resumePositions.set(resumeKey, absoluteTime()); });
            player.addEventListener('ended', () => resumePositions.delete(resumeKey), { once: true });
            function onError(){if(!valid(run))return;if(directPossible&&!activeHls&&!fallbackStarted){fallbackStarted=true;void useHls(selectedAudio,true,absoluteTime()).catch(()=>{message.textContent=t('playbackError');});}else message.textContent=t('playbackError');}
            player.addEventListener('error', onError, { once: true });
            if (directPossible) await player.play().catch(onError);
        } catch (error) {
            if (error.status === 403) fail(run);
            else if (valid(run)) body.append(el('p', t('playbackError'), 'gra-error'));
        } finally {if(playPending===run)playPending=0;}
    }
    async function tick() {
        const now = Date.now(), gap = now - lastTick; lastTick = now;
        const c = current();
        if (dialog) {
            if (!c || c.id !== identity || document.hidden || gap > 4000 || gap < 0 || (token && now - lastActivity >= idleMinutes * 60000)) { lock(); return; }
            if (token && !beatPending && now - lastBeat >= 2000) {
                if(activePlayer&&!activePlayer.paused&&!activePlayer.ended){activity=true;lastActivity=now;}const run = generation, t = token, active = activity; activity = false; beatPending = true;
                try { await request(c, 'Heartbeat', { method: 'POST', session: t, data: { Active: active } }); if (valid(run)) lastBeat = Date.now(); }
                catch (_) { fail(run); }
                finally { if (run === generation) beatPending = false; }
            }
            // A blocked request must not leave the section visible beyond its lease.
            if (token && now - lastBeat >= 6000) lock();
            return;
        }
        const host = [...document.querySelectorAll('#homeTab')].find(n => n.getClientRects().length);
        if (!c || !host || document.hidden) { clearHome(); return; }
        if (home && homeIdentity !== c.id) { clearHome(); statusAt = 0; }
        if (home && host.lastElementChild !== home) host.append(home);
        if (statusPending || now < statusAt) return;
        statusPending = true; statusAt = now + 15000;
        try {
            const status = await json(c, 'Status');
            if (current()?.id !== c.id || !host.isConnected || dialog || document.hidden) return;
            if (!status.Available) { clearHome(); return; }
            homePresentation = status;
            if (!home) {
                home = el('section', undefined, 'gra-home'); homeIdentity = c.id;
                const b = el('button', undefined, 'gra-card'), copy = el('span', undefined, 'gra-home-copy'); b.type = 'button';
                copy.append(el('span', status.HomeTitle || 'Adult', 'gra-home-title'));
                if (status.HomeDescription) copy.append(el('span', status.HomeDescription, 'gra-home-description'));
                b.append(copy); b.onclick = open; home.append(b); host.append(home);
                try {
                    const imageResponse = await request(c, 'HomeCover'); const blob = await imageResponse.blob();
                    if (!home || homeIdentity !== c.id) return;
                    homeUrl = URL.createObjectURL(blob); const image = el('img'); image.alt = ''; image.src = homeUrl; b.prepend(image);
                } catch (_) { }
            }
        } catch (_) { clearHome(); }
        finally { statusPending = false; }
    }
    for (const name of ['pointerdown', 'keydown', 'wheel', 'touchstart']) document.addEventListener(name, e => {
        if (dialog && e.isTrusted && dialog.contains(e.target)) { lastActivity = Date.now(); activity = true; }
    }, { capture: true, passive: true });
    document.addEventListener('keydown', e => {
        if (!dialog) return;
        if (e.key === 'Escape') { e.preventDefault(); lock(); }
        if (e.key === 'Tab') { const nodes = [...dialog.querySelectorAll('button:not(:disabled),input,a[href]')]; const first = nodes[0], last = nodes[nodes.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); } }
    }, true);
    document.addEventListener('click', e => { if (dialog && !dialog.contains(e.target)) lock(); }, true);
    window.addEventListener('popstate', e => { if (!dialog) return; if (!e.state?.grAdult || !token) lock(); else if (e.state.category) void videos(generation, e.state.category); else void categories(generation); });
    for (const event of ['hashchange', 'pagehide', 'blur', 'offline']) window.addEventListener(event, lock);
    document.addEventListener('visibilitychange', () => { if (document.hidden) lock(); else void tick(); });
    document.addEventListener('freeze', lock);
    document.addEventListener('viewshow', () => { if (dialog) lock(); statusAt = 0; void tick(); });
    window.addEventListener('genreRowsSettingsChanged', () => { lock(); clearHome(); statusAt = 0; });
    setInterval(() => { void tick(); }, 1000); void tick();
})();

