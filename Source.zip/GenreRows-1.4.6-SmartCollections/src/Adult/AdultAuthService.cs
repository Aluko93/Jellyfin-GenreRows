using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Jellyfin.Plugin.GenreRows.Adult;

public sealed class AdultConfiguration
{
    public bool Enabled { get; set; }
    public string RootPath { get; set; } = "";
    public string HomeVisibility { get; set; } = "AllUsers";
    public string[] AllowedUserIds { get; set; } = [];
    public int IdleMinutes { get; set; } = 5;
    public string PasswordHash { get; set; } = "";
    public string HomeTitle { get; set; } = "Adult";
    public string HomeDescription { get; set; } = "Area protetta";
    // Empty means the user-supplied image embedded in the plugin.
    public string HomeImageFile { get; set; } = "";
    public AdultCategoryConfiguration[] Categories { get; set; } = [];
}

public sealed class AdultCategoryConfiguration
{
    // FolderName is the immutable filesystem key; the displayed title is independent.
    public string FolderName { get; set; } = "";
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public string ImageFile { get; set; } = "";
}

// All state is process-local: restart always locks. Tokens are never persisted.
public sealed class AdultAuthService(TimeProvider? clock = null)
{
    private readonly TimeProvider clock = clock ?? TimeProvider.System;
    private readonly object gate = new();
    private readonly Dictionary<string, Session> sessions = [];
    private readonly Dictionary<Guid, Queue<DateTimeOffset>> attempts = [];
    private readonly Queue<DateTimeOffset> globalAttempts = [];
    public const int LeaseSeconds = 8;
    private sealed class Session
    {
        public required Guid User;
        public required string Binding;
        public required string Config;
        public DateTimeOffset Lease, Activity, Created;
    }
    // Adult is available to any authenticated Jellyfin account. The shared Adult password
    // is the access gate; a user allowlist caused admin setup failures and is unnecessary here.
    public static bool Allowed(AdultConfiguration c, Guid user) => c.Enabled && user != Guid.Empty &&
        (!string.Equals(c.HomeVisibility, "SelectedUsers", StringComparison.OrdinalIgnoreCase) ||
         (c.AllowedUserIds ?? []).Any(id => Guid.TryParse(id, out var allowed) && allowed == user));
    public static bool ShowHomeCard(AdultConfiguration c, Guid user) => Allowed(c, user) &&
        !string.Equals(c.HomeVisibility, "Hidden", StringComparison.OrdinalIgnoreCase);
    public static string HashPassword(string password)
    {
        if (password.Length is < 6 or > 256) throw new ArgumentException("Usare da 6 a 256 caratteri.");
        var salt = RandomNumberGenerator.GetBytes(32);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 600000, HashAlgorithmName.SHA256, 32);
        return "600000:" + Convert.ToBase64String(salt) + ":" + Convert.ToBase64String(hash);
    }
    public static bool Verify(string password, string stored)
    {
        if (password.Length > 256) return false;
        try {
            var parts = stored.Split(':');
            if (parts.Length != 3 || !int.TryParse(parts[0], out var rounds) || rounds is not (210000 or 600000)) return false;
            var salt = Convert.FromBase64String(parts[1]); var expected = Convert.FromBase64String(parts[2]);
            return salt.Length == 32 && expected.Length == 32 && CryptographicOperations.FixedTimeEquals(
                expected, Rfc2898DeriveBytes.Pbkdf2(password, salt, rounds, HashAlgorithmName.SHA256, 32));
        } catch (FormatException) { return false; }
    }
    private static string Digest(string value) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));
    private static string Stamp(AdultConfiguration c) => Digest(JsonSerializer.Serialize(c));
    public string? Unlock(AdultConfiguration c, Guid user, string binding, string password)
    {
        lock (gate) {
            var now = clock.GetUtcNow();
            foreach (var key in sessions.Where(p => p.Value.Lease <= now).Select(p => p.Key).ToArray()) sessions.Remove(key);
            if (!Allowed(c, user) || string.IsNullOrEmpty(binding) || sessions.Count >= 128) return null;
            if (!attempts.TryGetValue(user, out var queue)) attempts[user] = queue = new();
            while (queue.TryPeek(out var t) && t <= now.AddMinutes(-1)) queue.Dequeue();
            while (globalAttempts.TryPeek(out var t) && t <= now.AddMinutes(-1)) globalAttempts.Dequeue();
            if (queue.Count >= 5 || globalAttempts.Count >= 30) return null;
            queue.Enqueue(now); globalAttempts.Enqueue(now);
            if (!Verify(password, c.PasswordHash)) return null;
            // One Adult session per Jellyfin login; opening another tab locks the old one.
            foreach (var key in sessions.Where(p => p.Value.User == user && p.Value.Binding == Digest(binding)).Select(p => p.Key).ToArray()) sessions.Remove(key);
            var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
            sessions[Digest(token)] = new Session { User = user, Binding = Digest(binding), Config = Stamp(c),
                Activity = now, Created = now, Lease = now.AddSeconds(LeaseSeconds) };
            return token;
        }
    }
    public bool Validate(AdultConfiguration c, Guid user, string binding, string token, bool heartbeat = false, bool active = false)
    {
        lock (gate) {
            if (token.Length != 64) return false;
            var key = Digest(token); var now = clock.GetUtcNow();
            if (!sessions.TryGetValue(key, out var s)) return false;
            if (!Allowed(c, user) || s.User != user || s.Binding != Digest(binding) || s.Config != Stamp(c) ||
                now >= s.Lease || now >= s.Activity.AddMinutes(Math.Clamp(c.IdleMinutes, 1, 15)) || now >= s.Created.AddHours(1)) {
                sessions.Remove(key); return false;
            }
            if (heartbeat) { s.Lease = now.AddSeconds(LeaseSeconds); if (active) s.Activity = now; }
            return true;
        }
    }
    public void Lock(string token) { lock (gate) { sessions.Remove(Digest(token)); } }
    public void LockAll() { lock (gate) { sessions.Clear(); } }
}


