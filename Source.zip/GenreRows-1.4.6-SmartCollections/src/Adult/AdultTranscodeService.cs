using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Jellyfin.Plugin.GenreRows.Adult;

/// <summary>Runs bounded, per-playback FFmpeg HLS jobs; no standalone media server is created.</summary>
public static partial class AdultTranscodeService
{
    private sealed class Job(string directory, Process process, CancellationTokenSource cancellation)
    {
        public string Directory { get; } = directory;
        public Process Process { get; } = process;
        public CancellationTokenSource Cancellation { get; } = cancellation;
        public Task? Worker { get; set; }
        public volatile bool Failed;
    }

    private static readonly object Gate = new();
    private static readonly Dictionary<string, Job> Jobs = new(StringComparer.Ordinal);
    private static readonly SemaphoreSlim Slots = new(2, 2);
    private static bool initialized;

    public static async Task StartAsync(string ticket, string videoPath, int audioStreamIndex, CancellationToken cancellationToken, double startSeconds = 0)
    {
        lock (Gate) {
            InitializeCache();
            if (Jobs.TryGetValue(ticket, out var existing) && !existing.Failed) return;
        }
        await Slots.WaitAsync(cancellationToken).ConfigureAwait(false);
        var slotOwned = true;
        string? directory = null;
        Process? process = null;
        CancellationTokenSource? stop = null;
        try {
            lock (Gate) {
                if (Jobs.TryGetValue(ticket, out var existing) && !existing.Failed) { Slots.Release(); slotOwned = false; return; }
            }
            var cacheRoot = GetCacheRoot();
            directory = Path.Combine(cacheRoot, ticket);
            Directory.CreateDirectory(directory);
            var start = new ProcessStartInfo {
                FileName = AdultThumbnailService.FindTool("ffmpeg"), WorkingDirectory = directory, UseShellExecute = false,
                RedirectStandardError = true, CreateNoWindow = true
            };
            // Relative names keep local filesystem paths out of the HLS manifest sent to the browser.
            const string output = "index.m3u8";
            const string segmentPattern = "segment_%05d.ts";
            var arguments = new List<string> { "-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-ss", startSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture), "-i", videoPath, "-map", "0:v:0" };
            if (audioStreamIndex >= 0) { arguments.AddRange(["-map", "0:" + audioStreamIndex.ToString(System.Globalization.CultureInfo.InvariantCulture)]); }
            arguments.AddRange(["-sn", "-dn", "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", "-vf", "scale=w='min(1920,iw)':h=-2"]);
            if (audioStreamIndex >= 0) arguments.AddRange(["-c:a", "aac", "-b:a", "192k", "-ac", "2"]);
            arguments.AddRange(["-f", "hls", "-hls_time", "4", "-hls_playlist_type", "event", "-hls_flags", "independent_segments", "-hls_segment_filename", segmentPattern, output]);
            foreach (var arg in arguments) start.ArgumentList.Add(arg);
            process = new Process { StartInfo = start, EnableRaisingEvents = true };
            stop = new CancellationTokenSource();
            if (!process.Start()) throw new IOException("Impossibile avviare FFmpeg.");
            var job = new Job(directory, process, stop);
            lock (Gate) Jobs[ticket] = job;
            var stderr = process.StandardError.ReadToEndAsync(stop.Token);
            job.Worker = Task.Run(async () => {
                try {
                    await process.WaitForExitAsync(stop.Token).ConfigureAwait(false);
                    _ = await stderr.ConfigureAwait(false);
                    job.Failed = process.ExitCode != 0;
                } catch (OperationCanceledException) { job.Failed = true; }
                finally { Slots.Release(); }
            });
            slotOwned = false;

            using var wait = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, stop.Token);
            wait.CancelAfter(TimeSpan.FromSeconds(90));
            while ((!File.Exists(Path.Combine(directory, output)) && !File.Exists(Path.Combine(directory, output + ".tmp"))) || !Directory.EnumerateFiles(directory, "segment_*.ts").Any()) {
                if (job.Failed) throw new IOException("FFmpeg non ha generato il flusso HLS.");
                await Task.Delay(200, wait.Token).ConfigureAwait(false);
            }
        } catch {
            if (slotOwned) Slots.Release();
            Stop(ticket);
            throw;
        }
    }

    public static string? ResolveFile(string ticket, string file)
    {
        if (!SafeFileName().IsMatch(file) || file is "." or "..") return null;
        lock (Gate) {
            InitializeCache();
            if (!Jobs.TryGetValue(ticket, out var job) || job.Failed) return null;
            var path = Path.GetFullPath(Path.Combine(job.Directory, file));
            if (!path.StartsWith(Path.TrimEndingDirectorySeparator(job.Directory) + Path.DirectorySeparatorChar, StringComparison.Ordinal)) return null;
            if (file != "index.m3u8" && !Regex.IsMatch(file, @"^segment_[0-9]{5}\.ts$", RegexOptions.CultureInvariant)) return null;
            if (file == "index.m3u8" && !File.Exists(path)) path += ".tmp";
            return File.Exists(path) ? path : null;
        }
    }

    public static void Stop(string ticket)
    {
        Job? job;
        lock (Gate) { if (!Jobs.Remove(ticket, out job)) return; }
        try { job.Cancellation.Cancel(); } catch (ObjectDisposedException) { }
        try { if (!job.Process.HasExited) job.Process.Kill(true); } catch (Exception e) when (e is InvalidOperationException or System.ComponentModel.Win32Exception) { }
        try { job.Worker?.Wait(TimeSpan.FromSeconds(5)); } catch (AggregateException) { }
        try { if (Directory.Exists(job.Directory)) Directory.Delete(job.Directory, true); } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
        job.Process.Dispose(); job.Cancellation.Dispose();
    }

    public static void StopAll()
    {
        string[] keys; lock (Gate) keys = Jobs.Keys.ToArray();
        foreach (var key in keys) Stop(key);
    }

    private static string GetCacheRoot()
    {
        var data = Plugin.Instance?.DataFolderPath;
        if (string.IsNullOrWhiteSpace(data)) throw new IOException("Cartella dati del plugin non disponibile.");
        return Path.GetFullPath(Path.Combine(data, "AdultPlayback"));
    }

    private static void InitializeCache()
    {
        if (initialized) return;
        var root = GetCacheRoot(); Directory.CreateDirectory(root);
        AdultLibraryService.NoLinks(root);
        foreach (var directory in Directory.EnumerateDirectories(root)) {
            var name = Path.GetFileName(directory);
            if (name.Length == 64 && name.All(Uri.IsHexDigit)) try { Directory.Delete(directory, true); } catch (IOException) { }
        }
        initialized = true;
    }

    [GeneratedRegex("^[a-zA-Z0-9_.-]{1,64}$", RegexOptions.CultureInvariant)]
    private static partial Regex SafeFileName();
}


