using MediaBrowser.Controller.Library;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace Jellyfin.Plugin.GenreRows.Adult;

[ApiController, Authorize, Route("GenreRows/Adult")]
public sealed class AdultController(ILibraryManager library, IUserManager users, ILogger<AdultController> logger) : ControllerBase, IActionFilter
{
    private static readonly AdultAuthService Auth = new();
    internal static void PrunePlayback() => AdultPlaybackService.Sweep(ticket =>
        Auth.Validate(Plugin.Instance?.Configuration.Adult ?? new(), ticket.UserId, ticket.Binding, ticket.AdultToken));
    private AdultConfiguration Config => Plugin.Instance?.Configuration.Adult ?? new();
    private Guid UserId => Guid.TryParse(User.FindFirst("Jellyfin-UserId")?.Value, out var id) ? id : Guid.Empty;
    // Jellyfin 12 uses Authorization: MediaBrowser ...; bind the temporary Adult
    // session to that authenticated web login without relying on the retired header.
    private string Binding => Request.Headers["Authorization"].ToString();
    private string Token => Request.Headers["X-Adult-Session"].ToString();
    private AdultLibraryService Files => new(library);
    public void OnActionExecuting(ActionExecutingContext context) {
        Response.Headers.CacheControl = "no-store, private";
        Response.Headers.Pragma = "no-cache";
        Response.Headers["X-Content-Type-Options"] = "nosniff";
        Response.Headers["Referrer-Policy"] = "no-referrer";
    }
    public void OnActionExecuted(ActionExecutedContext context) { }
    private bool Valid() => Auth.Validate(Config, UserId, Binding, Token);
    [HttpGet("Status")]
    public object Status() => new { Available = AdultAuthService.ShowHomeCard(Config, UserId), LeaseSeconds = AdultAuthService.LeaseSeconds,
        HomeTitle = Text(Config.HomeTitle, "Adult", 80), HomeDescription = Text(Config.HomeDescription, "", 240) };
    [HttpGet("HomeCover")]
    public IActionResult HomeCover() {
        if (!AdultAuthService.Allowed(Config, UserId)) return Forbid();
        try {
            var image = Files.CustomHomeCover(Config) ?? AdultResources.DefaultCover;
            return File(image.Bytes, image.ContentType);
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) {
            return File(AdultResources.DefaultCover.Bytes, AdultResources.DefaultCover.ContentType);
        }
    }
    public sealed record UnlockRequest(string Password);
    [HttpPost("Unlock"), RequestSizeLimit(4096)]
    public IActionResult Unlock(UnlockRequest request) {
        if (!AdultAuthService.Allowed(Config, UserId)) return Forbid();
        try { Files.Root(Config); } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return StatusCode(503); }
        var token = Auth.Unlock(Config, UserId, Binding, request.Password ?? "");
        return token is null ? StatusCode(429, new { Error = "Accesso negato. Verificare la password o attendere un minuto." }) :
            Ok(new { Token = token, IdleMinutes = Math.Clamp(Config.IdleMinutes, 1, 15), LeaseSeconds = AdultAuthService.LeaseSeconds });
    }
    public sealed record HeartbeatRequest(bool Active);
    [HttpPost("Heartbeat"), RequestSizeLimit(4096)]
    public IActionResult Heartbeat(HeartbeatRequest request) => Auth.Validate(Config, UserId, Binding, Token, true, request.Active) ? NoContent() : Forbid();
    [HttpPost("Lock"), RequestSizeLimit(4096)]
    public IActionResult Lock() {
        Auth.Lock(Token); AdultPlaybackService.RevokeAdultToken(Token);
        Response.Cookies.Delete("gr_adult_play", new CookieOptions { Path = Request.PathBase + "/GenreRows/Adult/Playback", Secure = Request.IsHttps, SameSite = SameSiteMode.Strict, HttpOnly = true });
        return NoContent();
    }
    [HttpGet("Categories")]
    public IActionResult Categories() => Read(() => Ok(Files.Categories(Config)));
    [HttpGet("Videos")]
    public IActionResult Videos([FromQuery] string category) => Read(() => Ok(Files.Videos(Config, category)));
    [HttpGet("Cover")]
    public IActionResult Cover([FromQuery] string category) => Read(() => { var image = Files.Cover(Config, category); return File(image.Bytes, image.ContentType); });
    [HttpGet("Thumbnail")]
    public async Task<IActionResult> Thumbnail([FromQuery] string category, [FromQuery] string video, CancellationToken cancellationToken) {
        if (!Valid()) return Forbid();
        string path;
        try { path = Files.VideoFile(Config, category, video); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
        try {
            cancellationToken.ThrowIfCancellationRequested();
            var cover = AdultLibraryService.CustomVideoCover(path);
            if (cover is { } image) return Valid() ? File(image.Bytes, image.ContentType) : Forbid();
            var jpeg = await AdultThumbnailService.GetOrCreateAsync(path, cancellationToken).ConfigureAwait(false);
            return Valid() ? File(jpeg, "image/jpeg") : Forbid();
        } catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { return StatusCode(499); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException or System.ComponentModel.Win32Exception or InvalidOperationException) {
            return StatusCode(503, new { Error = "Anteprima non disponibile: verificare che FFmpeg sia installato nel container e che il video sia leggibile." });
        }
    }
    [HttpGet("Metadata")]
    public async Task<IActionResult> Metadata(string category, string video, CancellationToken cancellationToken) {
        if (!Valid()) return Forbid();
        try {
            var path = Files.VideoFile(Config, category, video);
            var info = await AdultThumbnailService.GetMediaInfoAsync(path, cancellationToken).ConfigureAwait(false);
            return Valid() ? Ok(new { info.DurationSeconds }) : Forbid();
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException or System.ComponentModel.Win32Exception or InvalidOperationException or System.Text.Json.JsonException) { return NotFound(); }
    }
    public sealed record PlaybackOpenRequest(string Category, string Video);
    [HttpPost("Playback/Open"), RequestSizeLimit(4096)]
    public async Task<IActionResult> PlaybackOpen(PlaybackOpenRequest request, CancellationToken cancellationToken) {
        if (!Valid()) return Forbid();
        string path;
        try { path = Files.VideoFile(Config, request.Category, request.Video); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
        var mediaInfo = new AdultThumbnailService.MediaInfo(0, "", "", [], []);
        try { mediaInfo = await AdultThumbnailService.GetMediaInfoAsync(path, cancellationToken).ConfigureAwait(false); }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { return StatusCode(499); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException or System.ComponentModel.Win32Exception or InvalidOperationException or System.Text.Json.JsonException) { /* Direct Play may work without FFprobe metadata. */ }
        if (!Valid()) return Forbid();
        var externalSubtitle = FindExternalSubtitle(path);
        var subtitleTracks = mediaInfo.SubtitleTracks.ToList();
        if (externalSubtitle is not null) subtitleTracks.Add(new AdultThumbnailService.TrackInfo(-2, Path.GetExtension(externalSubtitle), "und", "External"));
        var ticket = AdultPlaybackService.Create(Token, UserId, Binding, request.Category, request.Video);
        Response.Cookies.Append("gr_adult_play", ticket, new CookieOptions {
            HttpOnly = true, Secure = Request.IsHttps, SameSite = SameSiteMode.Strict,
            Path = Request.PathBase + "/GenreRows/Adult/Playback", MaxAge = TimeSpan.FromHours(1), IsEssential = true
        });
        // ApiClient.getUrl adds Jellyfin's configured BaseUrl. Return route-relative paths
        // here so installations behind /jellyfin do not get a duplicated prefix.
        return Ok(new { StreamUrl = "GenreRows/Adult/Playback/Stream", ContentType = ContentTypeFor(path),
            DurationSeconds = mediaInfo.DurationSeconds, Container = mediaInfo.Container, VideoCodec = mediaInfo.VideoCodec,
            AudioTracks = mediaInfo.AudioTracks, SubtitleTracks = subtitleTracks });
    }

    public sealed record PlaybackTranscodeRequest(int AudioIndex, bool Restart = false, double StartSeconds = 0);
    [HttpPost("Playback/Transcode"), RequestSizeLimit(4096)]
    public async Task<IActionResult> PlaybackTranscode(PlaybackTranscodeRequest request, CancellationToken cancellationToken) {
        if (!Valid()) return Forbid();
        var ticketId = Request.Cookies["gr_adult_play"] ?? "";
        var ticket = AdultPlaybackService.Find(ticketId);
        if (ticket is null || ticket.AdultToken != Token || ticket.UserId != UserId || ticket.Binding != Binding) return Forbid();
        string path;
        try { path = Files.VideoFile(Config, ticket.Category, ticket.Video); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
        try {
            var info = await AdultThumbnailService.GetMediaInfoAsync(path, cancellationToken).ConfigureAwait(false);
            if (request.AudioIndex < 0 ? info.AudioTracks.Length != 0 : !info.AudioTracks.Any(x => x.Index == request.AudioIndex)) return BadRequest(new { Error = "Traccia audio non valida." });
            if(!double.IsFinite(request.StartSeconds)||request.StartSeconds<0||request.StartSeconds>info.DurationSeconds)return BadRequest();
            if (request.Restart) AdultTranscodeService.Stop(ticketId);
            await AdultTranscodeService.StartAsync(ticketId, path, request.AudioIndex, cancellationToken, request.StartSeconds).ConfigureAwait(false);
            return TicketValid(ticketId, ticket) ? Ok(new { ManifestUrl = "GenreRows/Adult/Playback/Manifest/index.m3u8" }) : Forbid();
        } catch (OperationCanceledException e) {
            AdultTranscodeService.Stop(ticketId);
            if (cancellationToken.IsCancellationRequested) return StatusCode(499);
            logger.LogError(e, "Adult HLS transcode did not produce its first segment before the startup deadline.");
            return StatusCode(503, new { Error = "Transcoding non disponibile: FFmpeg non ha prodotto il primo segmento entro il tempo previsto." });
        }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException or System.ComponentModel.Win32Exception or InvalidOperationException) {
            logger.LogError(e, "Adult HLS transcode failed.");
            AdultTranscodeService.Stop(ticketId); return StatusCode(503, new { Error = "Transcoding non disponibile. Verificare FFmpeg e lo spazio temporaneo." });
        }
    }

    [AllowAnonymous, HttpGet("Playback/Manifest/{asset}")]
    public IActionResult PlaybackManifest(string asset) => PlaybackAsset(asset);
    [AllowAnonymous, HttpGet("Playback/Segment/{asset}")]
    public IActionResult PlaybackSegment(string asset) => PlaybackAsset(asset);
    private IActionResult PlaybackAsset(string asset) {
        var ticketId = Request.Cookies["gr_adult_play"] ?? "";
        var ticket = AdultPlaybackService.Find(ticketId);
        if (ticket is null || !Auth.Validate(Config, ticket.UserId, ticket.Binding, ticket.AdultToken)) return Forbid();
        var path = AdultTranscodeService.ResolveFile(ticketId, asset);
        if (path is null) return NotFound();
        var type = asset.Equals("index.m3u8", StringComparison.Ordinal) ? "application/vnd.apple.mpegurl" : "video/mp2t";
        if (type == "application/vnd.apple.mpegurl") return File(System.IO.File.ReadAllBytes(path), type);
        return File(new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan), type, enableRangeProcessing: true);
    }

    // The media element cannot attach Jellyfin's Authorization header. This deliberately
    // anonymous route accepts only a random HttpOnly ticket cookie minted by Playback/Open.
    [AllowAnonymous, HttpGet("Playback/Stream")]
    public async Task<IActionResult> PlaybackStream(CancellationToken cancellationToken) {
        var ticketId = Request.Cookies["gr_adult_play"] ?? "";
        var ticket = AdultPlaybackService.Find(ticketId);
        if (ticket is null || !Auth.Validate(Config, ticket.UserId, ticket.Binding, ticket.AdultToken)) return Forbid();
        string path;
        try { path = Files.VideoFile(Config, ticket.Category, ticket.Video); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
        var info = new FileInfo(path);
        if (!info.Exists || info.Length < 1) return NotFound();
        var start = 0L; var end = info.Length - 1;
        if (Request.Headers.TryGetValue("Range", out var ranges)) {
            var text = ranges.ToString();
            if (!text.StartsWith("bytes=", StringComparison.OrdinalIgnoreCase) || text.Contains(',')) return RangeNotSatisfiable(info.Length);
            var parts = text[6..].Split('-', 2);
            if (parts.Length != 2) return RangeNotSatisfiable(info.Length);
            if (parts[0].Length == 0) {
                if (!long.TryParse(parts[1], out var suffix) || suffix <= 0) return RangeNotSatisfiable(info.Length);
                start = Math.Max(0, info.Length - suffix);
            } else if (!long.TryParse(parts[0], out start) || start < 0 || start >= info.Length) return RangeNotSatisfiable(info.Length);
            if (parts[0].Length > 0 && parts[1].Length > 0 && (!long.TryParse(parts[1], out end) || end < start)) return RangeNotSatisfiable(info.Length);
            end = Math.Min(end, info.Length - 1);
            Response.StatusCode = StatusCodes.Status206PartialContent;
            Response.Headers.ContentRange = $"bytes {start}-{end}/{info.Length}";
        }
        Response.Headers.AcceptRanges = "bytes";
        Response.ContentType = ContentTypeFor(path);
        Response.ContentLength = end - start + 1;
        if (HttpMethods.IsHead(Request.Method)) return new EmptyResult();
        await using var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
        input.Seek(start, SeekOrigin.Begin);
        var buffer = new byte[128 * 1024]; var remaining = end - start + 1;
        while (remaining > 0 && !cancellationToken.IsCancellationRequested) {
            if (!TicketValid(ticketId, ticket)) return new EmptyResult();
            var read = await input.ReadAsync(buffer.AsMemory(0, (int)Math.Min(buffer.Length, remaining)), cancellationToken).ConfigureAwait(false);
            if (read == 0) break;
            await Response.Body.WriteAsync(buffer.AsMemory(0, read), cancellationToken).ConfigureAwait(false);
            remaining -= read;
        }
        return new EmptyResult();
    }

    [AllowAnonymous, HttpGet("Playback/Subtitle/{streamIndex:int}")]
    public async Task<IActionResult> PlaybackSubtitle(int streamIndex, CancellationToken cancellationToken) {
        var ticketId = Request.Cookies["gr_adult_play"] ?? "";
        var ticket = AdultPlaybackService.Find(ticketId);
        if (ticket is null || !Auth.Validate(Config, ticket.UserId, ticket.Binding, ticket.AdultToken)) return Forbid();
        string path;
        try { path = Files.VideoFile(Config, ticket.Category, ticket.Video); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
        try {
            byte[] subtitles;
            if (streamIndex == -2) {
                var external = FindExternalSubtitle(path); if (external is null) return NotFound();
                var info = new FileInfo(external); if (info.Length > 5 * 1024 * 1024) return StatusCode(413);
                subtitles = Path.GetExtension(external).Equals(".vtt", StringComparison.OrdinalIgnoreCase)
                    ? await System.IO.File.ReadAllBytesAsync(external, cancellationToken).ConfigureAwait(false)
                    : await AdultThumbnailService.ConvertExternalSubtitleAsync(external, cancellationToken).ConfigureAwait(false);
            } else subtitles = await AdultThumbnailService.ExtractSubtitleAsync(path, streamIndex, cancellationToken).ConfigureAwait(false);
            return TicketValid(ticketId, ticket) ? File(subtitles, "text/vtt; charset=utf-8") : Forbid();
        } catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { return StatusCode(499); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException or System.ComponentModel.Win32Exception or InvalidOperationException) {
            return StatusCode(503);
        }
    }

    [HttpPost("Playback/Close"), RequestSizeLimit(4096)]
    public IActionResult PlaybackClose() {
        if (!Valid()) return Forbid();
        var id = Request.Cookies["gr_adult_play"] ?? "";
        if (AdultPlaybackService.Find(id)?.AdultToken == Token) AdultPlaybackService.Revoke(id);
        return NoContent();
    }

    private bool TicketValid(string id, AdultPlaybackService.PlaybackTicket ticket) =>
        AdultPlaybackService.Find(id) is not null && Auth.Validate(Config, ticket.UserId, ticket.Binding, ticket.AdultToken);
    private static string? FindExternalSubtitle(string videoPath) {
        var directory = Path.GetDirectoryName(videoPath); var stem = Path.GetFileNameWithoutExtension(videoPath);
        if (string.IsNullOrEmpty(directory) || string.IsNullOrEmpty(stem)) return null;
        foreach (var ext in new[] { ".vtt", ".srt" }) {
            var candidate = Path.Combine(directory, stem + ext);
            if (!System.IO.File.Exists(candidate)) continue;
            AdultLibraryService.NoLinks(candidate);
            if (new FileInfo(candidate).Length <= 5 * 1024 * 1024) return candidate;
        }
        return null;
    }
    private IActionResult RangeNotSatisfiable(long length) { Response.Headers.ContentRange = $"bytes */{length}"; return StatusCode(StatusCodes.Status416RangeNotSatisfiable); }
    private static string ContentTypeFor(string path) => Path.GetExtension(path).ToLowerInvariant() switch {
        ".mp4" or ".m4v" => "video/mp4", ".webm" => "video/webm", ".mov" => "video/quicktime",
        ".avi" => "video/x-msvideo", ".wmv" => "video/x-ms-wmv", ".ts" => "video/mp2t", ".mkv" => "video/x-matroska", _ => "application/octet-stream"
    };
    private IActionResult Read(Func<IActionResult> read) {
        if (!Valid()) return Forbid();
        try { var result = read(); return Valid() ? result : Forbid(); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return NotFound(); }
    }
    [Authorize(Policy = "RequiresElevation"), HttpGet("Configuration")]
    public object GetConfiguration() {
        string[] folders = [];
        try { folders = Files.CategoryFolders(Config); } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { }
        var configured = (Config.Categories ?? []).Where(x => !string.IsNullOrWhiteSpace(x.FolderName))
            .GroupBy(x => x.FolderName, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        return new { Config.Enabled, Config.RootPath, Config.IdleMinutes, Config.HomeVisibility, Config.AllowedUserIds,
            Users = users.GetUsers().Select(x => new { Id = x.Id, Name = x.Username }).OrderBy(x => x.Name).ToArray(), HasPassword = Config.PasswordHash.Length > 0,
            HomeTitle = Text(Config.HomeTitle, "Adult", 80), HomeDescription = Text(Config.HomeDescription, "", 240), Config.HomeImageFile,
            Categories = folders.Select(folder => configured.TryGetValue(folder, out var item) ? new {
                FolderName = folder, Title = Text(item.Title, folder, 100), Description = Text(item.Description, "", 500), ImageFile = item.ImageFile ?? ""
            } : new { FolderName = folder, Title = folder, Description = "", ImageFile = "" }).ToArray() };
    }
    public sealed record CategorySettingsRequest(string FolderName, string Title, string Description, string ImageFile);
    public sealed record SettingsRequest(bool Enabled, string RootPath, int IdleMinutes, string? Password,
        string HomeTitle, string HomeDescription, string HomeImageFile, CategorySettingsRequest[] Categories,
        string HomeVisibility = "AllUsers", string[]? AllowedUserIds = null);
    [Authorize(Policy = "RequiresElevation"), HttpPost("Configuration"), RequestSizeLimit(16384)]
    public IActionResult Configure(SettingsRequest request) {
        if (Plugin.Instance is not { } plugin) return StatusCode(503);
        var next = new AdultConfiguration { Enabled = request.Enabled, RootPath = request.RootPath ?? "", IdleMinutes = request.IdleMinutes,
            HomeVisibility = request.HomeVisibility, AllowedUserIds = request.AllowedUserIds ?? [], PasswordHash = Config.PasswordHash };
        if (next.HomeVisibility is not ("AllUsers" or "SelectedUsers" or "Hidden")) return BadRequest(new { Error = "Modalità visibilità non valida." });
        if (next.HomeVisibility == "SelectedUsers") {
            if (next.AllowedUserIds.Any(id => !Guid.TryParse(id, out _) || users.GetUserById(Guid.Parse(id)) is null))
                return BadRequest(new { Error = "La selezione contiene utenti Jellyfin non validi." });
            next.AllowedUserIds = next.AllowedUserIds.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            if (next.AllowedUserIds.Length == 0) return BadRequest(new { Error = "Selezionare almeno un utente Jellyfin." });
        } else next.AllowedUserIds = [];
        if (next.IdleMinutes is < 1 or > 15) return BadRequest(new { Error = "Timeout da 1 a 15 minuti." });
        try {
            next.HomeTitle = Text(request.HomeTitle, "Adult", 80); next.HomeDescription = Text(request.HomeDescription, "", 240);
            next.HomeImageFile = FileName(request.HomeImageFile);
            next.Categories = (request.Categories ?? []).Select(x => new AdultCategoryConfiguration {
                FolderName = FolderName(x.FolderName), Title = Text(x.Title, x.FolderName, 100),
                Description = Text(x.Description, "", 500), ImageFile = FileName(x.ImageFile)
            }).GroupBy(x => x.FolderName, StringComparer.OrdinalIgnoreCase).Select(g => g.First()).ToArray();
            if (!string.IsNullOrEmpty(request.Password)) next.PasswordHash = AdultAuthService.HashPassword(request.Password);
            if (next.Enabled) {
                if (next.PasswordHash.Length == 0)
                    return BadRequest(new { Error = "Impostare una password Adult di almeno 6 caratteri." });
                var root = Files.Root(next); var folders = Files.CategoryFolders(next).ToHashSet(StringComparer.OrdinalIgnoreCase);
                next.Categories = next.Categories.Where(x => folders.Contains(x.FolderName)).ToArray();
                if (!string.IsNullOrEmpty(next.HomeImageFile)) AdultLibraryService.ReadImage(root, next.HomeImageFile);
                foreach (var item in next.Categories.Where(x => !string.IsNullOrEmpty(x.ImageFile)))
                    AdultLibraryService.ReadImage(AdultLibraryService.Child(root, item.FolderName, true), item.ImageFile);
            }
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or ArgumentException) { return BadRequest(new { Error = "Verificare percorso, isolamento, permessi e password (minimo 6 caratteri)." }); }
        Auth.LockAll(); AdultPlaybackService.RevokeAll(); plugin.Configuration.Adult = next; plugin.SaveConfiguration(); return NoContent();
    }
    private static string Text(string? value, string fallback, int max) {
        var text = (value ?? "").Trim(); if (text.Length > max) throw new ArgumentException("Testo troppo lungo."); return text.Length == 0 ? fallback : text;
    }
    private static string FileName(string? value) {
        var name = (value ?? "").Trim();
        if (name.Length == 0) return "";
        if (name.Length > 255 || name.IndexOfAny(['/', '\\', ':', '\0']) >= 0 || name is "." or ".." || !AdultLibraryService.ImageExtensions.Contains(Path.GetExtension(name)))
            throw new ArgumentException("Nome immagine non valido.");
        return name;
    }
    private static string FolderName(string? value) {
        var name = (value ?? "").Trim();
        if (name.Length == 0 || name.Length > 255 || name.IndexOfAny(['/', '\\', ':', '\0']) >= 0 || name is "." or "..")
            throw new ArgumentException("Nome cartella non valido.");
        return name;
    }
}

internal static class AdultResources
{
    internal static readonly string Script = Read("adult.js");
    internal static readonly string HlsScript = ReadAsset("Assets.hls.min.js");
    internal static readonly (byte[] Bytes, string ContentType) DefaultCover = (ReadBytes("Assets.adult.png"), "image/png");
    private static string Read(string name) {
        using var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.Adult.Web." + name)!;
        using var reader = new StreamReader(stream); return reader.ReadToEnd();
    }
    private static byte[] ReadBytes(string name) {
        using var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.Adult." + name)!;
        using var buffer = new MemoryStream(); stream.CopyTo(buffer); return buffer.ToArray();
    }
    private static string ReadAsset(string name) {
        using var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.Adult." + name)!;
        using var reader = new StreamReader(stream); return reader.ReadToEnd();
    }
}


