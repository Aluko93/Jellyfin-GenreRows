using System.Security.Cryptography;

namespace Jellyfin.Plugin.GenreRows.Adult;

/// <summary>
/// Issues short lived, HttpOnly browser playback cookies. The Adult session token is
/// never placed in a media URL; each media read is checked against the live server session.
/// </summary>
public static class AdultPlaybackService
{
    private static readonly object Gate = new();
    private static readonly Dictionary<string, PlaybackTicket> Tickets = new(StringComparer.Ordinal);

    public sealed record PlaybackTicket(string AdultToken, Guid UserId, string Binding, string Category, string Video, DateTimeOffset Expires);

    public static string Create(string adultToken, Guid userId, string binding, string category, string video)
    {
        lock (Gate)
        {
            PurgeExpired();
            foreach (var old in Tickets.Where(x => x.Value.AdultToken == adultToken).Select(x => x.Key).ToArray()) { Tickets.Remove(old); AdultTranscodeService.Stop(old); }
            if (Tickets.Count >= 128) throw new InvalidOperationException("Troppi flussi Adult aperti.");
            var ticket = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
            Tickets[ticket] = new PlaybackTicket(adultToken, userId, binding, category, video, DateTimeOffset.UtcNow.AddHours(1));
            return ticket;
        }
    }

    public static PlaybackTicket? Find(string ticket)
    {
        if (ticket.Length != 64) return null;
        lock (Gate)
        {
            PurgeExpired();
            return Tickets.TryGetValue(ticket, out var value) ? value : null;
        }
    }

    public static void Revoke(string ticket)
    {
        if (string.IsNullOrEmpty(ticket)) return;
        lock (Gate) { Tickets.Remove(ticket); AdultTranscodeService.Stop(ticket); }
    }

    public static void RevokeAdultToken(string adultToken)
    {
        if (string.IsNullOrEmpty(adultToken)) return;
        lock (Gate)
            foreach (var key in Tickets.Where(x => x.Value.AdultToken == adultToken).Select(x => x.Key).ToArray()) { Tickets.Remove(key); AdultTranscodeService.Stop(key); }
    }

    public static void RevokeAll()
    {
        lock (Gate) { Tickets.Clear(); AdultTranscodeService.StopAll(); }
    }

    internal static void Sweep(Func<PlaybackTicket, bool> valid)
    {
        string[] expired;
        lock (Gate) expired = Tickets.Where(x => !valid(x.Value)).Select(x => x.Key).ToArray();
        foreach (var ticket in expired) Revoke(ticket);
    }

    private static void PurgeExpired()
    {
        var now = DateTimeOffset.UtcNow;
        foreach (var key in Tickets.Where(x => x.Value.Expires <= now).Select(x => x.Key).ToArray()) { Tickets.Remove(key); AdultTranscodeService.Stop(key); }
    }
}

public sealed class AdultPlaybackReaper(Microsoft.Extensions.Logging.ILogger<AdultPlaybackReaper> logger) : Microsoft.Extensions.Hosting.BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(1));
        try { while (await timer.WaitForNextTickAsync(stoppingToken)) {
            try { AdultController.PrunePlayback(); }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException or InvalidOperationException or System.ComponentModel.Win32Exception) {
                Microsoft.Extensions.Logging.LoggerExtensions.LogWarning(logger, "GenreRows could not finish cleaning an expired playback job; retrying.");
            }
        } }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
        finally { AdultPlaybackService.RevokeAll(); }
    }
}


