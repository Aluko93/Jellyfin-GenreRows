using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace Jellyfin.Plugin.GenreRows.Adult;

/// <summary>Creates one cached JPEG preview per external video without adding it to Jellyfin's library.</summary>
public static class AdultThumbnailService
{
    private const int MaximumJpegBytes = 5 * 1024 * 1024;
    private static readonly SemaphoreSlim GenerationSlots = new(2, 2);
    private static readonly SemaphoreSlim ProbeSlots = new(2, 2);
    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, MediaInfo> MediaCache = new();
    public sealed record TrackInfo(int Index, string Codec, string Language, string Title);
    public sealed record MediaInfo(double DurationSeconds, string Container, string VideoCodec, TrackInfo[] AudioTracks, TrackInfo[] SubtitleTracks);

    public static async Task<MediaInfo> GetMediaInfoAsync(string videoPath, CancellationToken cancellationToken)
    {
        var file = new FileInfo(videoPath);
        var key = videoPath + "|" + file.Length + "|" + file.LastWriteTimeUtc.Ticks;
        if (MediaCache.TryGetValue(key, out var cached)) return cached;
        await ProbeSlots.WaitAsync(cancellationToken).ConfigureAwait(false);
        try {
        if (MediaCache.TryGetValue(key, out cached)) return cached;
        var json = await CaptureTextAsync(FindTool("ffprobe"), ["-v", "error", "-show_entries",
            "format=duration,format_name:stream=index,codec_type,codec_name:stream_tags=language,title", "-of", "json", videoPath],
            TimeSpan.FromSeconds(30), cancellationToken).ConfigureAwait(false);
        var result = ParseMediaInfo(json);
        if (MediaCache.Count >= 512) MediaCache.Clear();
        MediaCache[key] = result;
        return result;
        } finally { ProbeSlots.Release(); }
    }

    // FFprobe versions can represent duration as either a JSON number or string; accept both.
    public static MediaInfo ParseMediaInfo(string json)
    {
        using var document = System.Text.Json.JsonDocument.Parse(json);
        var root = document.RootElement;
        var duration = root.TryGetProperty("format", out var format) && format.TryGetProperty("duration", out var durationValue) &&
            TryReadNumber(durationValue, out var parsed) && double.IsFinite(parsed) ? parsed : 0;
        var container = root.TryGetProperty("format", out format) && format.TryGetProperty("format_name", out var formatName) ? formatName.GetString() ?? "" : "";
        var videoCodec = ""; var audio = new List<TrackInfo>(); var subtitles = new List<TrackInfo>();
        if (root.TryGetProperty("streams", out var streams)) foreach (var stream in streams.EnumerateArray()) {
            if (!stream.TryGetProperty("index", out var index) || !index.TryGetInt32(out var streamIndex)) continue;
            var kind = stream.TryGetProperty("codec_type", out var codecType) ? codecType.GetString() : "";
            var codec = stream.TryGetProperty("codec_name", out var codecName) ? codecName.GetString() ?? "" : "";
            var language = "und"; var title = "";
            if (stream.TryGetProperty("tags", out var tags)) {
                if (tags.TryGetProperty("language", out var lang)) language = lang.GetString() ?? "und";
                if (tags.TryGetProperty("title", out var name)) title = name.GetString() ?? "";
            }
            var item = new TrackInfo(streamIndex, codec, language, title);
            if (kind == "video" && videoCodec.Length == 0) videoCodec = codec;
            else if (kind == "audio") audio.Add(item); else if (kind == "subtitle") subtitles.Add(item);
        }
        return new MediaInfo(Math.Max(0, duration), container, videoCodec, audio.ToArray(), subtitles.ToArray());
    }

    private static bool TryReadNumber(System.Text.Json.JsonElement value, out double number)
    {
        number = 0;
        if (value.ValueKind == System.Text.Json.JsonValueKind.Number) return value.TryGetDouble(out number);
        return value.ValueKind == System.Text.Json.JsonValueKind.String &&
            double.TryParse(value.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out number);
    }

    public static async Task<byte[]> ExtractSubtitleAsync(string videoPath, int streamIndex, CancellationToken cancellationToken)
    {
        if (streamIndex < 0 || streamIndex > 255) throw new ArgumentOutOfRangeException(nameof(streamIndex));
        return await CaptureBytesAsync(FindTool("ffmpeg"), ["-hide_banner", "-loglevel", "error", "-i", videoPath,
            "-map", "0:" + streamIndex.ToString(CultureInfo.InvariantCulture), "-f", "webvtt", "pipe:1"],
            TimeSpan.FromSeconds(60), cancellationToken).ConfigureAwait(false);
    }

    public static async Task<byte[]> ConvertExternalSubtitleAsync(string subtitlePath, CancellationToken cancellationToken) =>
        await CaptureBytesAsync(FindTool("ffmpeg"), ["-hide_banner", "-loglevel", "error", "-i", subtitlePath, "-f", "webvtt", "pipe:1"],
            TimeSpan.FromSeconds(60), cancellationToken).ConfigureAwait(false);

    public static async Task<byte[]> GetOrCreateAsync(string videoPath, CancellationToken cancellationToken)
    {
        var info = new FileInfo(videoPath);
        if (!info.Exists || info.Length <= 0) throw new IOException("File video non disponibile.");
        var pluginPath = Plugin.Instance?.DataFolderPath;
        if (string.IsNullOrWhiteSpace(pluginPath)) throw new IOException("Cartella dati del plugin non disponibile.");
        var cache = Path.Combine(pluginPath, "AdultThumbnails");
        Directory.CreateDirectory(cache);
        var identity = Path.GetFullPath(videoPath) + "|" + info.Length.ToString(CultureInfo.InvariantCulture) + "|" + info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture);
        var key = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identity))).ToLowerInvariant();
        var target = Path.Combine(cache, key + ".jpg");
        if (ValidJpeg(target)) return await File.ReadAllBytesAsync(target, cancellationToken).ConfigureAwait(false);

        await GenerationSlots.WaitAsync(cancellationToken).ConfigureAwait(false);
        try {
            if (ValidJpeg(target)) return await File.ReadAllBytesAsync(target, cancellationToken).ConfigureAwait(false);
            var ffprobe = FindTool("ffprobe");
            var ffmpeg = FindTool("ffmpeg");
            var durationText = await CaptureTextAsync(ffprobe, ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", videoPath], TimeSpan.FromSeconds(30), cancellationToken).ConfigureAwait(false);
            if (!double.TryParse(durationText.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var duration) || !double.IsFinite(duration) || duration <= 0)
                throw new IOException("Durata video non leggibile.");

            // Avoid the very beginning and end; choose a fresh random point only on the first cache generation.
            var lower = duration > 60 ? 15d : duration * 0.1d;
            var upper = duration > 60 ? duration - 10d : duration * 0.9d;
            if (upper <= lower) { lower = 0; upper = duration * 0.9d; }
            var seconds = lower + RandomNumberGenerator.GetInt32(0, 1_000_001) / 1_000_000d * Math.Max(0.05, upper - lower);
            var jpeg = await CaptureBytesAsync(ffmpeg,
                ["-hide_banner", "-loglevel", "error", "-ss", seconds.ToString("0.###", CultureInfo.InvariantCulture), "-i", videoPath,
                 "-an", "-sn", "-frames:v", "1", "-vf", "scale=640:-2", "-q:v", "4", "-f", "image2pipe", "-vcodec", "mjpeg", "pipe:1"],
                TimeSpan.FromSeconds(60), cancellationToken).ConfigureAwait(false);
            if (jpeg.Length < 4 || jpeg[0] != 0xff || jpeg[1] != 0xd8 || jpeg[^2] != 0xff || jpeg[^1] != 0xd9)
                throw new IOException("FFmpeg non ha generato un'anteprima JPEG valida.");

            var temporary = target + ".tmp-" + Guid.NewGuid().ToString("N");
            try {
                await File.WriteAllBytesAsync(temporary, jpeg, cancellationToken).ConfigureAwait(false);
                File.Move(temporary, target, true);
            } finally { if (File.Exists(temporary)) File.Delete(temporary); }
            PruneCache(cache);
            return jpeg;
        } finally { GenerationSlots.Release(); }
    }

    private static bool ValidJpeg(string path)
    {
        try {
            var info = new FileInfo(path);
            if (!info.Exists || info.Length is < 4 or > MaximumJpegBytes) return false;
            using var stream = File.OpenRead(path);
            return stream.ReadByte() == 0xff && stream.ReadByte() == 0xd8;
        } catch (IOException) { return false; }
    }

    internal static string FindTool(string name)
    {
        var executable = OperatingSystem.IsWindows() ? name + ".exe" : name;
        var candidates = new List<string>();
        var configured = Environment.GetEnvironmentVariable("JELLYFIN_FFMPEG");
        if (!string.IsNullOrWhiteSpace(configured)) {
            var full = Path.GetFullPath(configured);
            candidates.Add(Path.GetFileName(full).StartsWith("ffmpeg", StringComparison.OrdinalIgnoreCase)
                ? Path.Combine(Path.GetDirectoryName(full)!, executable) : full);
        }
        foreach (var directory in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
            candidates.Add(Path.Combine(directory, executable));
        if (!OperatingSystem.IsWindows()) {
            foreach (var directory in new[] { "/usr/lib/jellyfin-ffmpeg", "/usr/lib/jellyfin-ffmpeg7", "/usr/bin", "/usr/local/bin" })
                candidates.Add(Path.Combine(directory, executable));
        }
        var found = candidates.FirstOrDefault(File.Exists);
        return found ?? throw new IOException("FFmpeg non trovato nel container Jellyfin.");
    }

    private static async Task<string> CaptureTextAsync(string executable, IReadOnlyList<string> arguments, TimeSpan timeout, CancellationToken cancellationToken)
    {
        using var process = CreateProcess(executable, arguments);
        if (!process.Start()) throw new IOException("Impossibile avviare FFprobe.");
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(timeout);
        var stdout = process.StandardOutput.ReadToEndAsync(deadline.Token);
        var stderr = process.StandardError.ReadToEndAsync(deadline.Token);
        try { await process.WaitForExitAsync(deadline.Token).ConfigureAwait(false); }
        catch (OperationCanceledException) { Kill(process); throw new IOException("FFprobe ha superato il tempo massimo."); }
        var output = await stdout.ConfigureAwait(false);
        _ = await stderr.ConfigureAwait(false);
        if (process.ExitCode != 0) throw new IOException("FFprobe non ha letto il video.");
        return output;
    }

    internal static async Task<byte[]> CaptureBytesAsync(string executable, IReadOnlyList<string> arguments, TimeSpan timeout, CancellationToken cancellationToken)
    {
        using var process = CreateProcess(executable, arguments);
        if (!process.Start()) throw new IOException("Impossibile avviare FFmpeg.");
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(timeout);
        var output = ReadBoundedAsync(process.StandardOutput.BaseStream, MaximumJpegBytes, deadline.Token);
        var stderr = process.StandardError.ReadToEndAsync(deadline.Token);
        try { await process.WaitForExitAsync(deadline.Token).ConfigureAwait(false); }
        catch (OperationCanceledException) { Kill(process); throw new IOException("FFmpeg ha superato il tempo massimo."); }
        var bytes = await output.ConfigureAwait(false);
        _ = await stderr.ConfigureAwait(false);
        if (process.ExitCode != 0) throw new IOException("FFmpeg non ha generato l'anteprima.");
        return bytes;
    }

    private static Process CreateProcess(string executable, IReadOnlyList<string> arguments)
    {
        var start = new ProcessStartInfo { FileName = executable, UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var argument in arguments) start.ArgumentList.Add(argument);
        return new Process { StartInfo = start, EnableRaisingEvents = true };
    }

    private static async Task<byte[]> ReadBoundedAsync(Stream stream, int limit, CancellationToken cancellationToken)
    {
        using var output = new MemoryStream();
        var buffer = new byte[16 * 1024];
        while (true) {
            var read = await stream.ReadAsync(buffer, cancellationToken).ConfigureAwait(false);
            if (read == 0) break;
            if (output.Length + read > limit) throw new IOException("Anteprima oltre il limite consentito.");
            output.Write(buffer, 0, read);
        }
        return output.ToArray();
    }

    private static void Kill(Process process)
    {
        try { if (!process.HasExited) process.Kill(true); } catch (InvalidOperationException) { }
    }

    private static void PruneCache(string path)
    {
        try {
            var files = new DirectoryInfo(path).GetFiles("*.jpg").OrderByDescending(x => x.LastWriteTimeUtc).ToArray();
            long total = files.Sum(x => x.Length);
            if (total <= 512L * 1024 * 1024) return;
            foreach (var file in files.Reverse()) {
                if (total <= 384L * 1024 * 1024) break;
                total -= file.Length;
                try { file.Delete(); } catch (IOException) { }
            }
        } catch (IOException) { }
    }
}


