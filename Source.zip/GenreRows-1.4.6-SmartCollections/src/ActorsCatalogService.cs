using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Jellyfin.Data.Enums;
using Jellyfin.Database.Implementations.Enums;
using MediaBrowser.Controller.Drawing;
using MediaBrowser.Controller.Dto;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Querying;

namespace Jellyfin.Plugin.GenreRows;

public sealed record ActorCard(string Id, string Name, string? PrimaryImageTag, int MovieCount = 0,
    double Prominence = 0, string? TmdbId = null, double? Popularity = null);
public sealed record ActorCatalogPage(string Revision, ActorCard[] Items, int NextStartIndex, int TotalCount, bool Loading, bool Failed,
    string PopularityVersion = "", bool PopularityLoading = false);

/// <summary>Permission-keyed disk snapshots. Only actor IDs, names and existing Jellyfin image tags are stored.</summary>
public sealed class ActorsCache(string directory)
{
    public const int PageSize = 100;
    private readonly ConcurrentDictionary<string, Entry> entries = new();
    private sealed class Entry {
        public readonly object Gate = new();
        public string Revision = Guid.NewGuid().ToString("N");
        public ActorCard[] Items = [];
        public bool Loading = true, Failed;
        public DateTimeOffset Saved;
        public Task? Initialization;
    }
    private sealed record DiskSnapshot(string Key, string Revision, DateTimeOffset Saved, ActorCard[] Items);
    public static string Digest(string value) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value))).ToLowerInvariant();
    public ActorCard[] Snapshot(string key) {
        if (!entries.TryGetValue(key, out var entry)) return [];
        lock (entry.Gate) return entry.Items;
    }

    public async Task<ActorCatalogPage> Page(string key, int start,
        Func<Action<ActorCard[]>, Task<ActorCard[]>> build) {
        if (key.Length != 64 || !key.All(Uri.IsHexDigit)) throw new ArgumentException("Invalid cache key.");
        if (entries.Count > 64) entries.Clear(); // Disk snapshots survive memory eviction.
        var entry = entries.GetOrAdd(key, _ => new());
        Task initialization;
        lock (entry.Gate) {
            if (!entry.Loading && DateTimeOffset.UtcNow - entry.Saved > TimeSpan.FromHours(6)) {
                entry.Items = []; entry.Revision = Guid.NewGuid().ToString("N"); entry.Loading = true; entry.Failed = false; entry.Initialization = null;
            }
            initialization = entry.Initialization ??= Initialize(key, entry, build);
        }
        await initialization.ConfigureAwait(false);
        lock (entry.Gate) {
            var offset = Math.Clamp(start, 0, entry.Items.Length);
            var items = entry.Items.Skip(offset).Take(PageSize).ToArray();
            return new(entry.Revision, items, offset + items.Length, entry.Items.Length, entry.Loading, entry.Failed);
        }
    }
    private async Task Initialize(string key, Entry entry, Func<Action<ActorCard[]>, Task<ActorCard[]>> build) {
        try {
            var file = Path.Combine(directory, key + ".json");
            if (File.Exists(file) && new FileInfo(file).Length <= 16 * 1024 * 1024) {
                var saved = JsonSerializer.Deserialize<DiskSnapshot>(await File.ReadAllTextAsync(file).ConfigureAwait(false));
                if (saved?.Key == key && saved.Items is not null && saved.Items.Length <= 100000 &&
                    saved.Saved <= DateTimeOffset.UtcNow.AddMinutes(1) && DateTimeOffset.UtcNow - saved.Saved < TimeSpan.FromHours(6)) {
                    lock (entry.Gate) { entry.Items = saved.Items; entry.Revision = saved.Revision; entry.Saved = saved.Saved; entry.Loading = false; }
                    return;
                }
            }
        } catch (Exception e) when (e is IOException or UnauthorizedAccessException or JsonException) { /* Cache failure never disables browsing. */ }
        _ = Task.Run(async () => {
            try {
                var items = await build(partial => { lock (entry.Gate) entry.Items = partial; }).ConfigureAwait(false);
                var now = DateTimeOffset.UtcNow;
                lock (entry.Gate) { entry.Items = items; entry.Saved = now; entry.Loading = false; entry.Revision = Guid.NewGuid().ToString("N"); }
                try {
                    Directory.CreateDirectory(directory);
                    var file = Path.Combine(directory, key + ".json"); var temporary = file + "." + Guid.NewGuid().ToString("N") + ".tmp";
                    try { await File.WriteAllTextAsync(temporary, JsonSerializer.Serialize(new DiskSnapshot(key, entry.Revision, now, items))).ConfigureAwait(false); File.Move(temporary, file, true); }
                    finally { if (File.Exists(temporary)) File.Delete(temporary); }
                    foreach (var old in new DirectoryInfo(directory).GetFiles("*.json").OrderByDescending(x => x.LastWriteTimeUtc).Skip(128)) old.Delete();
                } catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
            } catch { lock (entry.Gate) { entry.Loading = false; entry.Failed = true; entry.Saved = DateTimeOffset.UtcNow.AddHours(-6); } }
        });
    }
}

public sealed class ActorsCatalogService : IDisposable
{
    private readonly ILibraryManager library;
    private readonly IUserManager users;
    private readonly IImageProcessor images;
    private readonly ActorsCache cache;
    private readonly ActorPopularityService popularity;
    private readonly SemaphoreSlim builds = new(2, 2);
    private readonly CancellationTokenSource stopping = new();
    private string epoch;
    private readonly string epochFile;
    private readonly object invalidationGate = new();

    public ActorsCatalogService(ILibraryManager library, IUserManager users, IImageProcessor images) {
        this.library = library; this.users = users; this.images = images;
        var root = Path.GetFullPath(Path.Combine(Plugin.Instance?.DataFolderPath ?? throw new IOException("Plugin unavailable."), "Actors"));
        cache = new ActorsCache(root); epochFile = Path.Combine(root, "epoch.txt");
        popularity = new ActorPopularityService(Path.Combine(root, "Tmdb"));
        try { epoch = File.Exists(epochFile) ? File.ReadAllText(epochFile) : "initial"; } catch (IOException) { epoch = "initial"; }
        library.ItemAdded += (_, _) => Invalidate();
        library.ItemUpdated += (_, _) => Invalidate();
        library.ItemRemoved += (_, _) => Invalidate();
    }
    public void Invalidate() {
        lock (invalidationGate) {
        var next = Guid.NewGuid().ToString("N"); Volatile.Write(ref epoch, next);
        try { Directory.CreateDirectory(Path.GetDirectoryName(epochFile)!); File.WriteAllText(epochFile, next); }
        catch (Exception e) when (e is IOException or UnauthorizedAccessException) { }
        }
    }
    private (Jellyfin.Database.Implementations.Entities.User User, CollectionFolder[] Folders, string Key) Scope(Guid userId) {
        var user = users.GetUserById(userId) ?? throw new UnauthorizedAccessException();
        var folders = library.GetUserRootFolder().GetChildren(user, true).OfType<CollectionFolder>()
            .Where(f => library.GetLibraryOptions(f).Enabled).OrderBy(f => f.Id).ToArray();
        // A cache built for another user's permissions is never reused, including after permission changes.
        var policy = users.GetUserDto(user, "").Policy;
        var key = ActorsCache.Digest("actors-v3-discover|" + userId + "|" + JsonSerializer.Serialize(policy) + "|" +
            string.Join(',', folders.Select(f => f.Id)) + "|" + Volatile.Read(ref epoch));
        return (user, folders, key);
    }
    public async Task<ActorCatalogPage> Page(Guid userId, int start) {
        var scope = Scope(userId);
        var page = await Load(scope, start).ConfigureAwait(false);
        var snapshot = cache.Snapshot(scope.Key);
        var scores = popularity.Get(snapshot.Select(p => p.TmdbId), Plugin.Instance?.Configuration.ActorsPopularityEnabled == true);
        return page with { Items = page.Items.Select(p => p with { Popularity = p.TmdbId is { } id && int.TryParse(id, out var tmdb) && scores.Values.TryGetValue(tmdb, out var value) ? value : null }).ToArray(),
            PopularityVersion = scores.Version, PopularityLoading = scores.Loading };
    }
    public async Task<ActorCard[]> AccessibleActors(Guid userId) {
        var scope = Scope(userId); await Load(scope, 0).ConfigureAwait(false); return cache.Snapshot(scope.Key);
    }
    public async Task<object?> Titles(Guid userId, Guid actorId, Guid libraryId, int start) {
        var scope = Scope(userId); await Load(scope, 0).ConfigureAwait(false);
        if (!cache.Snapshot(scope.Key).Any(p => p.Id == actorId.ToString("N"))) return null;
        var folder = scope.Folders.FirstOrDefault(f => f.Id == libraryId); if (folder is null) return null;
        var query = new InternalItemsQuery(scope.User) { ParentId = folder.Id, Recursive = true, IncludeOwnedItems = true,
            IncludeItemTypes = [BaseItemKind.Movie, BaseItemKind.Series, BaseItemKind.Episode], PersonIds = [actorId], PersonTypes = ["Actor", "GuestStar"],
            IsVirtualItem = false, IsMissing = false, EnableTotalRecordCount = false, StartIndex = Math.Max(0, start), Limit = 100,
            DtoOptions = new DtoOptions(false) { Fields = [ItemFields.Genres, ItemFields.DateCreated], ImageTypes = [ImageType.Primary], ImageTypeLimit = 1, EnableUserData = false },
            OrderBy = [(ItemSortBy.SortName, SortOrder.Ascending)] };
        library.ConfigureUserAccess(query, scope.User);
        var items = library.GetItemList(query, [folder]);
        var episodes = items.OfType<MediaBrowser.Controller.Entities.TV.Episode>().Where(e => e.SeriesId != Guid.Empty).ToArray();
        var series = items.OfType<MediaBrowser.Controller.Entities.TV.Series>().ToDictionary(s => s.Id);
        var missing = episodes.Select(e => e.SeriesId).Distinct().Where(id => !series.ContainsKey(id)).ToArray();
        InternalItemsQuery Related(BaseItemKind type, int offset, int limit, bool artwork) => new(scope.User) {
            ParentId = folder.Id, Recursive = true, IncludeOwnedItems = true, IncludeItemTypes = [type],
            IsVirtualItem = false, IsMissing = false, StartIndex = offset, Limit = limit, EnableTotalRecordCount = false,
            DtoOptions = artwork ? new DtoOptions(false) { Fields = [ItemFields.Genres, ItemFields.DateCreated], ImageTypes = [ImageType.Primary], ImageTypeLimit = 1, EnableUserData = false } : DtoOptions.StoredColumnsOnly,
            OrderBy = [(ItemSortBy.SortName, SortOrder.Ascending)] };
        IReadOnlyList<BaseItem> Read(InternalItemsQuery related) { library.ConfigureUserAccess(related, scope.User); return library.GetItemList(related, [folder]); }
        if (missing.Length > 0) {
            var parents = Related(BaseItemKind.Series, 0, 100, true); parents.ItemIds = missing;
            // Resolve posters through another authorized query, never an unfiltered GetItemById.
            foreach (var parent in Read(parents).OfType<MediaBrowser.Controller.Entities.TV.Series>()) if (missing.Contains(parent.Id)) series[parent.Id] = parent;
        }
        var available = series.Keys.ToDictionary(id => id, _ => new HashSet<int>()); var seasonsComplete = series.Count == 0;
        if (series.Count > 0) {
            // Batch all referenced series. The outer library/user scope remains in force.
            for (var offset = 0; offset < 1024; offset += 128) {
                var seasons = Related(BaseItemKind.Season, offset, 128, false); seasons.AncestorIds = series.Keys.ToArray();
                var page = Read(seasons);
                foreach (var season in page.OfType<MediaBrowser.Controller.Entities.TV.Season>()) if (available.TryGetValue(season.SeriesId, out var numbers) && season.IndexNumber is >= 0) numbers.Add(season.IndexNumber.Value);
                if (page.Count < 128) { seasonsComplete = true; break; }
            }
        }
        ActorTitleCard Card(BaseItem item, string type) {
            string? tag = null; var image = item.GetImageInfo(ImageType.Primary, 0);
            if (image is not null) try { tag = images.GetImageCacheTag(item, image); } catch (IOException) { }
            return new(item.Id.ToString("N"), item.Name, item.Genres, item.ProductionYear, item.DateCreated, item.CommunityRating, type, tag);
        }
        var result = items.OfType<MediaBrowser.Controller.Entities.Movies.Movie>().Select(item => Card(item, "Movie")).ToList();
        foreach (var parent in series.Values) {
            var credits = episodes.Where(e => e.SeriesId == parent.Id).ToArray();
            result.Add(Card(parent, "Series") with { SeasonNumbers = credits.Where(e => e.ParentIndexNumber is >= 0).Select(e => e.ParentIndexNumber!.Value).Distinct().Order().ToArray(),
                AvailableSeasonNumbers = available[parent.Id].Order().ToArray(), SeasonCoverageKnown = seasonsComplete && available[parent.Id].Count > 0, HasEpisodeCredits = credits.Length > 0 });
        }
        // Pagination follows source credits, not the much smaller number of grouped series cards.
        return new { Items = result.ToArray(), NextStartIndex = Math.Max(0, start) + items.Count, HasMore = items.Count == 100 };
    }
    private async Task<ActorCatalogPage> Load((Jellyfin.Database.Implementations.Entities.User User, CollectionFolder[] Folders, string Key) scope, int start) {
        var (user, folders, key) = scope;
        return await cache.Page(key, start, async publish => {
            await builds.WaitAsync(stopping.Token).ConfigureAwait(false);
            try {
                var found = new Dictionary<Guid, ActorCard>();
                var people = new Dictionary<string, Person?>(StringComparer.OrdinalIgnoreCase);
                var counts = new Dictionary<Guid, int>();
                var billing = new Dictionary<Guid, (double Total, int Credits)>();
                var seenItems = new HashSet<Guid>();
                const int itemBatchSize = 128;
                foreach (var folder in folders) {
                    for (var offset = 0; ; offset += itemBatchSize) {
                        stopping.Token.ThrowIfCancellationRequested();
                        // Start with real, accessible titles, never with Jellyfin's global Persons table.
                        // User restrictions (ratings, blocked tags, folders) apply before cast lookup.
                        var query = new InternalItemsQuery(user) {
                            ParentId = folder.Id, Recursive = true, IncludeOwnedItems = true,
                            IncludeItemTypes = [BaseItemKind.Movie, BaseItemKind.Series, BaseItemKind.Episode],
                            IsVirtualItem = false, IsMissing = false, EnableTotalRecordCount = false,
                            DtoOptions = DtoOptions.StoredColumnsOnly,
                            OrderBy = [(ItemSortBy.SortName, SortOrder.Ascending)],
                            StartIndex = offset, Limit = itemBatchSize
                        };
                        library.ConfigureUserAccess(query, user);
                        // This overload resolves CollectionFolder/virtual-library roots to their
                        // physical top-parent IDs before querying, as Jellyfin's Items API does.
                        var page = library.GetItemList(query, [folder]);
                        var itemIds = page.Select(item => item.Id).Where(id => id != Guid.Empty && seenItems.Add(id)).ToArray();
                        // An empty ID list must never become an unfiltered people lookup.
                        if (itemIds.Length > 0) {
                            var allowed = itemIds.ToHashSet();
                            var credits = library.GetPeopleNamesByItems(itemIds, ["Actor", "GuestStar"]);
                            var movies = page.OfType<MediaBrowser.Controller.Entities.Movies.Movie>().Select(i => i.Id).ToHashSet();
                            var titles = page.Where(i => i is MediaBrowser.Controller.Entities.Movies.Movie or MediaBrowser.Controller.Entities.TV.Series).Select(i => i.Id).ToHashSet();
                            foreach (var credit in credits.Where(pair => allowed.Contains(pair.Key))) {
                                var position = 0;
                                foreach (var name in credit.Value.Distinct(StringComparer.OrdinalIgnoreCase)) {
                                    stopping.Token.ThrowIfCancellationRequested();
                                    var rank = position++;
                                    if (string.IsNullOrWhiteSpace(name)) continue;
                                    if (!people.TryGetValue(name, out var person)) {
                                        try { person = library.GetPerson(name); }
                                        catch (Exception e) when (e is IOException or KeyNotFoundException) { person = null; }
                                        people[name] = person;
                                    }
                                    if (person is null) continue;
                                    counts.TryGetValue(person.Id, out var count);
                                    if (movies.Contains(credit.Key)) counts[person.Id] = ++count;
                                    billing.TryGetValue(person.Id, out var prominence);
                                    if (titles.Contains(credit.Key)) billing[person.Id] = prominence = (prominence.Total + 1.0 / (rank + 1), prominence.Credits + 1);
                                    if (found.TryGetValue(person.Id, out var previous)) {
                                        found[person.Id] = previous with { MovieCount = count, Prominence = prominence.Credits > 0 ? prominence.Total / prominence.Credits : 0 };
                                        continue;
                                    }
                                    string? tag = null;
                                    var image = person.GetImageInfo(ImageType.Primary, 0);
                                    if (image is not null) try { tag = images.GetImageCacheTag(person, image); } catch (IOException) { }
                                    person.ProviderIds.TryGetValue("Tmdb", out var tmdbId);
                                    found[person.Id] = new(person.Id.ToString("N"), person.Name, tag, count,
                                        prominence.Credits > 0 ? prominence.Total / prominence.Credits : 0, tmdbId);
                                    if (found.Count == 30 || found.Count % ActorsCache.PageSize == 0) publish(found.Values.ToArray());
                                }
                            }
                        }
                        // Show partial results without waiting for all titles or resolving all portraits.
                        publish(found.Values.ToArray());
                        if (page.Count < itemBatchSize) break;
                    }
                }
                return found.Values.ToArray();
            } finally { builds.Release(); }
        }).ConfigureAwait(false);
    }
    public void Dispose() { stopping.Cancel(); popularity.Dispose(); stopping.Dispose(); }
}

public sealed record ActorTitleCard(string Id, string Name, string[] Genres, int? ProductionYear, DateTime DateCreated, float? CommunityRating, string Type, string? PrimaryImageTag)
{
    public int[] SeasonNumbers { get; init; } = [];
    public int[] AvailableSeasonNumbers { get; init; } = [];
    public bool SeasonCoverageKnown { get; init; }
    public bool HasEpisodeCredits { get; init; }
}
