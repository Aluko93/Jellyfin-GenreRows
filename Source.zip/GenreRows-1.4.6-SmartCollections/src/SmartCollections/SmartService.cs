using Jellyfin.Data.Enums;
using Jellyfin.Database.Implementations.Enums;
using MediaBrowser.Controller.Drawing;
using MediaBrowser.Controller.Dto;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Querying;

namespace Jellyfin.Plugin.GenreRows.SmartCollections;

public sealed record SmartItem(string Id, string Name, int? ProductionYear, float? CommunityRating, string? PrimaryImageTag, string Type);
public sealed record SmartPage(SmartItem[] Items, int NextStartIndex, bool HasMore);

/// <summary>Read-only views over Jellyfin's indexed, user-authorized libraries. No box-set or playback writes.</summary>
public sealed class SmartService(ILibraryManager library, IUserManager users, IUserDataManager data, IImageProcessor images)
{
    private readonly SemaphoreSlim queries = new(2, 2);
    public CollectionFolder[] Folders(Guid userId, string[] selected)
    {
        var user = users.GetUserById(userId) ?? throw new UnauthorizedAccessException();
        var ids = selected.Select(Guid.Parse).ToHashSet();
        return library.GetUserRootFolder().GetChildren(user, true).OfType<CollectionFolder>()
            .Where(f => library.GetLibraryOptions(f).Enabled && (ids.Count == 0 || ids.Contains(f.Id))).ToArray();
    }
    public async Task<SmartPage> Page(Guid userId, SmartCollection definition, int start, int limit, CancellationToken cancel)
    {
        var rule = SmartValidation.Normalize(definition);
        if (start < 0 || start > 1000000 || limit is < 1 or > 100) throw new ArgumentException("Invalid pagination.");
        var user = users.GetUserById(userId) ?? throw new UnauthorizedAccessException();
        var parents = Folders(userId, rule.LibraryIds).Cast<BaseItem>().ToList();
        // An empty parents list must never turn into a global item query.
        if (parents.Count == 0) return new([], start, false);
        var people = rule.ActorIds.Select(id => library.GetItemById(Guid.Parse(id))).OfType<Person>().ToArray();
        if (people.Length != rule.ActorIds.Length) return new([], start, false);
        var names = people.Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        await queries.WaitAsync(cancel).ConfigureAwait(false);
        try {
            var output = new List<SmartItem>(); var offset = start; var more = true;
            var accounts = rule.Played == "UnplayedByAnyone" ? users.GetUsers().ToArray() : [];
            // Bound each request; the continuation cursor allows even sparse AND rules to progress.
            for (var batch = 0; batch < 5 && output.Count < limit && more; batch++) {
                cancel.ThrowIfCancellationRequested();
                var batchSize = people.Length > 1 || accounts.Length > 0 ? 128 : limit - output.Count;
                var query = new InternalItemsQuery(user) { Recursive = true, IncludeOwnedItems = true,
                    IncludeItemTypes = [Enum.Parse<BaseItemKind>(rule.MediaType)], IsVirtualItem = false, IsMissing = false,
                    SourceTypes = [SourceType.Library], EnableTotalRecordCount = false, StartIndex = offset, Limit = batchSize,
                    Genres = rule.Genre.Length > 0 ? [rule.Genre] : [], PersonIds = people.Select(p => p.Id).ToArray(), PersonTypes = people.Length > 0 ? ["Actor", "GuestStar"] : [],
                    Years = rule.MinYear.HasValue || rule.MaxYear.HasValue ? Enumerable.Range(rule.MinYear ?? 1870, (rule.MaxYear ?? 3000) - (rule.MinYear ?? 1870) + 1).ToArray() : [],
                    MinCommunityRating = rule.MinRating, AudioLanguages = rule.AudioLanguage.Length > 0 ? LanguageCodes(rule.AudioLanguage) : [], Is4K = rule.Require4K ? true : null,
                    IsPlayed = rule.Played == "Any" ? null : false,
                    // StoredColumnsOnly excludes ImageInfos: cards would receive a null cover tag.
                    // Request only the existing Primary image, without unrelated metadata/user joins.
                    DtoOptions = new DtoOptions(false) { ImageTypes = [ImageType.Primary], ImageTypeLimit = 1, EnableUserData = false },
                    OrderBy = [(rule.SortBy switch { "Title" => ItemSortBy.SortName, "Year" => ItemSortBy.ProductionYear, "Rating" => ItemSortBy.CommunityRating, _ => ItemSortBy.DateCreated }, rule.SortBy == "Title" ? SortOrder.Ascending : SortOrder.Descending), (ItemSortBy.SortName, SortOrder.Ascending)] };
                library.ConfigureUserAccess(query, user);
                var items = library.GetItemList(query, parents);
                if (items.Count == 0) { more = false; break; }
                var allowedIds = items.Select(i => i.Id).ToHashSet();
                var credits = people.Length > 1 && items.Count > 0 ? library.GetPeopleNamesByItems(items.Select(i => i.Id).ToArray(), ["Actor", "GuestStar"]) : null;
                var played = new HashSet<Guid>();
                foreach (var account in accounts) {
                    cancel.ThrowIfCancellationRequested();
                    foreach (var pair in data.GetUserDataBatch(items, account)) if (allowedIds.Contains(pair.Key) && (pair.Value.Played || pair.Value.PlayCount > 0)) played.Add(pair.Key);
                }
                var consumed = 0;
                foreach (var item in items) {
                    cancel.ThrowIfCancellationRequested(); consumed++;
                    if (played.Contains(item.Id) || credits is not null && (!credits.TryGetValue(item.Id, out var cast) || !names.IsSubsetOf(cast.ToHashSet(StringComparer.OrdinalIgnoreCase)))) continue;
                    string? tag = null; var image = item.GetImageInfo(ImageType.Primary, 0);
                    if (image is not null) try { tag = images.GetImageCacheTag(item, image); } catch (IOException) { }
                    output.Add(new(item.Id.ToString("N"), item.Name, item.ProductionYear, item.CommunityRating, tag, rule.MediaType));
                    if (output.Count == limit) break;
                }
                offset += consumed;
                more = consumed < items.Count || items.Count == batchSize;
            }
            return new(output.ToArray(), offset, more);
        } finally { queries.Release(); }
    }
    public static string[] LanguageCodes(string code) => code switch { "fra" or "fre" => ["fra", "fre"], "deu" or "ger" => ["deu", "ger"], _ => [code] };
}
