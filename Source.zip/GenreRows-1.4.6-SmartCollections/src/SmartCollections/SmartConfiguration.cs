namespace Jellyfin.Plugin.GenreRows.SmartCollections;

public sealed class SmartConfiguration
{
    public bool Enabled { get; set; }
    public SmartCollection[] Collections { get; set; } = [];
}

public sealed class SmartCollection
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public string MediaType { get; set; } = "Movie";
    public string[] LibraryIds { get; set; } = [];
    public string[] ActorIds { get; set; } = [];
    public string Genre { get; set; } = "";
    public int? MinYear { get; set; }
    public int? MaxYear { get; set; }
    public double? MinRating { get; set; }
    public string Played { get; set; } = "Any";
    public string AudioLanguage { get; set; } = "";
    public bool Require4K { get; set; }
    public string SortBy { get; set; } = "Recent";
    public int Limit { get; set; } = 20;
}

public static class SmartValidation
{
    public static SmartConfiguration Normalize(SmartConfiguration input)
    {
        if (input.Collections is null || input.Collections.Length > 20) throw new ArgumentException("At most 20 collections are allowed.");
        var rules = input.Collections.Select(Normalize).ToArray();
        if (rules.Select(r => r.Id).Distinct().Count() != rules.Length) throw new ArgumentException("Collection IDs must be unique.");
        return new() { Enabled = input.Enabled, Collections = rules };
    }
    public static SmartCollection Normalize(SmartCollection rule)
    {
        if (rule is null || string.IsNullOrWhiteSpace(rule.Name) || rule.Name.Trim().Length > 80) throw new ArgumentException("Enter a collection name (1–80 characters).");
        if (rule.MediaType is not ("Movie" or "Series" or "Episode") || rule.Played is not ("Any" or "UnplayedByMe" or "UnplayedByAnyone") || rule.SortBy is not ("Recent" or "Title" or "Year" or "Rating")) throw new ArgumentException("Invalid collection option.");
        if (rule.MinYear is < 1870 or > 3000 || rule.MaxYear is < 1870 or > 3000 || rule.MinYear > rule.MaxYear || rule.MinRating is { } rating && (!double.IsFinite(rating) || rating < 0 || rating > 10) || rule.Limit is < 1 or > 60) throw new ArgumentException("Invalid year, rating or row length.");
        var audio = (rule.AudioLanguage ?? "").Trim().ToLowerInvariant();
        audio = audio switch { "it" => "ita", "en" => "eng", "fr" => "fra", "de" => "deu", "es" => "spa", "pt" => "por", _ => audio };
        if (audio.Length > 0 && (audio.Length != 3 || audio.Any(c => c is < 'a' or > 'z'))) throw new ArgumentException("Use a three-letter audio language code.");
        if (rule.MediaType == "Series" && (rule.Require4K || audio.Length > 0)) throw new ArgumentException("Audio and 4K filters require movies or episodes, not series folders.");
        var genre = (rule.Genre ?? "").Trim(); if (genre.Length > 120) throw new ArgumentException("Genre is too long.");
        return new() { Id = string.IsNullOrEmpty(rule.Id) ? Guid.NewGuid().ToString("N") : Id(rule.Id), Name = rule.Name.Trim(), Enabled = rule.Enabled,
            MediaType = rule.MediaType, LibraryIds = Ids(rule.LibraryIds, 64), ActorIds = Ids(rule.ActorIds, 8), Genre = genre,
            MinYear = rule.MinYear, MaxYear = rule.MaxYear, MinRating = rule.MinRating, Played = rule.Played,
            AudioLanguage = audio, Require4K = rule.Require4K, SortBy = rule.SortBy, Limit = rule.Limit };
    }
    private static string Id(string value) => Guid.TryParse(value, out var id) && id != Guid.Empty ? id.ToString("N") : throw new ArgumentException("Invalid identifier.");
    private static string[] Ids(string[]? values, int max) => values is null || values.Length > max ? throw new ArgumentException("Too many identifiers.") : values.Select(Id).Distinct().ToArray();
}

internal static class SmartResources
{
    internal static readonly string Script = Read("strings.js") + "\n" + Read("smart.js");
    internal static readonly string Strings = Read("strings.js");
    private static string Read(string name) {
        using var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.SmartCollections.Web." + name)!;
        using var reader = new StreamReader(stream); return reader.ReadToEnd();
    }
}
