using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Jellyfin.Plugin.GenreRows.SmartCollections;

[ApiController, Authorize, Route("GenreRows/SmartCollections")]
[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public sealed class SmartController(SmartService service) : ControllerBase
{
    private Guid UserId => Guid.TryParse(User.FindFirst("Jellyfin-UserId")?.Value, out var id) ? id : Guid.Empty;
    private SmartConfiguration Settings => Plugin.Instance?.Configuration.SmartCollections ?? new();
    [HttpGet("strings.js"), AllowAnonymous]
    public ContentResult Strings() => Content(SmartResources.Strings, "application/javascript; charset=utf-8");
    [HttpGet("Status")]
    public object Status() => new { Settings.Enabled };
    [HttpGet("Catalog")]
    public IActionResult Catalog() {
        if (!Settings.Enabled) return Forbid();
        if (UserId == Guid.Empty) return Unauthorized();
        try { return Ok(new { Collections = Settings.Collections.Where(r => r.Enabled && service.Folders(UserId, r.LibraryIds).Length > 0).Select(r => new { r.Id, r.Name, r.Limit }) }); }
        catch (UnauthorizedAccessException) { return Forbid(); }
    }
    [HttpGet("Items/{id:guid}")]
    public async Task<IActionResult> Items(Guid id, int startIndex = 0, int limit = 20) {
        if (!Settings.Enabled) return Forbid();
        var rule = Settings.Collections.FirstOrDefault(r => r.Enabled && r.Id == id.ToString("N"));
        if (rule is null) return NotFound();
        try { return Ok(await service.Page(UserId, rule, startIndex, limit, HttpContext.RequestAborted)); }
        catch (ArgumentException) { return BadRequest(); }
        catch (UnauthorizedAccessException) { return Forbid(); }
    }
    [HttpGet("Configuration"), Authorize(Policy = "RequiresElevation")]
    public async Task<object> Configuration([FromServices] ActorsCatalogService actors) {
        var ids = Settings.Collections.SelectMany(r => r.ActorIds).ToHashSet();
        var labels = ids.Count > 0 ? (await actors.AccessibleActors(UserId)).Where(p => ids.Contains(p.Id)).ToDictionary(p => p.Id, p => p.Name) : new Dictionary<string, string>();
        return new { Settings.Enabled, Settings.Collections, ActorNames = labels };
    }
    [HttpPost("Configuration"), Authorize(Policy = "RequiresElevation"), RequestSizeLimit(65536)]
    public IActionResult Configure(SmartConfiguration input) {
        if (Plugin.Instance is not { } plugin) return StatusCode(503);
        try { var normalized = SmartValidation.Normalize(input); plugin.Configuration.SmartCollections = normalized; plugin.SaveConfiguration(); return NoContent(); }
        catch (ArgumentException e) { return BadRequest(new { Error = e.Message }); }
    }
    [HttpPost("Preview"), Authorize(Policy = "RequiresElevation"), RequestSizeLimit(8192)]
    public async Task<IActionResult> Preview(SmartCollection rule) {
        try { return Ok(await service.Page(UserId, rule, 0, 10, HttpContext.RequestAborted)); }
        catch (ArgumentException e) { return BadRequest(new { Error = e.Message }); }
        catch (UnauthorizedAccessException) { return Forbid(); }
    }
    [HttpGet("Actors"), Authorize(Policy = "RequiresElevation")]
    public async Task<IActionResult> Actors([FromServices] ActorsCatalogService actors, string searchTerm = "") {
        if (UserId == Guid.Empty) return Unauthorized();
        var term = searchTerm.Trim(); if (term.Length is < 2 or > 80) return BadRequest();
        var list = await actors.AccessibleActors(UserId);
        return Ok(new { Items = list.Where(p => p.Name.Contains(term, StringComparison.OrdinalIgnoreCase)).OrderBy(p => p.Name).Take(20).Select(p => new { p.Id, p.Name }) });
    }
}
