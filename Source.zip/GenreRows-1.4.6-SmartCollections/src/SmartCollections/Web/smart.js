(() => {
    'use strict';
    if(window.__genreRowsSmart)return;window.__genreRowsSmart=true;
    const t=window.GenreRowsSmartText,el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
    const style=el('style');style.textContent=`
    .grs-home{margin:2em 3.3%;color:inherit}.grs-row{margin-bottom:1.7em;min-width:0}.grs-header{display:flex;align-items:center;gap:.6em}.grs-heading{flex:1;text-align:left;font-size:1.3em!important;border:0!important;background:transparent!important;padding:.5em 0!important}
    .grs-home button,.grs-page button{font:inherit;color:inherit;border:1px solid #666;background:var(--input-background-color,#252525);border-radius:.35em;padding:.6em;cursor:pointer}.grs-home button:focus,.grs-page button:focus,.grs-card:focus{outline:2px solid var(--accent,#00a4dc);outline-offset:3px}
    .grs-track{display:flex;gap:1em;overflow-x:auto;padding:.4em .2em 1em;scroll-snap-type:x proximity}.grs-home .grs-card{display:block;flex:0 0 clamp(125px,13vw,190px);width:clamp(125px,13vw,190px);max-width:clamp(125px,13vw,190px);min-width:0;box-sizing:border-box;color:inherit;text-decoration:none;scroll-snap-align:start}
    .grs-card{display:block;color:inherit;text-decoration:none;min-width:0}.grs-poster{display:block;position:relative;width:100%;height:0;padding-bottom:150%;box-sizing:content-box;background:#252525;border-radius:.4em;overflow:hidden}.grs-poster img{position:absolute;inset:0;display:block;width:100%;height:100%;min-width:0;max-width:100%;max-height:100%;object-fit:cover}.grs-name{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:.45em 0 .25em}.grs-card small{opacity:.65}.grs-message{opacity:.7}
    .grs-page{position:fixed;inset:0;z-index:9500;background:var(--theme-background-color,#111);color:var(--theme-text-color,#eee);overflow:auto;padding:1.5em max(1em,3.3vw);box-sizing:border-box}.grs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(125px,1fr));gap:1.2em;margin:1.5em 0}.grs-grid .grs-card{width:100%}.grs-home [hidden],.grs-page [hidden]{display:none!important}
    `;document.head.append(style);
    let root,identity='',generation=0,nextCheck=0,timer,detachTV,detachFast,artwork,dialog,detachDialog,previousOverflow,backFocus;
    function imageLoader(){
        const pending=new Map(),active=new Map();let disposed=false;
        const near=image=>{const r=image.getBoundingClientRect();return r.width>0&&r.height>0&&r.right>-100&&r.left<innerWidth+100&&r.bottom>-100&&r.top<innerHeight+100;};
        function pump(){
            if(disposed)return;
            for(const [image,url]of pending){
                if(active.size>=4)break;if(!image.isConnected||image.dataset.source!==url){pending.delete(image);continue;}if(!near(image))continue;
                pending.delete(image);observer?.unobserve(image);
                const job={done:false,finish:()=>{if(job.done)return;job.done=true;image.removeEventListener('load',job.finish);image.removeEventListener('error',job.finish);active.delete(image);pump();}};
                active.set(image,job);image.addEventListener('load',job.finish);image.addEventListener('error',job.finish);image.src=url;
            }
        }
        const observer='IntersectionObserver'in window?new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting&&entry.target.dataset.source)pending.set(entry.target,entry.target.dataset.source);else pending.delete(entry.target);pump();},{rootMargin:'100px'}):null;
        function remove(image){pending.delete(image);observer?.unobserve(image);const job=active.get(image);if(job){image.removeAttribute('src');job.finish();}}
        const fallback=()=>pump();if(!observer)window.addEventListener('scroll',fallback,true);
        return{
            set(image,url){remove(image);image.dataset.source=url;if(!url){image.removeAttribute('src');return;}if(observer)observer.observe(image);else{pending.set(image,url);queueMicrotask(pump);}},
            remove,
            dispose(){disposed=true;observer?.disconnect();pending.clear();for(const [image,job]of active){image.removeAttribute('src');job.finish();}window.removeEventListener('scroll',fallback,true);}
        };
    }
    function fastHorizontal(scope){
        const handler=e=>{
            const key=e.key&&e.key!=='Unidentified'?e.key:({37:'ArrowLeft',39:'ArrowRight'})[e.keyCode];if(!['ArrowLeft','ArrowRight','Left','Right'].includes(key))return;
            const current=document.activeElement;if(!scope.contains(current)||!current.matches('.grs-track > .grs-card'))return;
            const forward=key==='ArrowRight'||key==='Right',next=forward?current.nextElementSibling:current.previousElementSibling;
            if(next?.matches('.grs-card')){e.preventDefault();e.stopImmediatePropagation();window.GenreRowsTV.focus(next);}
        };
        window.addEventListener('keydown',handler,true);return()=>window.removeEventListener('keydown',handler,true);
    }
    function close(){if(!dialog)return;detachDialog?.();for(const image of dialog.querySelectorAll('img'))artwork?.remove(image);dialog.remove();dialog=null;document.body.style.overflow=previousOverflow;if(backFocus?.isConnected)window.GenreRowsTV.focus(backFocus);}
    function reset(){generation++;clearTimeout(timer);artwork?.dispose();close();detachFast?.();detachTV?.();artwork=null;root?.remove();root=null;identity='';}
    function place(host){
        const tail=[root,host.querySelector(':scope > .gr-actors'),host.querySelector(':scope > .gra-home')].filter(Boolean),current=[...host.children].slice(-tail.length);
        // Keep the three optional modules after the genre rows, in this order, regardless of async arrival.
        if(tail.some((node,index)=>current[index]!==node))for(const node of tail)host.append(node);
    }
    function card(api,item){const a=el('a',undefined,'grs-card focusable'),frame=el('span',undefined,'grs-poster'),image=el('img');a.dataset.id=item.Id;a.href='#/details?id='+encodeURIComponent(item.Id)+'&serverId='+encodeURIComponent(api.serverId());image.alt='';image.loading='lazy';image.decoding='async';frame.append(image);a.append(frame,el('span',undefined,'grs-name'),el('small'));return a;}
    function sync(api,container,items){
        const existing=new Map([...container.children].map(n=>[n.dataset.id,n])),wanted=new Set(items.map(i=>i.Id));
        for(const [id,node] of existing)if(!wanted.has(id)){artwork?.remove(node.querySelector('img'));node.remove();}
        for(const [index,item] of items.entries()){
            const node=existing.get(item.Id)||card(api,item),name=node.querySelector('.grs-name'),small=node.querySelector('small'),image=node.querySelector('img');
            if(name.textContent!==item.Name){name.textContent=item.Name;node.title=item.Name;}
            const info=[item.ProductionYear,item.CommunityRating==null?'':'★ '+Number(item.CommunityRating).toFixed(1)].filter(Boolean).join(' · ');if(small.textContent!==info)small.textContent=info;
            const url=item.PrimaryImageTag?api.getImageUrl(item.Id,{type:'Primary',tag:item.PrimaryImageTag,maxWidth:380}):'';
            if(image.dataset.source!==url)artwork.set(image,url);
            if(container.children[index]!==node)container.insertBefore(node,container.children[index]||null);
        }
    }
    async function check(){
        const api=window.ApiClient,user=api?.getCurrentUserId?.(),token=user&&api.accessToken?.(),host=[...document.querySelectorAll('#homeTab')].find(n=>n.getClientRects().length),id=user&&token?api.serverAddress()+'|'+user+'|'+token:'';
        if(!host||!id){reset();return;}if(identity&&identity!==id){reset();nextCheck=0;}if(root?.isConnected&&identity===id){place(host);return;}if(Date.now()<nextCheck)return;
        reset();identity=id;nextCheck=Date.now()+15000;const run=generation,valid=()=>generation===run&&identity===id&&host.isConnected&&window.ApiClient===api&&api.getCurrentUserId()===user&&api.accessToken()===token,get=window.GenreRowsCore.requester(api);
        try{
            const status=await get('GenreRows/SmartCollections/Status');if(!valid()||!status.Enabled)return;
            const catalog=await get('GenreRows/SmartCollections/Catalog');if(!valid()||!catalog.Collections?.length)return;
            root=el('section',undefined,'grs-home');root.append(el('h2',t.title));place(host);
            artwork=imageLoader();detachFast=fastHorizontal(root);detachTV=window.GenreRowsTV.attach(root);const rows=[],signature=JSON.stringify(catalog.Collections||[]);let firstRefresh=true;
            for(const definition of catalog.Collections||[]){
                const section=el('section',undefined,'grs-row'),header=el('div',undefined,'grs-header'),heading=el('button',definition.Name,'grs-heading'),refresh=el('button','↻'),track=el('div',undefined,'grs-track'),message=el('p',t.waiting,'grs-message');
                section.dataset.id=definition.Id;heading.type=refresh.type='button';heading.setAttribute('aria-label',t.details+': '+definition.Name);refresh.setAttribute('aria-label',t.reload+': '+definition.Name);
                const state={definition,section,track,message,busy:false};heading.onclick=()=>void open(state);refresh.onclick=()=>void loadRow(state);
                header.append(heading,refresh);for(const [sign,glyph]of[[-1,'‹'],[1,'›']]){const arrow=el('button',glyph);arrow.type='button';arrow.setAttribute('aria-label',(sign<0?t.back:t.more)+': '+definition.Name);arrow.onclick=()=>track.scrollBy({left:sign*track.clientWidth*.85,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});header.append(arrow);}
                section.append(header,message,track);root.append(section);rows.push(state);
            }
            async function loadRow(state){
                if(state.busy||!valid())return;state.busy=true;const matches=new Map(),initial=state.track.children.length===0;let start=0;
                try{do{
                    const count=Math.max(1,Math.min(12,state.definition.Limit-matches.size));
                    const page=await get('GenreRows/SmartCollections/Items/'+state.definition.Id,{StartIndex:start,Limit:count});if(!valid())return;
                    for(const item of page.Items||[])matches.set(item.Id,item);
                    const done=!page.HasMore||page.NextStartIndex<=start||matches.size>=state.definition.Limit;
                    if(initial&&matches.size||done)sync(api,state.track,[...matches.values()].slice(0,state.definition.Limit));state.message.textContent=matches.size?'':page.HasMore?t.waiting:t.empty;
                    if(done)break;
                    start=page.NextStartIndex;await new Promise(r=>setTimeout(r,120));
                }while(valid()&&!document.hidden);
                }catch(_){if(valid())state.message.textContent=t.error;}finally{state.busy=false;}
            }
            async function refreshAll(){
                if(!valid())return;if(document.hidden){timer=setTimeout(()=>void refreshAll(),15000);return;}
                if(!firstRefresh){try{const status=await get('GenreRows/SmartCollections/Status');if(!valid())return;if(!status.Enabled){reset();nextCheck=Date.now()+15000;return;}const updated=await get('GenreRows/SmartCollections/Catalog');if(!valid())return;if(JSON.stringify(updated.Collections||[])!==signature){reset();nextCheck=0;void check();return;}}catch(_){/* Keep the existing rows during a temporary connection failure. */}}
                firstRefresh=false;let cursor=0;async function worker(){while(valid()&&cursor<rows.length)await loadRow(rows[cursor++]);}await Promise.all([worker(),worker()]);if(valid())timer=setTimeout(()=>void refreshAll(),60000);
            }
            async function open(state){
                if(!valid())return;close();backFocus=document.activeElement;previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
                const page=el('section',undefined,'grs-page'),back=el('button','← '+t.back),grid=el('div',undefined,'grs-grid'),message=el('p',t.waiting,'grs-message'),more=el('button',t.more);dialog=page;page.setAttribute('role','dialog');page.setAttribute('aria-modal','true');page.setAttribute('aria-label',state.definition.Name);back.type=more.type='button';back.onclick=close;more.hidden=true;
                page.append(back,el('h1',state.definition.Name),message,grid,more);document.body.append(page);detachDialog=window.GenreRowsTV.attach(page,{trap:true,onBack:close});window.GenreRowsTV.focus(back);
                const live=()=>valid()&&dialog===page,all=new Map();let offset=0,busy=false;
                page.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const controls=[...page.querySelectorAll('button,a')].filter(n=>!n.hidden&&!n.disabled&&n.getClientRects().length);if(document.activeElement===(e.shiftKey?controls[0]:controls.at(-1))){e.preventDefault();window.GenreRowsTV.focus(e.shiftKey?controls.at(-1):controls[0]);}});
                async function load(){if(busy||!live())return;const restore=document.activeElement===more;busy=true;more.disabled=true;try{
                    const result=await get('GenreRows/SmartCollections/Items/'+state.definition.Id,{StartIndex:offset,Limit:100});if(!live())return;
                    for(const item of result.Items||[])all.set(item.Id,item);sync(api,grid,[...all.values()]);message.textContent=all.size?all.size+' '+t.matches:result.HasMore?t.waiting:t.empty;
                    more.hidden=!result.HasMore||result.NextStartIndex<=offset;offset=result.NextStartIndex;
                }catch(_){if(live())message.textContent=t.error;}finally{busy=false;more.disabled=false;if(live()&&restore&&document.activeElement===document.body)window.GenreRowsTV.focus(more.hidden?(grid.lastElementChild||back):more);}}
                more.onclick=()=>void load();await load();
            }
            void refreshAll();
        }catch(_){if(valid())reset();}
    }
    window.addEventListener('genreRowsSmartChanged',()=>{reset();nextCheck=0;void check();});window.addEventListener('hashchange',()=>{reset();nextCheck=0;void check();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)void check();});setInterval(()=>{if(!document.hidden)void check();},1500);void check();
})();
