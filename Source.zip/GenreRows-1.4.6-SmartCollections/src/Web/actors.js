/* ActorFlix uses only the current user's accessible Jellyfin titles and cached person records. */
(() => {
    'use strict';
    if (window.__genreRowsActors) return;
    window.__genreRowsActors = true;
    const lang=(document.documentElement.lang||navigator.language||'en').split('-')[0];
    const words={
        it:['Attori','Cerca attore','A–Z','Z–A','Caricamento…','Nessun risultato','Indietro','Impossibile caricare. Riprova.','Mostra altri','Preferiti','Tutti i generi','Tutti gli anni','Titoli nella tua libreria','Ultimi film aggiunti','Più recenti','Genere','Anno','Aggiungi ai preferiti','Rimuovi dai preferiti','Biografia non disponibile','Mostra di più','Mostra meno','Informazioni','Discover · libreria','Discover · TMDB e libreria','Popolarità in aggiornamento'],
        en:['Actors','Search actors','A–Z','Z–A','Loading…','No results','Back','Could not load. Retry.','Show more','Favorites','All genres','All years','Titles in your library','Recently added movies','Recently added','Genre','Year','Add to favorites','Remove from favorites','Biography unavailable','Read more','Read less','About','Discover · library','Discover · TMDB and library','Updating popularity'],
        fr:['Acteurs','Rechercher un acteur','A–Z','Z–A','Chargement…','Aucun résultat','Retour','Chargement impossible. Réessayez.','Afficher plus','Favoris','Tous les genres','Toutes les années','Titres de votre bibliothèque','Films récemment ajoutés','Plus récents','Genre','Année','Ajouter aux favoris','Retirer des favoris','Biographie indisponible','Lire la suite','Réduire','À propos','Discover · bibliothèque','Discover · TMDB et bibliothèque','Actualisation de la popularité'],
        de:['Darsteller','Darsteller suchen','A–Z','Z–A','Laden…','Keine Ergebnisse','Zurück','Laden fehlgeschlagen. Erneut versuchen.','Mehr anzeigen','Favoriten','Alle Genres','Alle Jahre','Titel in deiner Bibliothek','Zuletzt hinzugefügte Filme','Neueste zuerst','Genre','Jahr','Zu Favoriten hinzufügen','Aus Favoriten entfernen','Keine Biografie verfügbar','Mehr lesen','Weniger lesen','Info','Discover · Bibliothek','Discover · TMDB und Bibliothek','Popularität wird aktualisiert'],
        es:['Actores','Buscar actor','A–Z','Z–A','Cargando…','Sin resultados','Atrás','No se pudo cargar. Reintenta.','Mostrar más','Favoritos','Todos los géneros','Todos los años','Títulos en tu biblioteca','Películas añadidas recientemente','Más recientes','Género','Año','Añadir a favoritos','Quitar de favoritos','Biografía no disponible','Leer más','Leer menos','Acerca de','Discover · biblioteca','Discover · TMDB y biblioteca','Actualizando popularidad'],
        pt:['Atores','Pesquisar ator','A–Z','Z–A','Carregando…','Sem resultados','Voltar','Não foi possível carregar. Tente novamente.','Mostrar mais','Favoritos','Todos os gêneros','Todos os anos','Títulos na sua biblioteca','Filmes adicionados recentemente','Mais recentes','Gênero','Ano','Adicionar aos favoritos','Remover dos favoritos','Biografia indisponível','Ler mais','Ler menos','Sobre','Discover · biblioteca','Discover · TMDB e biblioteca','Atualizando popularidade']
    };
    const extra={it:['Titolo','Anno: più recenti','Anno: meno recenti','Valutazione'],en:['Title','Year: newest','Year: oldest','Rating'],fr:['Titre','Année : récents','Année : anciens','Note'],de:['Titel','Jahr: neueste','Jahr: älteste','Bewertung'],es:['Título','Año: recientes','Año: antiguos','Valoración'],pt:['Título','Ano: recentes','Ano: antigos','Avaliação']};
    const television=({it:['Film','Serie TV','Stagione','Stagioni','Speciali'],en:['Movies','TV series','Season','Seasons','Specials'],fr:['Films','Séries TV','Saison','Saisons','Épisodes spéciaux'],de:['Filme','Serien','Staffel','Staffeln','Extras'],es:['Películas','Series de TV','Temporada','Temporadas','Especiales'],pt:['Filmes','Séries de TV','Temporada','Temporadas','Especiais']})[lang]||['Movies','TV series','Season','Seasons','Specials'];
    const t=i=>(words[lang]||words.en)[i],label=i=>(extra[lang]||extra.en)[i];
    const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
    const style=el('style');
    style.textContent=`
    .gr-actors{margin:2em 3.3%;color:inherit}.gr-actors-toolbar,.gr-actor-filters{display:flex;gap:.8em;align-items:center;flex-wrap:wrap}
    .gr-actors button,.gr-actors select,.gr-actor-page button,.gr-actor-page select{font:inherit;color:inherit;background:var(--input-background-color,#252525);border:1px solid #666;border-radius:.35em;padding:.65em;cursor:pointer}
    .gr-actors input{font:inherit;padding:.65em;color:inherit;background:#252525;border:1px solid #666;border-radius:.35em}.gr-actors-track{display:flex;gap:1.15em;overflow-x:auto;padding:1.6em .6em;scroll-snap-type:x proximity}
    .gr-actors .gr-person{position:relative;display:flex;align-items:center;justify-content:center;flex:0 0 195px;width:195px;min-height:293px;padding:0;border:0;border-radius:.6em;background:transparent;color:inherit;scroll-snap-align:start;outline:none}
    .gr-person-frame{display:block;position:relative;flex-shrink:0;width:156px;border:0;outline:0;border-radius:.65em;overflow:hidden;background:#252525;transition:transform .25s ease,box-shadow .25s ease;box-shadow:0 2px 7px #0007}
    .gr-person img{display:block;width:100%;height:234px;object-fit:cover}.gr-person-name{position:absolute;inset:auto 0 0;padding:2.8em .5em .7em;color:white;font-size:.95em;font-weight:600;text-align:center;background:linear-gradient(transparent,rgba(0,0,0,.92));white-space:normal}
    .gr-person[data-id]::after{content:'';pointer-events:none;position:absolute;bottom:-.4em;left:18%;right:18%;height:15px;border-radius:50%;background:var(--accent,var(--primary-color,#00a4dc));filter:blur(13px);opacity:0;transition:opacity .25s ease}
    .gr-person[data-id]:hover .gr-person-frame,.gr-person[data-id]:focus .gr-person-frame{transform:scale(1.25);box-shadow:0 3px 14px #0009}
    .gr-person[data-id]:hover::after,.gr-person[data-id]:focus::after{opacity:.8}
    .gr-person-heart{position:absolute;right:.45em;top:.35em;color:#fff;text-shadow:0 1px 4px #000;font-size:1.3em}.gr-actors .gr-actors-more{min-height:234px;border:1px solid #666}.gr-actors [hidden],.gr-actor-page [hidden]{display:none!important}
    .gr-discover-note{opacity:.65;font-size:.9em;margin:.6em 0 0}.gr-actor-page{position:fixed;inset:0;z-index:9500;background:var(--theme-background-color,#111);color:var(--theme-text-color,#eee);overflow:auto;padding:1.5em max(1em,4vw);box-sizing:border-box}
    .gr-actor-page:focus{outline:none}.gr-actor-profile{display:grid;grid-template-columns:minmax(130px,210px) 1fr;gap:1.8em;max-width:1200px;margin:1.6em 0 2em}.gr-actor-photo{width:100%;aspect-ratio:2/3;object-fit:cover;border-radius:.5em;background:#252525}
    .gr-actor-profile h1{margin:.1em 0 .5em}.gr-actor-biography{max-width:900px;white-space:pre-line;line-height:1.5}.gr-actor-biography.gr-collapsed{display:-webkit-box;-webkit-line-clamp:5;-webkit-box-orient:vertical;overflow:hidden}
    .gr-actor-page [aria-pressed=true],.gr-actors [aria-pressed=true]{border-color:var(--accent,#00a4dc);color:var(--accent,#00a4dc)}
    .gr-actor-items{display:grid;grid-template-columns:repeat(auto-fill,minmax(145px,1fr));gap:1.2em;margin:1.3em 0 2em}.gr-actor-item{display:block;color:inherit;text-decoration:none;min-width:0;max-width:240px;border-radius:.4em}
    .gr-actor-item img{display:block;width:100%;aspect-ratio:2/3;object-fit:cover;border-radius:.4em;background:#252525}.gr-actor-item span{display:block;margin:.4em 0;overflow-wrap:anywhere}.gr-actor-item small{display:block;opacity:.65;line-height:1.4}.gr-actor-recent{display:flex;overflow-x:auto;gap:1em;padding:.6em .2em 1em}.gr-actor-recent .gr-actor-item{flex:0 0 140px}
    .gr-actor-page button:focus,.gr-actor-page select:focus,.gr-actor-item:focus,.gr-actors-toolbar button:focus,.gr-actors-toolbar select:focus{outline:2px solid var(--accent,#00a4dc);outline-offset:3px}
    .gr-actor-about{font-size:.85em;opacity:.75;margin:1em 0;max-width:800px}.gr-actor-about img{width:90px;height:auto;display:block;margin:.7em 0}.gr-actor-about a{color:inherit}
    @media(max-width:600px){.gr-actors .gr-person{width:165px;flex-basis:165px;min-height:248px}.gr-person-frame{width:132px}.gr-person img{height:198px}.gr-actor-profile{grid-template-columns:110px 1fr;gap:1em}.gr-actor-profile h1{font-size:1.5em}.gr-actor-biography{grid-column:1/-1}.gr-actor-items{grid-template-columns:repeat(auto-fill,minmax(120px,1fr))}}
    @media(prefers-reduced-motion:reduce){.gr-person-frame,.gr-person::after{transition:none!important}}
    `;
    document.head.append(style);
    function variation(id,seed){let h=2166136261;for(const c of seed+'|'+id){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return(h>>>0)/4294967295;}
    function discover(list,seed){
        const maxPopularity=list.reduce((max,p)=>Math.max(max,Number(p.Popularity)||0),0),maxCount=list.reduce((max,p)=>Math.max(max,Number(p.MovieCount)||0),1);
        const score=p=>{
            const library=Math.log1p(Number(p.MovieCount)||0)/Math.log1p(maxCount);
            const fame=maxPopularity>0?Math.log1p(Math.max(0,Number(p.Popularity)||0))/Math.log1p(maxPopularity):.6*library+.4*Math.max(0,Math.min(1,Number(p.Prominence)||0));
            return .7*fame+.2*library+.1*variation(p.Id,seed);
        };
        return list.map(p=>({person:p,score:score(p)})).sort((a,b)=>b.score-a.score||a.person.Name.localeCompare(b.person.Name)).map(p=>p.person);
    }
    // Pure ranking helper also allows regression tests without a running Jellyfin server.
    window.GenreRowsActorFlix={discover};
    let identity='',root,epoch=0,nextCheck=0,detachTV,portraitObserver,refreshTimer,profile,detachProfile,returnFocus,returnId,previousOverflow;
    function closeProfile(){if(!profile)return;detachProfile?.();profile.remove();profile=null;document.body.style.overflow=previousOverflow;const cards=[...(root?.querySelectorAll('.gr-person[data-id]')||[])],target=cards.find(n=>n.dataset.id===returnId)||(returnFocus?.isConnected&&returnFocus.matches('button,a,select')?returnFocus:null)||cards[0]||root?.querySelector('.gr-actors-toolbar button');if(target)window.GenreRowsTV.focus(target);}
    function reset(){epoch++;clearTimeout(refreshTimer);portraitObserver?.disconnect();detachTV?.();detachTV=null;closeProfile();root?.remove();root=null;identity='';}
    async function check(){
        const api=window.ApiClient,user=api?.getCurrentUserId?.(),key=user&&api.accessToken?.(),host=[...document.querySelectorAll('#homeTab')].find(n=>n.getClientRects().length);
        const id=user&&key?api.serverAddress()+'|'+user+'|'+key:'';
        if(!host||!id){reset();return;}if(identity&&identity!==id){reset();nextCheck=0;}if(root?.isConnected&&identity===id)return;if(Date.now()<nextCheck)return;
        reset();identity=id;const run=epoch;nextCheck=Date.now()+15000;
        const valid=()=>run===epoch&&identity===id&&window.ApiClient===api&&api.getCurrentUserId()===user&&api.accessToken()===key&&host.isConnected;
        const get=window.GenreRowsCore.requester(api);
        try{
            const status=await get('GenreRows/Actors/Status');if(!valid()||!status.Enabled)return;
            root=el('section',undefined,'gr-actors');host.append(root);detachTV=window.GenreRowsTV.attach(root);
            const toolbar=el('div',undefined,'gr-actors-toolbar'),search=el('input'),sort=el('select'),favoritesButton=el('button','♥ '+t(9)),track=el('div',undefined,'gr-actors-track'),message=el('p',t(4)),note=el('p',t(23),'gr-discover-note');
            search.type='search';search.placeholder=t(1);search.setAttribute('aria-label',t(1));sort.setAttribute('aria-label','Discover / '+t(2)+' / '+t(3));sort.append(new Option('Discover','discover'),new Option(t(2),'asc'),new Option(t(3),'desc'));favoritesButton.type='button';favoritesButton.setAttribute('aria-pressed','false');
            toolbar.append(el('h2',t(0)),search,sort,favoritesButton);root.append(toolbar,note,message,track);window.GenreRowsTV.explicitSearch(search,t(1));
            const aboutButton=el('button',t(22)),about=el('section',undefined,'gr-actor-about');about.hidden=true;aboutButton.type='button';aboutButton.setAttribute('aria-expanded','false');
            about.append(el('p','Discover: 70% TMDB, 20% '+t(12)+', 10% '+({it:'rotazione giornaliera',fr:'rotation quotidienne',de:'tägliche Rotation',es:'rotación diaria',pt:'rotação diária'}[lang]||'daily rotation')));
            if(status.PopularityEnabled!==false){const logo=el('img');logo.src=api.getUrl('GenreRows/Actors/TmdbLogo');logo.alt='TMDB';const link=el('a','TMDB');link.href='https://www.themoviedb.org';link.target='_blank';link.rel='noopener noreferrer';about.append(logo,el('p','This product uses the TMDB API but is not endorsed or certified by TMDB.'),link);}
            aboutButton.onclick=()=>{about.hidden=!about.hidden;aboutButton.setAttribute('aria-expanded',String(!about.hidden));};root.append(aboutButton,about);
            const libraries=await get('GenreRows/Libraries');if(!valid())return;
            const people=new Map(),cards=new Map();let shown=30,revision='',popVersion='',popLoading=false,loading=true,availableCount=0,favorites=new Set(),favoritesOnly=false,favoritesBusy=false,exposed=[],drawTimer,lastDraw=0;
            const seed=user+'|'+new Date().toISOString().slice(0,10);
            const moreActors=el('button',t(8),'gr-person gr-actors-more focusable');moreActors.type='button';
            const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
            if('IntersectionObserver' in window)portraitObserver=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){const image=entry.target;if(image.dataset.src&&image.getAttribute('src')!==image.dataset.src)image.src=image.dataset.src;portraitObserver.unobserve(image);}},{root:track,rootMargin:'0px 150px'});
            function scheduleDraw(){if(!valid()||drawTimer)return;if(!lastDraw){draw();return;}drawTimer=setTimeout(()=>{drawTimer=null;draw();},Math.max(0,200-(performance.now()-lastDraw)));}
            async function loadFavorites(){if(favoritesBusy||!valid())return;favoritesBusy=true;try{const response=await get('GenreRows/Actors/Favorites');if(!valid())return;favorites=new Set(response.Ids||[]);draw();}catch(_){if(valid())message.textContent=t(7);}finally{favoritesBusy=false;}}
            function draw(){
                if(!valid())return;lastDraw=performance.now();
                const term=search.value.trim().toLocaleLowerCase(),all=[...people.values()];
                const matches=p=>p.Name?.toLocaleLowerCase().includes(term)&&(!favoritesOnly||favorites.has(p.Id));
                const matching=all.filter(matches);availableCount=matching.length;
                // A background page/popularity update must not move portraits the user already sees.
                // Recompute their order only on an explicit sort/search/filter or the next visit.
                exposed=exposed.filter(id=>people.has(id)&&matches(people.get(id)));
                if(exposed.length<Math.min(shown,availableCount)){
                    const known=new Set(exposed),remaining=matching.filter(p=>!known.has(p.Id));
                    const ordered=sort.value==='discover'?discover(remaining,seed):remaining.sort((a,b)=>a.Name.localeCompare(b.Name)*(sort.value==='desc'?-1:1));
                    exposed.push(...ordered.slice(0,shown-exposed.length).map(p=>p.Id));
                }
                message.textContent=loading?t(4)+' '+people.size:(availableCount?'':t(5));note.hidden=sort.value!=='discover';note.textContent=(all.some(p=>Number(p.Popularity)>0)?t(24):t(23))+(popLoading?' · '+t(25):'');
                const desired=[];
                for(const id of exposed.slice(0,shown)){
                    const person=people.get(id);let button=cards.get(id);
                    if(!button){
                        button=el('button',undefined,'gr-person focusable');const frame=el('span',undefined,'gr-person-frame'),image=el('img');
                        button.type='button';button.dataset.id=id;image.alt='';image.loading='lazy';image.decoding='async';frame.append(image,el('span',person.Name,'gr-person-name'));button.append(frame);
                        button.onclick=()=>{const current=people.get(id);if(current)void openProfile(current);};cards.set(id,button);
                    }
                    if(button.getAttribute('aria-label')!==person.Name){button.setAttribute('aria-label',person.Name);button.querySelector('.gr-person-name').textContent=person.Name;}
                    const image=button.querySelector('img'),url=person.PrimaryImageTag?api.getImageUrl(person.Id,{type:'Primary',tag:person.PrimaryImageTag,maxWidth:312}):'';
                    if(image.dataset.src!==url){image.dataset.src=url;if(url){if(portraitObserver)portraitObserver.observe(image);else image.src=url;}else{portraitObserver?.unobserve(image);image.removeAttribute('src');}}
                    const heart=button.querySelector('.gr-person-heart');if(favorites.has(id)&&!heart){const badge=el('span','♥','gr-person-heart');badge.setAttribute('aria-hidden','true');button.firstChild.append(badge);}else if(!favorites.has(id))heart?.remove();
                    desired.push(button);
                }
                if(availableCount>shown)desired.push(moreActors);
                const wanted=new Set(desired);for(const node of [...track.children])if(!wanted.has(node)){portraitObserver?.unobserve(node.querySelector('img')||node);node.remove();if(node.dataset.id)cards.delete(node.dataset.id);}
                // Keep existing nodes (and decoded image pixels). Inserting new siblings never resets focus or scroll.
                desired.forEach((node,index)=>{if(track.children[index]!==node)track.insertBefore(node,track.children[index]||null);});
            }
            moreActors.onclick=()=>{const previous=shown;shown+=30;draw();const next=track.querySelectorAll('.gr-person[data-id]')[previous];if(next)window.GenreRowsTV.focus(next);};
            async function loadCatalog(){
                let offset=0,scanRevision=null,scanPopularity=null;const received=new Map();
                try{while(valid()){
                    const page=await get('GenreRows/Actors/Catalog',{StartIndex:offset});if(!valid())return;
                    popLoading=!!page.PopularityLoading;
                    const currentPop=page.PopularityVersion||'';
                    if(offset===0&&revision===page.Revision&&popVersion===currentPop&&!page.Loading&&people.size===page.TotalCount){loading=false;scheduleDraw();break;}
                    if(scanRevision!==null&&(page.Revision!==scanRevision||currentPop!==scanPopularity)){offset=0;scanRevision=null;received.clear();await pause(100);continue;}
                    scanRevision=page.Revision;scanPopularity=currentPop;
                    for(const person of page.Items||[])if(person.Id){received.set(person.Id,person);people.set(person.Id,person);}loading=!!page.Loading;scheduleDraw();
                    if(page.Failed){message.textContent=t(7);break;}
                    const next=page.NextStartIndex;if(!page.Loading&&next>=page.TotalCount){
                        for(const id of people.keys())if(!received.has(id))people.delete(id);
                        revision=scanRevision;popVersion=scanPopularity;scheduleDraw();void loadFavorites();break;
                    }
                    // Yield between metadata pages so slow links/TVs can paint the first portraits and respond to input.
                    await pause(next<=offset?750:60);offset=next;
                }}catch(_){if(valid())message.textContent=t(7);}
                if(valid())refreshTimer=setTimeout(()=>void loadCatalog(),30000);
            }
            track.addEventListener('focusin',e=>{const cards=[...track.querySelectorAll('.gr-person[data-id]')],card=e.target.closest('.gr-person[data-id]');if(card&&cards.indexOf(card)>=cards.length-5&&shown<availableCount){shown+=30;draw();}});
            async function openProfile(person){
                if(!valid())return;closeProfile();returnFocus=document.activeElement;returnId=person.Id;previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
                const dialog=el('section',undefined,'gr-actor-page');profile=dialog;dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-label',person.Name);
                const live=()=>valid()&&profile===dialog;const back=el('button','← '+t(6));back.type='button';back.onclick=closeProfile;dialog.append(back,el('p',t(4)));document.body.append(dialog);
                detachProfile=window.GenreRowsTV.attach(dialog,{trap:true,onBack:closeProfile});window.GenreRowsTV.focus(back);
                dialog.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const controls=[...dialog.querySelectorAll('button,a[href],select')].filter(n=>!n.disabled&&!n.hidden&&n.getClientRects().length);if(!controls.length)return;const edge=e.shiftKey?controls[0]:controls.at(-1);if(document.activeElement===edge){e.preventDefault();window.GenreRowsTV.focus(e.shiftKey?controls.at(-1):controls[0]);}});
                try{
                    const info=await get('GenreRows/Actors/Details/'+person.Id);if(!live())return;
                    const hero=el('div',undefined,'gr-actor-profile'),photo=el('img',undefined,'gr-actor-photo'),copy=el('div'),favorite=el('button'),bio=el('p',String(info.Biography||t(19)).replace(/<[^>]*>/g,''),'gr-actor-biography gr-collapsed'),expand=el('button',t(20));
                    photo.alt=person.Name;if(info.PrimaryImageTag)photo.src=api.getImageUrl(person.Id,{type:'Primary',tag:info.PrimaryImageTag,maxWidth:420});
                    let isFavorite=!!info.IsFavorite;const favoriteLabel=()=>{favorite.textContent='♥ '+t(isFavorite?18:17);favorite.setAttribute('aria-pressed',String(isFavorite));};favoriteLabel();favorite.type='button';
                    favorite.onclick=async()=>{if(!live())return;favorite.disabled=true;try{await api.ajax({type:'POST',url:api.getUrl('GenreRows/Actors/Favorite/'+person.Id),contentType:'application/json',data:JSON.stringify({IsFavorite:!isFavorite})});if(!live())return;isFavorite=!isFavorite;favoriteLabel();if(isFavorite)favorites.add(person.Id);else favorites.delete(person.Id);draw();}catch(_){if(live())error.textContent=t(7);}finally{favorite.disabled=false;if(live()&&document.activeElement===document.body)window.GenreRowsTV.focus(favorite);}};
                    expand.type='button';expand.hidden=String(info.Biography||'').length<450;expand.onclick=()=>{const collapsed=bio.classList.toggle('gr-collapsed');expand.textContent=t(collapsed?20:21);};
                    copy.append(el('h1',person.Name),favorite);if(info.BirthDate||info.BirthPlaces?.length){const birth=[info.BirthDate?new Date(info.BirthDate).toLocaleDateString():null,...(info.BirthPlaces||[])].filter(Boolean);copy.append(el('p',birth.join(' · ')));}copy.append(bio,expand);hero.append(photo,copy);
                    const filters=el('div',undefined,'gr-actor-filters'),genre=el('select'),year=el('select'),order=el('select'),recentTitle=el('h2',t(13)),recent=el('div',undefined,'gr-actor-recent'),grid=el('div',undefined,'gr-actor-items gr-actor-movies'),tvGrid=el('div',undefined,'gr-actor-items gr-actor-series'),moviesTitle=el('h2',television[0]),tvTitle=el('h2',television[1]),count=el('p',t(4)),error=el('p',undefined,'gr-actor-error'),more=el('button',t(8));
                    genre.setAttribute('aria-label',t(15));year.setAttribute('aria-label',t(16));order.setAttribute('aria-label',t(14));order.append(new Option(t(14),'recent'),new Option(label(0)+' A–Z','asc'),new Option(label(0)+' Z–A','desc'),new Option(label(1),'yearDesc'),new Option(label(2),'yearAsc'),new Option(label(3),'rating'));filters.append(genre,year,order);dialog.replaceChildren(back,hero,recentTitle,recent,el('h2',t(12)),filters,count,moviesTitle,grid,tvTitle,tvGrid,more,error);
                    if(!dialog.contains(document.activeElement))window.GenreRowsTV.focus(back);
                    const media=new Map();let limit=120,mediaLoading=true;
                    function seasonText(item){
                        if(mediaLoading||item.Type!=='Series'||!item.HasEpisodeCredits)return'';
                        const numbers=[...new Set(item.SeasonNumbers||[])].filter(n=>Number.isInteger(n)&&n>=0).sort((a,b)=>a-b),available=item.AvailableSeasonNumbers||[];
                        if(!numbers.length||item.SeasonCoverageKnown&&available.length&&available.every(n=>numbers.includes(n)))return'';
                        const seasons=numbers.filter(n=>n>0),parts=[];if(seasons.length)parts.push(television[seasons.length===1?2:3]+' '+seasons.join(', '));if(numbers.includes(0))parts.push(television[4]);return parts.join(' · ');
                    }
                    function syncMedia(container,list){
                        const existing=new Map([...container.children].map(n=>[n.dataset.id,n])),ids=new Set(list.map(i=>i.Id));for(const[id,node]of existing)if(!ids.has(id))node.remove();
                        for(const[index,item]of list.entries()){
                            let link=existing.get(item.Id);if(!link){link=el('a',undefined,'gr-actor-item focusable');const image=el('img');image.alt='';image.loading='lazy';image.decoding='async';link.dataset.id=item.Id;link.href='#/details?id='+encodeURIComponent(item.Id)+'&serverId='+encodeURIComponent(api.serverId());link.append(image,el('span',undefined,'gr-actor-item-name'),el('small',undefined,'gr-actor-year'),el('small',undefined,'gr-actor-seasons'));}
                            const image=link.querySelector('img'),url=item.PrimaryImageTag?api.getImageUrl(item.Id,{type:'Primary',tag:item.PrimaryImageTag,maxWidth:360}):'';if(image.dataset.source!==url){image.dataset.source=url;if(url)image.src=url;else image.removeAttribute('src');}
                            for(const[selector,text]of[['.gr-actor-item-name',item.Name],['.gr-actor-year',item.ProductionYear?String(item.ProductionYear):''],['.gr-actor-seasons',seasonText(item)]]){const n=link.querySelector(selector);if(n.textContent!==text)n.textContent=text;n.hidden=!text;}
                            if(container.children[index]!==link)container.insertBefore(link,container.children[index]||null);
                        }
                    }
                    function drawMedia(){
                        if(!live())return;const all=[...media.values()],selectedGenre=genre.value,selectedYear=year.value,focusedId=document.activeElement?.closest('.gr-actor-item')?.dataset.id,focusRecent=recent.contains(document.activeElement);
                        genre.replaceChildren(new Option(t(10),''),...[...new Set(all.flatMap(i=>i.Genres||[]))].sort((a,b)=>a.localeCompare(b)).map(g=>new Option(g,g)));
                        year.replaceChildren(new Option(t(11),''),...[...new Set(all.map(i=>i.ProductionYear).filter(Boolean))].sort((a,b)=>b-a).map(y=>new Option(String(y),String(y))));genre.value=selectedGenre;year.value=selectedYear;
                        const visible=all.filter(i=>(!genre.value||i.Genres?.includes(genre.value))&&(!year.value||String(i.ProductionYear)===year.value)).sort((a,b)=>{
                            if(order.value==='recent')return(Date.parse(b.DateCreated)||0)-(Date.parse(a.DateCreated)||0)||a.Name.localeCompare(b.Name);
                            if(order.value==='rating')return(Number(b.CommunityRating)||-1)-(Number(a.CommunityRating)||-1)||a.Name.localeCompare(b.Name);
                            if(order.value==='yearDesc'||order.value==='yearAsc'){const ay=Number(a.ProductionYear)||0,by=Number(b.ProductionYear)||0;return(!ay)-(!by)||(order.value==='yearDesc'?by-ay:ay-by)||a.Name.localeCompare(b.Name);}
                            return a.Name.localeCompare(b.Name)*(order.value==='desc'?-1:1);
                        });
                        const movies=visible.filter(i=>i.Type==='Movie'),shows=visible.filter(i=>i.Type==='Series');syncMedia(grid,movies.slice(0,limit));syncMedia(tvGrid,shows.slice(0,limit));moviesTitle.hidden=grid.hidden=!movies.length;tvTitle.hidden=tvGrid.hidden=!shows.length;more.hidden=movies.length<=limit&&shows.length<=limit;count.textContent=(mediaLoading?t(4)+' ':'')+(movies.length+shows.length);
                        const latest=all.filter(i=>i.Type==='Movie'&&i.DateCreated).sort((a,b)=>Date.parse(b.DateCreated)-Date.parse(a.DateCreated)).slice(0,6);syncMedia(recent,latest);recentTitle.hidden=recent.hidden=!latest.length;
                        if(focusedId){const next=[...(focusRecent?recent:dialog).querySelectorAll('.gr-actor-item')].find(n=>n.dataset.id===focusedId);if(next&&next!==document.activeElement)window.GenreRowsTV.focus(next);}
                    }
                    genre.onchange=year.onchange=order.onchange=()=>{limit=120;drawMedia();};more.type='button';more.onclick=()=>{limit+=120;drawMedia();};drawMedia();
                    for(const library of libraries){for(let start=0;live();){const page=await get('GenreRows/Actors/Titles/'+person.Id,{LibraryId:library.Id,StartIndex:start});if(!live())return;for(const item of page.Items||[]){if(!['Movie','Series'].includes(item.Type))continue;const previous=media.get(item.Id);media.set(item.Id,{...item,SeasonNumbers:[...new Set([...(previous?.SeasonNumbers||[]),...(item.SeasonNumbers||[])])],AvailableSeasonNumbers:[...new Set([...(previous?.AvailableSeasonNumbers||[]),...(item.AvailableSeasonNumbers||[])])],HasEpisodeCredits:!!(previous?.HasEpisodeCredits||item.HasEpisodeCredits),SeasonCoverageKnown:!!(previous?.SeasonCoverageKnown||item.SeasonCoverageKnown)});}drawMedia();if(!page.HasMore||page.NextStartIndex<=start)break;start=page.NextStartIndex;}}
                    mediaLoading=false;drawMedia();
                }catch(_){if(live())dialog.append(el('p',t(7)));}
            }
            const reorder=()=>{shown=30;exposed=[];draw();};search.oninput=reorder;sort.onchange=reorder;favoritesButton.onclick=()=>{favoritesOnly=!favoritesOnly;favoritesButton.setAttribute('aria-pressed',String(favoritesOnly));reorder();void loadFavorites();};draw();void loadCatalog();
        }catch(_){if(valid()&&root)root.append(el('p',t(7)));}
    }
    window.addEventListener('hashchange',()=>{reset();nextCheck=0;void check();});window.addEventListener('genreRowsSettingsChanged',()=>{reset();nextCheck=0;void check();});setInterval(()=>{if(!document.hidden)void check();},1500);void check();
})();
