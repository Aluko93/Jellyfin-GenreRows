/* Genre Rows — no translation lookup, no metadata writes, no external scripts. */
(() => {
    'use strict';
    if (window.__genreRowsLoaded) return;
    window.__genreRowsLoaded = true;
    const style = document.createElement('style');
    style.textContent = `
      .gr-root{--gr-card-width:clamp(125px,13vw,190px);margin:1.5em 0;padding:0 3.3%;min-width:0;box-sizing:border-box}.gr-section{margin:0 0 2em;min-width:0}
      .gr-heading{font-size:1.5em;margin:.5em 0}.gr-track{display:flex;gap:1em;overflow-x:auto;padding:.4em .2em 1em;scroll-snap-type:x proximity}
      .gr-root .gr-card{flex:0 0 var(--gr-card-width);width:var(--gr-card-width);max-width:var(--gr-card-width);min-width:0;display:block;box-sizing:border-box;color:inherit;text-decoration:none;scroll-snap-align:start;border-radius:.4em}
      .gr-card:focus-visible{outline:3px solid var(--accent,#00a4dc);outline-offset:3px}
      .gr-root .gr-poster{position:relative;width:100%;height:0;padding-bottom:150%;overflow:hidden;background:#252525;border-radius:.4em;display:block;box-sizing:content-box}
      .gr-root .gr-poster .gr-image{position:absolute;inset:0;display:block;width:100%;height:100%;min-width:0;max-width:100%;max-height:100%;margin:0;padding:0;object-fit:cover}
      .gr-title{display:block;margin-top:.5em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .gr-year{opacity:.65;font-size:.85em}.gr-controls{display:flex;align-items:center;gap:.5em}
      .gr-controls .gr-heading{flex:1;min-width:0;overflow-wrap:anywhere}.gr-arrow{flex-shrink:0;background:transparent;color:inherit;border:1px solid #777;border-radius:50%;width:2em;height:2em;cursor:pointer}
      .gr-status{opacity:.7;padding:1em 0}.gr-group-title{font-size:1.9em;margin:1.5em 0 .7em}.gr-diagnostics{font-size:.9em;opacity:.75;margin:1em 0}.gr-diagnostics summary{cursor:pointer}
      @media(prefers-reduced-motion:reduce){.gr-track{scroll-behavior:auto}}
    `;
    document.head.append(style);
    let generation = 0, session = '', activeRoot, retryAt = 0;
    const core = window.GenreRowsCore;
    const el = (tag, cls, text) => {
        const node = document.createElement(tag);
        if (cls) node.className = cls;
        if (text !== undefined) node.textContent = text;
        return node;
    };
    function drawRow(api, genre, items) {
        const section = el('section', 'gr-section');
        const header = el('div', 'gr-controls');
        header.append(el('h3', 'gr-heading', genre.Name));
        const track = el('div', 'gr-track');
        track.setAttribute('aria-label', genre.Name);
        for (const [label, sign, glyph] of [['Indietro', -1, '‹'], ['Avanti', 1, '›']]) {
            const button = el('button', 'gr-arrow', glyph);
            button.type = 'button'; button.setAttribute('aria-label', `${label}: ${genre.Name}`);
            button.onclick = () => track.scrollBy({ left: sign * track.clientWidth * .85,
                behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
            header.append(button);
        }
        section.append(header, track);
        for (const item of items) {
            const card = el('a', 'gr-card');
            card.href = '#/details?id=' + encodeURIComponent(item.Id) + '&serverId=' + encodeURIComponent(api.serverId());
            card.title = item.Name;
            const frame = el('span', 'gr-poster');
            if (item.ImageTags?.Primary) {
                const poster = el('img', 'gr-image');
                poster.alt = ''; poster.loading = 'lazy'; poster.decoding = 'async';
                poster.src = api.getImageUrl(item.Id, { type: 'Primary', tag: item.ImageTags.Primary, maxWidth: 380, quality: 90 });
                frame.append(poster);
            }
            card.append(frame);
            card.append(el('span', 'gr-title', item.Name), el('span', 'gr-year', item.ProductionYear || ''));
            track.append(card);
        }
        return section;
    }
    async function render(api, userId, root, epoch) {
        const valid = () => epoch === generation && root.isConnected && window.ApiClient === api && api.getCurrentUserId() === userId;
        const status = el('div', 'gr-status', 'Caricamento generi e librerie…');
        status.setAttribute('role', 'status'); root.append(status);
        try {
            const get = core.requester(api);
            const raw = await get('GenreRows/Settings');
            if (!valid()) return;
            if (!raw.Enabled) { root.replaceChildren(); return; }
            const cat = await core.catalogue(get,userId);
            if (!valid()) return;
            const settings = core.configuration(raw,cat);
            const jobs = [], diagnostics = [];
            let visible = 0, failures = cat.Errors.length;
            for (const category of settings.Groups.filter(g=>g.Enabled)) {
                const label = category.Name || (category.MediaType === 'Movie' ? 'Film' : 'Serie TV');
                const group = el('div','gr-group');
                const title = el('h2','gr-group-title',label); title.hidden = true; group.append(title); root.append(group);
                for (const genre of category.Genres) {
                    if (!core.activeLibraries(cat,category,genre).length) {
                        diagnostics.push(label+' — '+genre+': non disponibile nelle librerie selezionate per questo utente.');
                        continue;
                    }
                    const slot = el('div'); group.append(slot);
                    jobs.push({category,label,genre,slot,title});
                }
            }
            let cursor = 0, committed = 0;
            const ready = new Map(), used = {Movie:new Set(),Series:new Set()};
            function commitReady() {
                // Request completion order must not decide which genre gets the first unique titles.
                while (ready.has(committed) && valid()) {
                    const job = jobs[committed], response = ready.get(committed);
                    ready.delete(committed++);failures += response.Failures;
                    const items = core.diversify(response.Items,used[job.category.MediaType],job.category.Limit,15);
                    if (items.length) {
                        job.slot.replaceWith(drawRow(api,{Name:job.label+' — '+job.genre},items));
                        job.title.hidden = false; visible++;
                    } else {
                        job.slot.remove();
                        diagnostics.push(job.label+' — '+job.genre+': nessun elemento disponibile.');
                    }
                }
            }
            async function worker() {
                while (cursor < jobs.length && valid()) {
                    const index = cursor++, job = jobs[index];
                    const response = await core.items(get,userId,cat,job.category,job.genre,{CandidateLimit:Math.min(100,core.clamp(job.category.Limit)+60)});
                    if (!valid()) return;
                    ready.set(index,response);commitReady();
                }
            }
            await Promise.all([worker(),worker()]);
            if (!valid()) return;
            status.remove();
            if (!visible) root.append(el('p','gr-status','Nessuna riga disponibile con le selezioni attuali. Controlla generi e librerie nelle impostazioni Genre Rows.'));
            if (failures) {
                root.append(el('p','gr-status','Alcune librerie non sono state caricate. Nuovo tentativo tra 30 secondi.'));
                retryAt = Date.now()+30000;
            }
            if (diagnostics.length) {
                const detail=el('details','gr-diagnostics');
                detail.append(el('summary','',visible+' righe visibili · '+diagnostics.length+' senza contenuti disponibili'));
                for (const reason of diagnostics) detail.append(el('p','',reason));
                root.append(detail);
            }
        } catch (error) {
            if (!valid()) return;
            status.textContent = 'Generi non disponibili. Nuovo tentativo tra 30 secondi.';
            retryAt = Date.now() + 30000;
            console.warn('Genre Rows: caricamento non riuscito', error);
        }
    }
    function check() {
        const api = window.ApiClient;
        const userId = api?.getCurrentUserId?.();
        const host = [...document.querySelectorAll('#homeTab')].find(n => n.getClientRects().length);
        const key = userId && api ? `${api.serverAddress()}|${userId}` : '';
        if (!host || !key) {
            if (activeRoot) { generation++; activeRoot.remove(); activeRoot = null; }
            session = ''; retryAt = 0; return;
        }
        if (activeRoot?.isConnected && session === key && (!retryAt || Date.now() < retryAt)) return;
        activeRoot?.remove();
        generation++; session = key; retryAt = 0;
        activeRoot = el('div', 'gr-root');
        // Sibling of Jellyfin's .sections: native refreshes do not erase our rows.
        host.append(activeRoot);
        void render(api, userId, activeRoot, generation);
    }
    window.addEventListener('genreRowsSettingsChanged', () => { generation++; activeRoot?.remove(); activeRoot = null; check(); });
    window.addEventListener('hashchange', check);
    document.addEventListener('viewshow', check);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
    setInterval(() => { if (!document.hidden) check(); }, 1500);
    check();
})();
