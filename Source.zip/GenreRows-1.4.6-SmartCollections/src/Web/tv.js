/* Explicit search activation and remote navigation for plugin-owned controls only. */
(() => {
    'use strict';
    if (window.GenreRowsTV) return;
    const visible = n => !n.disabled && !n.hidden && !n.closest('[hidden],[inert]') && n.getClientRects().length && getComputedStyle(n).visibility !== 'hidden';
    function focus(node) {
        try {node.focus({preventScroll:true});} catch(_) {node.focus();}
        try {node.scrollIntoView({block:'nearest',inline:'nearest',behavior:'auto'});} catch(_) {node.scrollIntoView(false);}
    }
    function explicitSearch(input,label) {
        const button=document.createElement('button');button.type='button';button.className='gr-explicit-search focusable';button.textContent=label;button.setAttribute('aria-label',label);
        input.hidden=true;input.before(button);
        button.onclick=()=>{button.hidden=true;input.hidden=false;focus(input);};
        const close=()=>{input.hidden=true;button.hidden=false;button.textContent=input.value?label+': '+input.value:label;};
        input.addEventListener('blur',close);
        input.addEventListener('keydown',e=>{if(['Enter','Escape'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation();close();focus(button);}},true);
        return button;
    }
    function attach(scope,{trap=false,onBack}={}) {
        const controls=()=>[...scope.querySelectorAll('button,a[href],input,select,[tabindex="0"]')].filter(visible);
        const handler=e=>{
            if(!scope.isConnected)return;
            const current=document.activeElement;
            if(!scope.contains(current))return;
            const raw=e.key&&e.key!=='Unidentified'?e.key:({13:'Enter',37:'ArrowLeft',38:'ArrowUp',39:'ArrowRight',40:'ArrowDown',179:'MediaPlayPause',461:'GoBack',10009:'GoBack',10252:'MediaPlayPause'})[e.keyCode];
            const key=({Left:'ArrowLeft',Right:'ArrowRight',Up:'ArrowUp',Down:'ArrowDown',OK:'Enter',Select:'Enter'})[raw]||raw;
            const editing=current.matches('input:not([readonly]),textarea');
            if(editing)return;
            if((key==='Enter'&&current.matches('.gra-player-page'))||key==='MediaPlayPause'){
                const play=current.closest('.gra-player-page')?.querySelector('.gra-player-controls button');
                if(play){e.preventDefault();e.stopImmediatePropagation();play.click();return;}
            }
            if(['GoBack','BrowserBack','Back','Escape','Backspace'].includes(key)&&onBack){e.preventDefault();e.stopImmediatePropagation();onBack();return;}
            if(current.matches('select')){
                if(key==='Enter'){current.dataset.grEditing='true';return;}
                if(current.dataset.grEditing==='true')return;
            }
            if(key==='Enter'&&current.matches('button,a[href],[role="button"]')){e.preventDefault();e.stopImmediatePropagation();current.click();return;}
            if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(key))return;
            // The player's sliders retain their native arrow behavior.
            if(current.matches('input[type=range]')||current.closest('.gra-player-page'))return;
            const a=current.getBoundingClientRect(),ax=a.left+a.width/2,ay=a.top+a.height/2;
            const horizontal=key==='ArrowLeft'||key==='ArrowRight',sign=key==='ArrowLeft'||key==='ArrowUp'?-1:1;
            let target,score=Infinity;
            for(const candidate of controls()){
                if(candidate===current||current.contains(candidate))continue;
                const r=candidate.getBoundingClientRect(),dx=r.left+r.width/2-ax,dy=r.top+r.height/2-ay;
                const forward=(horizontal?dx:dy)*sign,cross=Math.abs(horizontal?dy:dx);
                if(forward<8)continue;
                const rank=forward+cross*4;
                if(rank<score){score=rank;target=candidate;}
            }
            if(target){e.preventDefault();e.stopImmediatePropagation();focus(target);}
            else if(trap){e.preventDefault();e.stopImmediatePropagation();scope.scrollTop+=horizontal?0:sign*scope.clientHeight*.65;scope.scrollLeft+=horizontal?sign*scope.clientWidth*.65:0;}
        };
        // Window capture runs before Jellyfin's document-level navigation handlers.
        window.addEventListener('keydown',handler,true);
        const selectReset=e=>{if(e.target.matches('select'))delete e.target.dataset.grEditing;};
        scope.addEventListener('change',selectReset);scope.addEventListener('focusout',selectReset);
        return ()=>{window.removeEventListener('keydown',handler,true);scope.removeEventListener('change',selectReset);scope.removeEventListener('focusout',selectReset);};
    }
    window.GenreRowsTV={attach,explicitSearch,focus};
})();
