using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;

namespace Jellyfin.Plugin.GenreRows;

[ApiController]
[Route("GenreRows")]
public sealed class RowsController : ControllerBase
{
    [Authorize]
    [HttpGet("Settings")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public object Settings()
    {
        var c = Plugin.Instance?.Configuration ?? new Configuration { Enabled = false };
        // Only presentation settings. Library access uses Jellyfin's authenticated APIs.
        return new {
            SchemaVersion = c.SchemaVersion,
            Enabled = c.Enabled, AllGenres = c.AllGenres,
            Genres = (c.Genres ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).ToArray(),
            Limit = Math.Clamp(c.Limit, 1, 100),
            MediaType = c.MediaType,
            MovieRows = CleanRows(c.MovieRows), SeriesRows = CleanRows(c.SeriesRows),
            MovieLimit = Math.Clamp(c.MovieLimit, 1, 100), SeriesLimit = Math.Clamp(c.SeriesLimit, 1, 100),
            Groups = (c.Groups ?? []).Where(g => g is not null).Select(g => new GenreGroup {
                Id = string.IsNullOrWhiteSpace(g.Id) ? Guid.NewGuid().ToString("N") : g.Id,
                Name = g.Name?.Trim() ?? "", Enabled = g.Enabled,
                MediaType = g.MediaType == "Series" ? "Series" : "Movie",
                LibraryIds = (g.LibraryIds ?? []).Where(id => Guid.TryParse(id, out _)).Select(id => Guid.Parse(id).ToString("N")).Distinct().ToArray(),
                Genres = (g.Genres ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).ToArray(),
                Limit = Math.Clamp(g.Limit, 1, 100)
            }).ToArray()
        };
    }

    private static GenreSelection[] CleanRows(GenreSelection[]? rows) => (rows ?? [])
        .Where(r => r is not null && !string.IsNullOrWhiteSpace(r.Genre))
        .GroupBy(r => r.Genre, StringComparer.Ordinal)
        .Select(g => new GenreSelection { Genre = g.Key, LibraryIds = g.SelectMany(r => r.LibraryIds ?? [])
            .Where(id => Guid.TryParse(id, out _)).Select(id => Guid.Parse(id).ToString("N")).Distinct().ToArray() }).ToArray();

    [Authorize]
    [HttpGet("Libraries")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public IActionResult Libraries([FromServices] ILibraryManager library, [FromServices] IUserManager users)
    {
        // Derive identity from Jellyfin's authenticated claim, never from a requested user ID.
        if (!Guid.TryParse(User.FindFirst("Jellyfin-UserId")?.Value, out var id)) return Unauthorized();
        var user = users.GetUserById(id);
        if (user is null) return Unauthorized();
        var folders = library.GetUserRootFolder().GetChildren(user, true).OfType<CollectionFolder>()
            .Where(f => library.GetLibraryOptions(f).Enabled)
            .OrderBy(f => f.Name).Select(f => new { Id = f.Id.ToString("N"), f.Name }).ToArray();
        return Ok(folders);
    }

    [AllowAnonymous]
    [HttpGet("client.js")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public ContentResult Script() => Content(Resources.Core + "\n" + Resources.Client + "\n" + Resources.TV + "\n" + Resources.Actors + "\n" + SmartCollections.SmartResources.Script + "\n" + Adult.AdultResources.HlsScript + "\n" + Adult.AdultResources.Script, "application/javascript; charset=utf-8");

    [AllowAnonymous]
    [HttpGet("core.js")]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public ContentResult Core() => Content(Resources.Core, "application/javascript; charset=utf-8");
}

internal static class Resources
{
    internal static readonly string Actors = Read("actors.js");
    internal static readonly string TV = Read("tv.js");
    internal static readonly string Client = Read("client.js");
    internal static readonly string Core = Read("core.js");
    private static string Read(string name)
    {
        using var stream = typeof(Plugin).Assembly.GetManifestResourceStream("Jellyfin.Plugin.GenreRows.Web." + name)!;
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
