#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
dotnet restore src/GenreRows.csproj --configfile NuGet.Config --locked-mode
dotnet build src/GenreRows.csproj -c Release --no-restore
cp src/bin/Release/net10.0/Jellyfin.Plugin.GenreRows.dll package/GenreRows_1.4.6.0/
(cd package/GenreRows_1.4.6.0 && sha256sum Jellyfin.Plugin.GenreRows.dll meta.json > SHA256SUMS)
